<?
/* This file is part of IJE: the Integrated Judging Environment system 
   (C) Kalinin Petr 2002-2008
   $Id: lang_english.php 202 2008-04-19 11:24:40Z *KAP* $ */
$lang['KirovTeamContest']="Kirov team contest";
$lang['LazurnyVersion']='Lazurny version';
$lang["Points"]="Points";
$lang["SuccessfullTests"]="Success. tests";
$lang["Full"]="Full";
$lang["Pl"]="Pl";

$lang["TotalSubmits"]="Total submits";
$lang["Submits"]="Submits";
$lang["Languages"]="Languages";
$lang["ExtraSubmissionPenalty"]="Extra submission penalty";
$lang["pts"]="pts";
?>