#define inputfile "lg.in"
#define outputfile "lg.out"

#include <fstream>
#include <string>
#include <vector>

typedef struct std::vector<int> number;

bool le(number a, number b) { // a <= b
	if (a.size()<b.size()) return true;
	if (a.size()>b.size()) return false;
	for (int i=0; i<a.size(); ++i)
		if (a[i]>b[i])
			return false;
		else
			return true;
}

void mult(number& a, int b) { // a = a * b
	int r = 0, p;
	for (int i=0; i<a.size(); ++i) {
		p = a[i]*b + r;
		a[i] = p%10;
		r = p/10;
	}
	while (r>0) {
		a.push_back(r%10);
		r/=10;
	}
}

int main() {
	std::ifstream ifs(inputfile, std::ifstream::in);
	std::string buffer;
	getline(ifs, buffer);
	int b;
	ifs >> b;
	ifs.close();
	
	assert((b>=2)&&(b<=100));
	number a;
	for (std::string::reverse_iterator it=buffer.rbegin(); it!=buffer.rend(); ++it)
	{
		assert((*it>='0')&&(*it<='9'));
		a.push_back(*it-'0');
	}
	assert(a.size()<=100);
	
	number x(1, 1); // x = 1
	int p = 0;
	
	while (le(x, a)) {
		mult(x, b);
		p++;
	}
	
	std::ofstream ofs(outputfile, std::ofstream::out);
		ofs << p-1;
	ofs.close();
	
	return 0;
}