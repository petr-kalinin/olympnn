#include <stdio.h>
#include <assert.h>
#include <string.h>

int a[26][26],b[26][26];
char s[501];
int n,m,ka[26],kb[26];

int dp[500][26],p[500][26],q[500][26];

int main()
{
	int i,cnt;
	freopen("cypher.in","rt",stdin);
	freopen("cypher.out","wt",stdout);
	scanf("%d\n",&n);
	assert(0<=n&&n<=676);
	memset(ka,0,sizeof(ka));
	memset(kb,0,sizeof(kb));
	for (i=0;i<n;i++){
		char x,y,z;
		scanf("%c%c%c",&x,&y,&z);
		assert('A'<=x&&x<='Z'&&'a'<=y&&y<='z'&&z=='\n');
		a[y-'a'][ka[y-'a']++]=x-'A';
	}
	scanf("%d\n",&m);
	assert(0<=m&&m<=676);
	for (i=0;i<m;i++){
		char x,y,z;
		scanf("%c%c%c",&x,&y,&z);
		assert('A'<=x&&x<='Z'&&'A'<=y&&y<='Z'&&z=='\n');
		b[x-'A'][kb[x-'A']++]=y-'A';
	}
	scanf("%d\n",&n);
	assert(1<=n&&n<=500);
	scanf("%s",s);
	assert(strlen(s)==n);
	for (i=0;i<n;i++)assert('a'<=s[i]&&s[i]<='z');
	memset(dp,0,sizeof(dp));
	memset(p,255,sizeof(p));
	memset(q,255,sizeof(q));
	for (i=0;i<ka[s[0]-'a'];i++)dp[0][a[s[0]-'a'][i]]=1;
	for (i=0;i<n-1;i++){
		int j;
		char w[26];
		memset(w,0,sizeof(w));
		for (j=0;j<ka[s[i+1]-'a'];j++)w[a[s[i+1]-'a'][j]]=1;
		for (j=0;j<26;j++){
			int k;
			for (k=0;k<kb[j];k++){
				if (w[b[j][k]]){
					dp[i+1][b[j][k]]+=dp[i][j];
					if (dp[i][j]>0){
						if (p[i+1][b[j][k]]<0)p[i+1][b[j][k]]=j;else
						if (q[i+1][b[j][k]]!=j) q[i+1][b[j][k]]=j;
					}
				}
			}
		}
	}
	cnt=0;
	for (i=0;i<26;i++)cnt+=dp[n-1][i];
	if (cnt==0)printf("no\n");else
	if (cnt==1){
		int ch=0;
		printf("only\n");
		for (i=0;i<26;i++)if (dp[n-1][i]){
			ch=i;
			break;
		}
		for (i=n-1;i>=0;i--){
			s[i]=ch+'A';
			ch=p[i][ch];
		}
		printf("%s\n",s);
	}else {
		int ch=0;
		printf("many\n");
		for (i=0;i<26;i++)if (dp[n-1][i]){
			ch=i;
			dp[n-i][i]--;
			break;
		}
		for (i=n-1;i>=0;i--){
			s[i]=ch+'A';
			ch=p[i][ch];
		}
		printf("%s\n",s);
		for (i=0;i<26;i++)if (dp[n-1][i]){
			ch=i;
			break;
		}
		for (i=n-1;i>=0;i--){
			s[i]=ch+'A';
			ch=(q[i][ch]>=0?q[i][ch]:p[i][ch]);
		}
		printf("%s\n",s);
	}
	return 0;
}
