#include <stdio.h>

int main(){
  FILE* f=fopen("..\\metro.out","w");
  fprintf(f,"1");
  fclose(f);
  return 0;
}