#include <stdlib.h>
#include <stdio.h>
#include <assert.h>
#include <string.h>

#define PROBLEM "cypher"
#define NLETTERS 26
#define TRUE  1
#define FALSE 0
#define MIN(a, b) ((a) < (b)) ? (a) : (b)

static char** build_dict(int m)
{
	char pair[m][2];
	char **dict;
	int count[NLETTERS];
	int i, j;
	
	memset(count, 0, sizeof(count));
	for (i = 0; i < m; i++) {
		scanf("%c%c\n", &pair[i][0], &pair[i][1]);
		assert('A' <= pair[i][0] && pair[i][0] <= 'Z');
		assert('a' <= pair[i][1] && pair[i][1] <= 'z');
		count[pair[i][1]-'a']++;
	}
	
	dict = (char**)calloc(NLETTERS, sizeof(char*));
	for (i = 0; i < NLETTERS; i++)
		dict[i] = (char*)calloc(count[i] + 1, sizeof(char));
	for (i = 0; i < m; i++) {
		j = pair[i][1] - 'a';
		dict[j][--count[j]] = pair[i][0];
	}
	
	return dict;
}

static char** build_rules(int k)
{
	char** rules;
	int i;
	
	rules = (char**)calloc(NLETTERS, sizeof(char*));
	for (i = 0; i < NLETTERS; i++)
		rules[i] = (char*)calloc(NLETTERS, sizeof(char));
	
	for (i = 0; i < k; i++) {
		char a, b;
		scanf("%c%c\n", &a, &b);
		assert('A' <= a && a <= 'Z');
		assert('A' <= b && b <= 'Z');
		rules[a-'A'][b-'A'] = TRUE;
	}
	
	return rules;
}

static void compute(int m, int k, int n, char **dict, char **rules, char *word)
{
	char dp[n][NLETTERS];
	int i, j, nvar;

	memset(dp, 0, sizeof(dp));
	for (i = 0; i < NLETTERS; i++)
		dp[0][i] = strchr(dict[word[0]-'a'], i+'A') ? 1 : 0;

	for (i = 1; i < n; i++) {
		char *p = dict[word[i]-'a'];
		while (*p != 0) {
			for (j = 0; j < NLETTERS; j++) {
				if (rules[j][*p-'A'])
					dp[i][*p-'A'] = MIN(dp[i][*p-'A'] + dp[i-1][j], 2);
			}
			p++;
		}
	}
	
	nvar = 0;
	for (i = 0; i < NLETTERS; i++)	
		nvar += dp[n-1][i];
	
	
	if (nvar == 0) {
		printf("no\n");
		return;
	}
	printf("%s\n", (nvar == 1) ? "only": "many");
	
	char* orig = (char*)calloc(n + 1, sizeof(char));
	for (i = 0; i < NLETTERS; i++) {
		if (dp[n-1][i] == 0) continue;
		// decode first variant
		j = n - 1;
		orig[j] = i + 'A';
		while (--j >= 0) {
			char c;
			orig[j] = 0;
			for (c = 'A'; c <= 'Z'; c++)
			if (rules[c-'A'][orig[j+1]-'A'] && dp[j][c-'A']) {
				orig[j] = c;
				break;
			}
			assert (orig[j] != 0);
		}
		printf("%s\n", orig);
		if (nvar == 1) break;
		
		if (dp[n-1][i] > 1) {
			// decode last variant
			j = n - 1;
			orig[j] = i + 'A';
			while (--j >= 0) {
				char c;
				orig[j] = 0;
				for (c = 'Z'; c >= 'A'; c--)
				if (rules[c-'A'][orig[j+1]-'A'] && dp[j][c-'A']) {
					orig[j] = c;
					break;
				}
				assert (orig[j] != 0);
			}
			printf("%s\n", orig);
			break;
		} else
			nvar = 1;
	}
	free(orig);
}

static void solve()
{
	int m, k, n, i;
	char **dict, **rules;
	char *word;

	scanf("%d\n", &m);
	assert(0 <= m && m <= 676);
	dict = build_dict(m);
	scanf("%d\n", &k);
	assert(0 <= k && k <= 676);
	rules = build_rules(k);
	
	scanf("%d\n", &n);
	assert(1 <= n && n <= 500);
#ifdef _GNU_SOURCE
	scanf("%a[a-z]", &word);
#else
	word = (char*)malloc (n + 1);
	scanf("%s", word);
#endif
	assert(strlen(word) == n);
	
	// DP
	compute(m, k, n, dict, rules, word);
	
	free(word);
	for (i = 0; i < NLETTERS; i++)
		free(dict[i]);
	free(dict);
	for (i = 0; i < NLETTERS; i++)
		free(rules[i]);
	free(rules);
}

int main(int argc, char* argv[])
{
#ifndef USE_STDIO
	freopen(PROBLEM".in", "r", stdin);
	freopen(PROBLEM".out", "w", stdout);
#endif
	solve();
	return 0;
}

