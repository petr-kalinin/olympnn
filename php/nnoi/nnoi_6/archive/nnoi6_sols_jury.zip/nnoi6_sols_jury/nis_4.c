#include <stdlib.h>
#include <stdio.h>

void wrongInput(void)
{
	fprintf(stderr, "Wrong input format\n");
	exit(1);
}

void readLine(int n, char* str)
{
	char c;
	while (n --> 0) {
		scanf("\t%c", &c);
		if (c != '.' && c != '#')
			wrongInput();
		*(str++) = c;
	}
	scanf("\n");
}

void printLine(int n, char* str)
{
	int i;
	printf("%c", str[0]);
	for (i = 1; i < n; i++)
		printf("%c%c", (str[i-1] == '#' && str[i] == '#') ? '-' : ' ', str[i]);
	printf("\n");
}

int main(int argc, char* argv[])
{
	char *p1, *p2, *p;
	size_t i, j, n, m;
	
	freopen("balls.in", "r", stdin);
	freopen("balls.out", "w", stdout);
	
	scanf("%d %d\n", &n, &m);
	p1 = (char*) malloc(m);
	p2 = (char*) malloc(m);
	
	readLine(m, p1);
	printLine(m, p1);
	for (i = 1; i < n; i++) {
		readLine(m, p2);
		for (j = 0; j < m; j++) {
			printf("%c", (p1[j] == '#' && p2[j] == '#') ? '|' : ' ');
			if (j != (m-1)) {
				char c = ' ';
				if (p1[j] == '#' && p2[j+1] == '#')
					c = '\\';
				if (p1[j+1] == '#' && p2[j] == '#')
					c = (c == ' ') ? '/' : 'X';
				printf("%c", c);
			}
		}
		printf("\n");
		printLine(m, p2);
		p = p1; p1 = p2; p2 = p;
	}
	
	free(p1);
	free(p2);
	return 0;
}

