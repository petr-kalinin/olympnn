#include <stdio.h>
#include <assert.h>
#include <string.h>
#include <stdlib.h>

#define fin "balls.in"
#define fout "balls.out"

char **a;

const char X[4]={' ','/','\\','X'};

int main()
{
	int n,i,m;
	freopen(fin,"rt",stdin);
	freopen(fout,"wt",stdout);

	scanf("%d%d",&n,&m);
	assert(1<=n&&n<=100&&1<=m&&m<=100);
	a=(char**)calloc(n,sizeof(char*));
	for (i=0;i<n;i++){
		int j;
		a[i]=(char*)malloc(m+1);
		memset(a[i],0,sizeof(a[i]));
		scanf("%s",a[i]);
		assert(strlen(a[i])==m);
		for (j=0;j<m;j++)assert(a[i][j]=='.'||a[i][j]=='#');
	}
	for (i=0;i<n;i++){
		int j;
		if (i){
			for (j=0;j<m;j++){
				if (a[i][j]=='#'&&a[i-1][j]=='#')printf("|");else printf(" ");
				if (m!=j+1){
					int x=0;
					if (a[i][j]=='#'&&a[i-1][j+1]=='#')x+=1;
					if (a[i][j+1]=='#'&&a[i-1][j]=='#')x+=2;
					printf("%c",X[x]);
				}
			}
			printf("\n");
		}
		for (j=0;j<m;j++){
			if (j){
				if (a[i][j-1]=='#'&&a[i][j]=='#')printf("-");else printf(" ");
			}
			printf("%c",a[i][j]);
		}	
		printf("\n");
	}
	fflush(stdout);

	for (i=0;i<n;i++) free(a[i]);
	free(a);

	return 0;
}
