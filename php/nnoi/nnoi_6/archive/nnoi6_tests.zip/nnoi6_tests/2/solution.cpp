#define inputfile "change.in"
#define outputfile "change.out"

#include <fstream>
#include <cassert>

int main() {
	int n, coin, current = 0, min = 0;
	
	std::ifstream ifs(inputfile, std::ifstream::in);
		ifs >> n;
		assert(n>0&&n<=50000);
		for (int i=0; i<n; ++i) {
			ifs >> coin;
			assert(coin==5||coin==10||coin==50||coin==100);
			switch(coin) {
				case 5: current += 1; break;
				case 10: current -= 1; break;
				case 50: current -= 9; break;
				case 100: current -= 19; break;
			}
			if (current<min) min = current;
		}
	ifs.close();
	
	std::ofstream ofs(outputfile, std::ofstream::out);
		ofs << -min;
	ofs.close();
	
	return 0;
}