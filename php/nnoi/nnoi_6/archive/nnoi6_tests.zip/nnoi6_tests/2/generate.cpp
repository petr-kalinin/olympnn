#include <fstream>
#include <sstream>
#include <stdlib.h>
#include <vector>

void random(int n, std::vector<int>& a) {
	const int c[] = {5, 10, 50, 100};
	for (int i=0; i<n; ++i)
		a.push_back(c[rand()%4]);
}

int main() {
	srand(48151623);
	const int max = 50000;
	for (int i=1; i<=20; ++i) {
		std::vector<int> a;
		switch(i) {
			case 1:  a.push_back(5);  break;
			case 2:  a.push_back(10); break;
			case 3:  a.push_back(10); a.push_back(10); break;
			case 4:  for (int i=0; i<100; ++i) a.push_back(50); break;
			case 5:  for (int i=0; i<max; ++i) a.push_back(10); break;
			case 6:  for (int i=0; i<max; ++i) a.push_back(100); break;
			case 7:  for (int i=0; i<300; ++i) { a.push_back(10); a.push_back(5); } break;
			case 8:  for (int i=0; i<300; ++i) { a.push_back(5); a.push_back(10); } break;
			case 9:  for (int i=0; i<100; ++i) { for (int j=0; j<10; ++j) a.push_back(5); a.push_back(50); } break;
			case 10: for (int i=0; i<1000; ++i) { for (int j=0; j<10; ++j) a.push_back(5); a.push_back(100); } break;
			case 11: for (int i=0; i<1000; ++i) { for (int j=0; j<20; ++j) a.push_back(5); a.push_back(100); } break;
			case 12: for (int i=0; i<1000; ++i) { for (int j=0; j<10; ++j) a.push_back(5); a.push_back(10); }
					 for (int i=0; i<1000; ++i) { for (int j=0; j<10; ++j) a.push_back(5); a.push_back(50); } break;
			case 13: for (int i=0; i<max; ++i) { a.push_back(5); } break;
			case 14: case 15: random(10, a); break;
			case 16: case 17: random(1000, a); break;
			case 18: case 19: random(32000, a); break;
			case 20: random(50000, a); break;
			default: random(50000, a); break;
		}
		std::stringstream stream;
		if (i<10) stream << "0";
		stream << i;
		std::ofstream o(stream.str().c_str(), std::ofstream::out);
		o << a.size() << "\n";
		for (std::vector<int>::const_iterator i=a.begin(); i!=a.end(); ++i)
			o << *i << " ";
		o.close();
	}
}