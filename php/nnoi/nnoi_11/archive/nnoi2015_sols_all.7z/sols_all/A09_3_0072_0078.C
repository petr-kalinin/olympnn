#include <stdio.h>

int main() {
    FILE *fin, *fout;

    int h1, m1, h2, m2;

    fin = fopen("cuckoo.in", "r");

    fscanf(fin, "%d %d %d %d", h1, m1, h2, m2);
    fclose(fin);

    fout = fopen("cuckoo.out", "w");
    if (h1 == h2) {
        if (m1 < 30 && m2 > 30) {
            fprintf(fout, "%d", 1);
            fclose(fout);
            return 0;
        } else {
            fprintf(fout, "%d", 0);
            fclose(fout);
            return 0;
        }
    } else if (h1 > h2) {
        int count = 0;
        if (m1 < 30)
            count++;
        if (m2 > 30)
            count++;

        int i;
        for (i=h1+1; i < h2; i++) {
            count += i;
        }
        fprintf(fout, "%d", count);
        fclose(fout);
    }

    return 0;
}
