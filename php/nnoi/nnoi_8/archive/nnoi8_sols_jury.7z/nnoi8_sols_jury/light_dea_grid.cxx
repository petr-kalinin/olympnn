#include <cstdio>
#include <algorithm>
#include <cmath>
#include <iostream>

using namespace std;

#define MAX_TEST 500
#define INF 10000
#define EPS 1e-7

const int pr[6][3] = {{1,2,3},{1,3,2},{2,1,3},{2,3,1},{3,1,2},{3,2,1}};
const int ans[6][3] = {{1,2,3},{1,3,2},{2,1,3},{3,1,2},{2,3,1},{3,2,1}};

struct point
{
    double x, y;
    void read()
    {
        scanf("%lf %lf", &x, &y);
    }
} p[10], t;

double sq(point a, point b, point c)
{
    return abs( (b.x - a.x)*(c.y - a.y) - (b.y - a.y)*(c.x - a.x) );
}

bool _in(point &t, point &a, point &b, point &c)
{
    double s1 = sq(a, b, c);
    double s2 = sq(t, a, b) + sq(t, b, c) + sq(t, a, c);
    return abs(s1 - s2) < EPS;
}

double xt, yt, xmin, ymin, xmax, ymax;

int main()
{
    freopen("light.in", "r", stdin);
    freopen("light.out", "w", stdout);
    int tc;
    scanf("%i", &tc);
    while (tc--)
    {
        xmin = ymin = INF;
        ymax = xmax = -INF;
        for(int i=0; i<6; ++i) 
        {
            p[i].read();
            xmin = min(xmin, p[i].x);
            ymin = min(ymin, p[i].y);
            xmax = max(xmax, p[i].x);
            ymax = max(ymax, p[i].y);
        }
        bool g_ok = false;
        for(int i=0; i<6; ++i)
        {
            bool ok = true;
            for(int j=0; j<3; ++j) p[6 + j] = p[2 + pr[i][j] ];
            for(int sx=0; sx<=MAX_TEST; ++sx)
            {
                t.x = sx * (xmax - xmin) / MAX_TEST + xmin;
                for(int sy=0; sy<=MAX_TEST; ++sy)
                {
                    t.y = sy * (ymax - ymin) / MAX_TEST + ymin;
                
                    if (_in(t, p[0], p[1], p[2]))
                        if (!(_in(t, p[0], p[1], p[6]) || _in(t, p[1], p[2], p[7]) || _in(t, p[2], p[0], p[8])))
                        {
                            ok = false;
                            break;
                        }
                }
            }
            if (ok)
            {
                printf("%i %i %i \n", ans[i][0], ans[i][1], ans[i][2]);                
                g_ok = true;
                break;
            }
        }
        if (!g_ok) printf("no solution\n");
    }
    return 0;
}
