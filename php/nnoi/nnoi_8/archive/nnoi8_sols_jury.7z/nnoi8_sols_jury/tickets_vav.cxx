#include <cstdio>
#include <iostream>
#include <algorithm>
#include <cstring>
#include <string>
#include <set>
#include <vector>
#include <cmath>
#include <cassert>
#include <cstdlib>
#include <map>
#include <queue>
#include <deque>
#include <bitset>

#define y0 y63475625
#define y1 y28435
#define j0 jfd0sf
#define j1 je90ue0
#define sqr(x) ((x)*(x))
#define fi first
#define se second
#define pb push_back
#define mp make_pair
#define re return
#define sz(x) ((int)(x).size())
#define all(x) (x).begin(), (x).end()
#define rep(i, n) for (int i = 0; i < (n); i++)
#define rrep(i, n) for (int i = (n) - 1; i >= 0; i--)
#define sqrt(x) (sqrt(abs(x)))
#define fill(a, x) memset(a, x, sizeof(a))

using namespace std;

typedef vector <int> vi;
typedef vector <vi> vvi;
typedef long long ll;
typedef long double ld;
typedef pair <int, int> ii;
typedef vector <ii> vii;
typedef double D;
typedef pair <ll, ll> pll;
typedef vector <string> vs;

template <class T> T abs(const T a) {
	return a > 0 ? a : -a;
}

const double PI = 2.0 * acos(1.0);

int n;
int m;

int main()
{
	freopen("tickets.in", "r", stdin);
	freopen("tickets.out", "w", stdout);
	cin >> n;
	if (n == 1) {
		printf("18\n");
		rep(i, 9) {
			printf("%02d\n", (i * 11 + (i + 1) * 11) / 2);
			printf("%02d\n", (i * 11 + (i + 1) * 11) / 2 + 1);
		}
	} else {
		printf("4\n");
		rep(i, n)
			printf("0");
		printf("5");
		rep(i, n - 1)
			printf("0");
		printf("\n");
		
		rep(i, n)
			printf("0");
		printf("5");
		rep(i, n - 2)
			printf("0");
		printf("1\n");
		
		rep(i, n)
			printf("9");
		printf("4");
		rep(i, n - 2)
			printf("9");
		printf("8\n");
		
		rep(i, n)
			printf("9");
		printf("4");
		rep(i, n -1)
			printf("9");
		printf("\n");
	}
	return 0;
}
