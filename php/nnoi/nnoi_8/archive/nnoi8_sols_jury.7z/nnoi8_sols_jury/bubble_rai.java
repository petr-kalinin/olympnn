import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintWriter;
import java.math.BigInteger;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class bubble_rai {
    public static void main(String[] args) throws FileNotFoundException {
        new bubble_rai().run();
    }

    private void run() throws FileNotFoundException {
        Scanner in = new Scanner(new File("bubble.in"));
        PrintWriter out = new PrintWriter(new File("bubble.out"));
        int n = in.nextInt();
        int[] a = new int[10000];
        for (int i = 0; i < n; i++) {
            a[i] = in.nextInt();
        }
        List<Integer> pr = new ArrayList<Integer>();
        for (int i = 2; i <= 1000; i++) {
            boolean ok = true;
            for (int j: pr) {
                if (i % j == 0) {
                    ok = false;
                    break;
                }
            }
            if (ok) {
                pr.add(i);
            }
        }
        BigInteger ans = BigInteger.ONE;
        for (int i: pr) {
            int best = 1;
            for (int j = 0; j < n; j++) {
                int cur = 1;
                while (a[j] % i == 0) {
                    a[j] /= i;
                    cur *= i;
                }
                best = Math.max(best, cur);
            }
            ans = ans.multiply(BigInteger.valueOf(best));
        }
        out.println(ans);
        in.close();
        out.close();
    }
}
