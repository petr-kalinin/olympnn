#include <iostream>
#include <cstdio>
#include <cstdlib>
#include <vector>

using namespace std;

const int MAXN = 15;

int n;
int value[MAXN];

int maskValue[1 << MAXN];
vector<int> masks[MAXN + 1];

int getanswer(int length, int position, int friendsCount, int usedMask) {
	if (friendsCount == 4)
		return 1;

	int sumValue = maskValue[masks[length][position]];
	int answer = 0;

	for (int i = position + 1; i < (int) masks[length].size(); i++) {
		int mask = masks[length][i];
		if (maskValue[mask] == sumValue && ((usedMask & mask) == 0))
			answer += getanswer(length, i, friendsCount + 1, usedMask | mask);
	}

	for (int newLength = length + 1; newLength <= n; newLength++) {
		for (int i = 0; i < (int) masks[newLength].size(); i++) {
			int mask = masks[newLength][i];
			if (maskValue[mask] == sumValue && ((usedMask & mask) == 0))
				answer += getanswer(newLength, i, friendsCount + 1, usedMask | mask);
		}
	}

	return answer;
}

int main() {
	freopen("choco.in", "r", stdin);
	freopen("choco.out", "w", stdout);

	cin >> n;
	for (int i = 0; i < n; i++)
		cin >> value[i];
	for (int i = 0; i < (1 << n); i++) {
		int maskLenght = 0;
		for (int j = 0; j < n; j++)
			if ((i & (1 << j)) != 0) {
				maskValue[i] += value[j];
				maskLenght++;
			}
		masks[maskLenght].push_back(i);
	}

	int answer = 0;
	for (int length = 1; length <= n / 4; length++)
		for (int i = 0; i < (int) masks[length].size(); i++)
			answer += getanswer(length, i, 1, masks[length][i]);

	cout << answer * 24 << endl;

	return 0;
}
