#include <cstdio>
#include <algorithm>
#include <cmath>

using namespace std;

#define y1 y352435
#define y2 y542345

const double eps = 1e-6;

int x[4], y[4], xx[3], yy[3], p[3];
int x1[6], y1[6], x2[6], y2[6];
double xc[36], yc[36];

int cross (double x1, double y1, double x2, double y2, double x3, double y3, double x4, double y4, double *tx, double *ty) {
	double a = x2 - x1;
	double b = x3 - x4;
	double c = x3 - x1;
	double d = y2 - y1;
	double e = y3 - y4;
	double f = y3 - y1;
	if (fabs (a * e - b * d) > eps) {
		double t = (c * e - b * f) / (a * e - b * d);
		double s = (a * f - c * d) / (a * e - b * d);
		if (t > -eps && t < 1 + eps && s > -eps && s < 1 + eps) {
			*tx = x1 + (x2 - x1) * t;
			*ty = y1 + (y2 - y1) * t;
			return 1;
		}	
	}
	return 0;
}

double vect (double x1, double y1, double x2, double y2) {
	return x1 * y2 - x2 * y1;
}

int _in (double x, double y, double x1, double y1, double x2, double y2, double x3, double y3) {
	double v1 = vect (x1 - x, y1 - y, x2 - x, y2 - y);
	double v2 = vect (x2 - x, y2 - y, x3 - x, y3 - y);
	double v3 = vect (x3 - x, y3 - y, x1 - x, y1 - y);
	if (v1 > -eps && v2 > -eps && v3 > -eps || v1 < eps && v2 < eps && v3 < eps) return 1;
	return 0;
}

int check (double xc, double yc) {
	 for (int i = 0; i < 3; i++) 
	 	if (_in (xc, yc, xx[i], yy[i], x[p[i]], y[p[i]], x[p[i] + 1], y[p[i] + 1]))
	 		return 1;
	return 0;
}

int main () {
	freopen ("light.in", "r", stdin);
	freopen ("light.out", "w", stdout);
	int tt;
	scanf ("%d", &tt);
	for (int it = 0; it < tt; it++) {
		for (int i = 0; i < 3; i++) scanf ("%d%d", &x[i], &y[i]);
		x[3] = x[0];
		y[3] = y[0];
		for (int i = 0; i < 3; i++) scanf ("%d%d", &xx[i], &yy[i]);
		for (int i = 0; i < 3; i++) p[i] = i;
		do {
			int o = 0;
			for (int i = 0; i < 3; i++) {
				xc[o] = xx[i];
				yc[o] = yy[i];
				o++;
				xc[o] = x[i];
				yc[o] = y[i];
				o++;
			}
			int good = 1;
			for (int i = 0; i < o; i++) 
				for (int j = i + 1; j < o; j++) {
					if (!check ((xc[i] + xc[j]) / 2, (yc[i] + yc[j]) / 2)) good = 0;
					for (int k = j + 1; k < o; k++)
						if (!check ((xc[i] + xc[j] + xc[k]) / 3, (yc[i] + yc[j] + yc[k]) / 3))
							good = 0;
				}
			if (good) {
				for (int i = 0; i < 3; i++) printf ("%d ", p[i] + 1);
				printf ("\n");
				break;
			}
		} while (next_permutation (p, p + 3));
	}	
}