#include <cstdio>
#include <iostream>
#include <vector>

using namespace std;

#define MAXN 16
#define MAX_WEIGHT 1001

vector<int> v[MAXN*MAX_WEIGHT];
int         w[MAXN];
int         n, N, K;
int         sum[1 << MAXN];
long long   ans[MAXN][1 << MAXN];


int main()
{
  freopen("choco.in", "r", stdin);
  freopen("choco.out", "w", stdout);
  memset(sum, 0, sizeof(sum));
  memset(ans, 0, sizeof(ans));

  scanf("%i %i", &n, &K);
  for(int i=0; i<n; ++i) scanf("%i", &w[i]);

  N = 1 << n;
  for(int i=1; i<N; ++i)
  {
    for(int j=0; j<n; ++j) if ((i >> j)&1) sum[i] += w[j];
    v[sum[i]].push_back(i);
    ans[1][i] = 1;
  }

  for(int k=2; k<=K; ++k)
    for(int i=1; i<N; ++i)
      if (sum[i] % k == 0)
      {
        int x = sum[i] / k;
        for(int j=0; j<v[x].size(); ++j) if ((i & v[x][j]) == v[x][j]) ans[k][i] += ans[k-1][i - v[x][j]];
      }

  long long total_ans = 0;
  for(int i=1; i<N; ++i) total_ans += ans[K][i];
  printf("%I64d\n", total_ans);
}