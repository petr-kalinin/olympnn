#include <iostream>
#include <vector>
#include <string>
#include <cstdio>
#include <algorithm>
#include <cstdlib>
#include <cmath>

using namespace std;

#define LL long long

const int maxn = 1005;
const int inf = 1e9;

int dp[maxn][maxn];
int n, P, Q, m;
int b[maxn];
int a[maxn];

int main()
{
	freopen("schedule.in", "r", stdin);
	freopen("schedule.out", "w", stdout);
	scanf("%d%d%d%d", &n, &m, &P, &Q);
	int q;
	for (q = 1; q <= n; q++)
		scanf("%d", &a[q]);
	sort(a + 1, a + n + 1);
	for (q = 1; q <= m; q++)
		scanf("%d", &b[q]);
	sort(b + 1, b + m + 1);
	
	for (int i = 0; i <= n; i++)
		for (int j = 0; j <= m; j++)
			dp[i][j] = inf;
	dp[0][0] = 0;
	for (int i = 0; i < n; i++)
		for (int j = 0; j <= m; j++) if (dp[i][j] != inf)
		{
			for (int choice = j + 1, to_add = dp[i][j]; choice <= m; choice++, to_add += Q)
				dp[i + 1][choice] = min(dp[i + 1][choice], to_add + abs(a[i + 1] - b[choice]));
			dp[i + 1][j] = min(dp[i + 1][j], dp[i][j] + P);
		}
	int answer = inf;
	for (int choice = 0; choice <= m; choice++)
		answer = min(answer, dp[n][choice] + (m - choice) * Q);
	printf("%d", answer);
}