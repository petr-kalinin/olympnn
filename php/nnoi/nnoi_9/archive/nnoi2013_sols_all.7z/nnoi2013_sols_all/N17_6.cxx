//Nikolay Kalinin, Liceum 40, 10F, problem 6, GNU C++

#include <iostream>
#include <cstdio>
#include <cstdlib>
#include <vector>
#include <cmath>
#include <algorithm>
#include <cassert>
#include <cstring>

using namespace std;

typedef long long ll;
typedef long double ld;

#define TASKNAME "rummikub"

const int maxmask = (1 << 16) + 5;

int last[15][4][2];
int next[15][4][2];
int wh[4][2];
int waswh[15][4][2];
vector<pair<int, int> > curanswer[200];
bool was[15][maxmask];
int kv[15][4];
int n;
char card[10];
vector<pair<int, int> > c1[15];
vector<pair<int, int> > c2[15];
int curkans;

inline bool bad(int x)
{
	return (x == 1) || (x == 2);
}

inline int getmaskone(int m[2])
{
	return m[1] * 4 + m[0];
}

inline void putmaskone(int mask, int m[2])
{
	m[0] = mask % 4;
	m[1] = mask / 4;
}

inline int getmask(int m[4][2])
{
	int ans = 0;
	int cur = 1;
	for (int i = 0; i < 4; i++)
	{
		ans += cur * getmaskone(m[i]);
		cur *= 16;
	}
	return ans;
}

inline void putmask(int mask, int m[4][2])
{
	for (int i = 0; i < 4; i++)
	{
		putmaskone(mask % 16, m[i]);
		mask /= 16;
	}
}

void go(int cur, int mask);

void goinone(int cur, int lvl)
{
	if (cur == 4)
	{
//		cout << "try end level with " << c1[lvl].size() << ' ' << c2[lvl].size() << endl;
		if (bad(c1[lvl].size()) || bad(c2[lvl].size())) return;
		if (c1[lvl].size() > 0)
		{
			curanswer[curkans++] = c1[lvl];
		}
		if (c2[lvl].size() > 0)
		{
			curanswer[curkans++] = c2[lvl];
		}
//		cout << "do it" << endl;
		go(lvl + 1, getmask(next[lvl]));
		if (c1[lvl].size() > 0)
		{
			curkans--;
		}
		if (c2[lvl].size() > 0)
		{
			curkans--;
		}
		return;
	}
	if (kv[lvl][cur] == 0)
	{
		if (bad(last[lvl][cur][0]) || bad(last[lvl][cur][1])) return;
		next[lvl][cur][0] = 0;
		next[lvl][cur][1] = 0;
		wh[cur][0] = -1;
		wh[cur][1] = -1;
		goinone(cur + 1, lvl);
		wh[cur][0] = waswh[lvl][cur][0];
		wh[cur][1] = waswh[lvl][cur][1];
	} else if (kv[lvl][cur] == 1)
	{
		if (!bad(last[lvl][cur][0]) && !bad(last[lvl][cur][1]))
		{
			next[lvl][cur][0] = 0;
			next[lvl][cur][1] = 0;
			wh[cur][0] = -1;
			wh[cur][1] = -1;
			c1[lvl].push_back(make_pair(lvl, cur));
			goinone(cur + 1, lvl);
			c1[lvl].pop_back();
			c2[lvl].push_back(make_pair(lvl, cur));
			goinone(cur + 1, lvl);
			c2[lvl].pop_back();
			wh[cur][0] = waswh[lvl][cur][0];
			wh[cur][1] = waswh[lvl][cur][1];
		}
		if (!bad(last[lvl][cur][0]))
		{
			if (last[lvl][cur][1] == 0)
			{
				wh[cur][1] = curkans;
				curanswer[curkans].resize(0);
				curkans++;
			}
			curanswer[wh[cur][1]].push_back(make_pair(lvl, cur));
			next[lvl][cur][1] = min(3, last[lvl][cur][1] + 1);
			next[lvl][cur][0] = 0;
			wh[cur][0] = -1;
			goinone(cur + 1, lvl);
			curanswer[wh[cur][1]].pop_back();
			if (last[lvl][cur][1] == 0)
			{
				curkans--;
			}
			wh[cur][0] = waswh[lvl][cur][0];
			wh[cur][1] = waswh[lvl][cur][1];
		}
		if (!bad(last[lvl][cur][1]))
		{
			if (last[lvl][cur][0] == 0)
			{
				wh[cur][0] = curkans;
				curanswer[curkans].resize(0);
				curkans++;
			}
			curanswer[wh[cur][0]].push_back(make_pair(lvl, cur));
			next[lvl][cur][0] = min(3, last[lvl][cur][0] + 1);
			next[lvl][cur][1] = 0;
			wh[cur][1] = -1;
			goinone(cur + 1, lvl);
			curanswer[wh[cur][0]].pop_back();
			if (last[lvl][cur][0] == 0)
			{
				curkans--;
			}
			wh[cur][0] = waswh[lvl][cur][0];
			wh[cur][1] = waswh[lvl][cur][1];
		}
	} else //2
	{
		if (!bad(last[lvl][cur][0]) && !bad(last[lvl][cur][1]))
		{
			next[lvl][cur][0] = 0;
			next[lvl][cur][1] = 0;
			wh[cur][0] = -1;
			wh[cur][1] = -1;
			c1[lvl].push_back(make_pair(lvl, cur));
			c2[lvl].push_back(make_pair(lvl, cur));
			goinone(cur + 1, lvl);
			goinone(cur + 1, lvl);
			c1[lvl].pop_back();
			c2[lvl].pop_back();
			wh[cur][0] = waswh[lvl][cur][0];
			wh[cur][1] = waswh[lvl][cur][1];
		}
		if (!bad(last[lvl][cur][0]))
		{
			if (last[lvl][cur][1] == 0)
			{
				wh[cur][1] = curkans;
				curanswer[curkans].resize(0);
				curkans++;
			}
			curanswer[wh[cur][1]].push_back(make_pair(lvl, cur));
			next[lvl][cur][1] = min(3, last[lvl][cur][1] + 1);
			next[lvl][cur][0] = 0;
			wh[cur][0] = -1;
			c1[lvl].push_back(make_pair(lvl, cur));
			goinone(cur + 1, lvl);
			c1[lvl].pop_back();
			c2[lvl].push_back(make_pair(lvl, cur));
			goinone(cur + 1, lvl);
			c2[lvl].pop_back();
			curanswer[wh[cur][1]].pop_back();
			if (last[lvl][cur][1] == 0)
			{
				curkans--;
			}
			wh[cur][0] = waswh[lvl][cur][0];
			wh[cur][1] = waswh[lvl][cur][1];
		}
		if (!bad(last[lvl][cur][1]))
		{
			if (last[lvl][cur][0] == 0)
			{
				wh[cur][0] = curkans;
				curanswer[curkans].resize(0);
				curkans++;
			}
			curanswer[wh[cur][0]].push_back(make_pair(lvl, cur));
			next[lvl][cur][0] = min(3, last[lvl][cur][0] + 1);
			next[lvl][cur][1] = 0;
			wh[cur][1] = -1;
			c1[lvl].push_back(make_pair(lvl, cur));
			goinone(cur + 1, lvl);
			c1[lvl].pop_back();
			c2[lvl].push_back(make_pair(lvl, cur));
			goinone(cur + 1, lvl);
			c2[lvl].pop_back();
			curanswer[wh[cur][0]].pop_back();
			if (last[lvl][cur][0] == 0)
			{
				curkans--;
			}
			wh[cur][0] = waswh[lvl][cur][0];
			wh[cur][1] = waswh[lvl][cur][1];
		}		
		if (last[lvl][cur][0] == 0)
		{
			wh[cur][0] = curkans;
			curanswer[curkans].resize(0);
			curkans++;
		}
		if (last[lvl][cur][1] == 0)
		{
			wh[cur][1] = curkans;
			curanswer[curkans].resize(0);
			curkans++;
		}
		curanswer[wh[cur][0]].push_back(make_pair(lvl, cur));
		curanswer[wh[cur][1]].push_back(make_pair(lvl, cur));
		next[lvl][cur][0] = min(3, last[lvl][cur][0] + 1);
		next[lvl][cur][1] = min(3, last[lvl][cur][1] + 1);
		goinone(cur + 1, lvl);
		curanswer[wh[cur][0]].pop_back();
		curanswer[wh[cur][1]].pop_back();
		if (last[lvl][cur][0] == 0)
		{
			curkans--;
		}
		if (last[lvl][cur][1] == 0)
		{
			curkans--;
		}
		wh[cur][0] = waswh[lvl][cur][0];
		wh[cur][1] = waswh[lvl][cur][1];
	}
}

void go(int cur, int mask)
{
	if (cur == 14)
	{
//		answer found!
		printf("%d\n", curkans);
		for (int i = 0; i < curkans; i++)
		{
			printf("%d", curanswer[i].size());
			for (int j = 0; j < curanswer[i].size(); j++) printf(" %c%d", (char)('A' + curanswer[i][j].second), curanswer[i][j].first + 1);
			printf("\n");
		}
		exit(0);
		return;
	}
	if (was[cur][mask]) return;
	was[cur][mask] = true;
	for (int i = 0; i < 4; i++)
	{
		for (int j = 0; j < 2; j++) waswh[cur][i][j] = wh[i][j];
	}
	putmask(mask, last[cur]);
//	cout << "try " << cur << ' ' << mask << ":" << endl;
//	for (int i = 0; i < 4; i++)
//	{
//		cout << i << ": " << last[cur][i][0] << ' ' << last[cur][i][1] << endl;
//	}
	c1[cur].resize(0);
	c2[cur].resize(0);
	goinone(0, cur);
	for (int i = 0; i < 4; i++)
	{
		for (int j = 0; j < 2; j++) wh[i][j] = waswh[cur][i][j];
	}
}

int main()
{
	freopen(TASKNAME ".in", "r", stdin);
	freopen(TASKNAME ".out", "w", stdout);
	scanf("%d", &n);
	memset(kv, 0, sizeof(kv));
	for (int i = 0; i < n; i++)
	{
		scanf("%s", card);
		int c = card[0] - 'A';
		int lvl;
		assert(sscanf(card + 1, "%d", &lvl) == 1);
		lvl--;
		kv[lvl][c]++;
	}
	curkans = 0;
	memset(wh, 0, sizeof(wh));
	memset(was, false, sizeof(was));
	go(0, 0);
	printf("-1\n");
	return 0;
}