#include <algorithm>
#include <fstream>
using namespace std;
fstream cin("paint.in");
ofstream cout("paint.out");
int two(int k){
    int p=0;
    while(k%2==0){
        k/=2;
        p++;
    }
    return p;
}
int main(){
    int l,r,ans=0;
    cin>>l>>r;
    for(int i=l;i<=r;i++)
        if(i%2==0)
            ans+=two(i);
    cout<<ans;
    return 0;
}
