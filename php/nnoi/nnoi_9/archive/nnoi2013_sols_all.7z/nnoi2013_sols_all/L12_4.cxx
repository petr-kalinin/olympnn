#include <fstream>
using namespace std;
inline long tw(long a){if(!a) return 1; else if(a==1) return 2; else return tw(a-1)*2;}
inline long mt(long a){long i; for(i=0;a>tw(i);i++); return i;}
int main()
{
    ifstream in("testing.in");
    long n; in>>n;
    const long min=mt(n);
    bool a[min][n]; for(long i=0;i<min;i++) for(long j=0;j<n;j++) a[i][j]=0;
    for(long i=1;i<n;i++)
    {
        for(long j=0;j<n;j++) a[j][i]=a[j][i-1];
        long k; for(k=0;a[k][i]&&k<min;k++) a[k][i]=0; a[k][i]=1;
    }
    ofstream out("testing.out");
    out<<min<<'\n';
    for(long i=0;i<min;i++){ long s=0; for(long j=0;j<n;j++) s+=!a[i][j]; out<<s<<' ';  for(long j=0;j<n;j++) if(!a[i][j]) out<<j+1<<' '; out<<'\n';}
    in.close();
    out.close();
    return 0;
}
