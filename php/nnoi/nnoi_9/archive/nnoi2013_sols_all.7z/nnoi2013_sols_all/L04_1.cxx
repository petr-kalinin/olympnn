#include <algorithm>
#include <fstream>
using namespace std;
fstream cin("schedule.in");
ofstream cout("schedule.out");
int abs(int k){
    if(k>0)
        return k;
    else
        return -1*k;
}

int main(){
    int n,m,p,q,ai[100000],bj[100000],ans=0;
    cin>>n>>m>>p>>q;
    for(int i=0;i<n;i++)
        cin>>ai[i];
    for(int i=0;i<m;i++)
        cin>>bj[i];
    sort(ai,ai+n);
    sort(bj,bj+m);
    int f=min(n,m);
    bool full=false;
    if(m>n)
        ans+=(m-n)*q;
    if(n>=m){
        full=true;
        ans+=(n-m)*p;
    }
    for(int i=0;i<f;i++){
        int now=abs(ai[i]-bj[i]);
        if(full==true and now>p){
            ans+=p;
            ai[i]=0;
            sort(ai,ai+n);
        }
        else if(full==false and now>q){
            ans+=q;
            bj[i]=0;
            sort(bj,bj+m);
        }
        else
            ans+=now;
    }
    cout<<ans;
    return 0;
}
