/*
Artem Smirnov <u01>
GNU C++ 4.6.2
*/

#include<fstream>
#include<vector>
#include<algorithm>

using namespace std;

bool sortf ( pair<int, pair<int, int> > a,  pair<int, pair<int, int> > b) {
    return a.first < b.first;
}

int main () {
    ifstream cin("schedule.in");
    ofstream cout("schedule.out");

    int n,m,p,q;
    cin >> n >> m >> p >> q;

    int *a = new int[n];
    bool *ua = new bool[n];
    int *b = new int[m];
    bool *ub = new bool[m];

    for (int i=0 ; i<n ; i++) {
        cin >> a[i];
        ua[i] = false;
    }

    for (int j=0 ; j<m; j++) {

        cin >> b[j];
        ub[j] = false;
    }

    pair<int, pair<int, int> > *pairs = new pair<int, pair<int, int> >[n*m];

    for (int i=0 ; i<n ; i++) {
        for (int j=0 ; j<m ; j++) {
            pairs[i*m+j] = make_pair(abs(a[i]-b[j]), make_pair(i,j));
        }
    }

    sort(pairs, pairs+n*m, sortf);

    long s = 0;
    if (m>n) s+=(m-n)*q;
    if (n>m) s+=(n-m)*p;

    int t = min(n, m);
    int i=0;
    int o=0;
    bool next = true;
    while (next && o<t) {
        for (; i<n*m ; i++) {
            if (pairs[i].first > p+q) {
                next = false;
                break;
            } else {
                if (ua[pairs[i].second.first] || ub[pairs[i].second.second]) continue;
                s += pairs[i].first;
                ua[pairs[i].second.first] = true;
                ub[pairs[i].second.second] = true;
                o++;
            }

        }
    }

    s += (p+q)*(t-o);
    cout << s;

    cin.close();
    cout.close();

    return 0;
}
