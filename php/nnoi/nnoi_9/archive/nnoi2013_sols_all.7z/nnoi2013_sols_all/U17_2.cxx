#include <iostream>
#include <vector>
#include <string>
#include <cstdio>
#include <algorithm>
#include <cstdlib>
#include <cmath>

using namespace std;

#define LL long long

int n;

int main()
{
	freopen("holidays.in", "r", stdin);
	freopen("holidays.out", "w", stdout);
	scanf("%d", &n);
	int cur = 0;
	for (int j = 1; j <= n; j++)
	{
		int x;
		scanf("%d", &x);
		cur += x;
		if (cur > 0)
		{
			printf("+ ");
			cur--;
		}
		else printf("- ");
	}
	for (int j = 1; j <= cur; j++)
		printf("+ ");
}