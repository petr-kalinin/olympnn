#include <algorithm>
#include <fstream>
using namespace std;
fstream cin("holidays.in");
ofstream cout("holidays.out");
int main(){
    int n, mas[100010],plus=0;
    cin>>n;
    for(int i=0;i<n;i++)
        cin>>mas[i];
    for(int i=0;i<n;i++){
     if(mas[i]>1){
        for(int j=i;j<n;j++)
            if(mas[j]==0 and mas[i]>1){
                mas[j]++;
                mas[i]--;
            }
      plus+=mas[i]-1;
     }
    }
    for(int i=0;i<n;i++){
        if(mas[i]>=1)
            cout<<"+"<<' ';
        else
            cout<<"-"<<' ';
    }
    while(plus--){
    cout<<"+"<<' ';
    }
    return 0;
}
