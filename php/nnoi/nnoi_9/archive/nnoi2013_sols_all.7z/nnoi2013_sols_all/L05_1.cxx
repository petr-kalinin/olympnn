#include <iostream>
#include <cstdio>
#include <cstdlib>


using namespace std;

#define SIZE 10;

void Sort (int mas[], int);



int main()
{
  FILE *buf, *bufo;

int massiv[100];
int a,b,c,m,n,p,q;


  buf=fopen ("schedule.in","r");

 fscanf(buf,"%d %d %d %d \n %d", &a,&b,&p,&q);

  fclose (buf);



 bufo=fopen("schedule.out", "w");
fprintf (bufo, "%d", a);
  fclose (bufo);






  return 0;

}

void Sort (int mas[SIZE], int vibor)

{
for (int=0; i< SIZE-1;++i)
{
int tmp=0;

for (int j=(i+1); j<SIZE;++j)
if (vibor*mas[i]<vibor*mas[j])
{
    tmp=mas[i];
    mas[i]mas[j];
mas[j]=tmp;

}
}
}

