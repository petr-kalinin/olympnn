#include <iostream>
#include <cstdio>
#include <cstdlib>

using namespace std;

unsigned int result=0;

 unsigned int rekurs( unsigned int aa, unsigned int result2)

{

 if (  (aa % (result2*2)) ==0  )
{

result=result + 1;
if ( (aa % (result2*4) ) == 0 and aa >= (result2*4) )

{


result2=result2 *2;

 rekurs( aa, result2);
}




 }


 return  result;
}





int main()
{
  FILE *buf, *bufo;

   unsigned int a,b,c,answer,tempPlus;


  buf=fopen ("paint.in","r");
  fscanf(buf, "%d %d", &a,&b);

  fclose (buf);


for ( int i=a; i< b+1;i++)
{

rekurs(i,1);

}


//answer=rekurs(4,1);

 bufo=fopen("paint.out", "w");
fprintf (bufo, "%d", result);
  fclose (bufo);





  return 0;

  //  return 0;
}
