//Nikolay Kalinin, Liceum 40, 10F, problem 1, GNU C++

#include <iostream>
#include <cstdio>
#include <cstdlib>
#include <vector>
#include <cmath>
#include <algorithm>

using namespace std;

typedef long long ll;
typedef long double ld;

#define TASKNAME "schedule"

const int maxn = 1005;
const int inf = 1e9;

int a[maxn], b[maxn], ans[maxn][maxn];
int n, m, p, q;

int main()
{
	freopen(TASKNAME ".in", "r", stdin);
	freopen(TASKNAME ".out", "w", stdout);
	scanf("%d%d%d%d", &n, &m, &p, &q);
	for (int i = 0; i < n; i++) scanf("%d", &a[i]);
	for (int i = 0; i < m; i++) scanf("%d", &b[i]);
	sort(a, a + n);
	sort(b, b + m);
	for (int i = 0; i <= n; i++)
	{
		for (int j = 0; j <= m; j++) ans[i][j] = inf;
	}
	ans[0][0] = 0;
	for (int i = 0; i <= n; i++)
	{
		for (int j = 0; j <= m; j++)
		{
			ans[i + 1][j + 1] = min(ans[i + 1][j + 1], ans[i][j] + abs(a[i] - b[j]));
			ans[i + 1][j] = min(ans[i + 1][j], ans[i][j] + p);
			ans[i][j + 1] = min(ans[i][j + 1], ans[i][j] + q);
		}
	}
	printf("%d\n", ans[n][m]);
	return 0;
}