#include <fstream>
using namespace std;
int main()
{
    ifstream in("http.in");
    int n; in>>n;
    ofstream out("http.out");
    for(int i=0;i<n-1;i+=2) out<<"LW";
    if(n%2) out<<'W';
    in.close();
    out.close();
    return 0;
}
