//Nikolay Kalinin, Liceum 40, 10F, problem 4, GNU C++

#include <iostream>
#include <cstdio>
#include <cstdlib>
#include <vector>
#include <cmath>
#include <algorithm>

using namespace std;

typedef long long ll;
typedef long double ld;

#define TASKNAME "testing"

const int maxn = 100005;

int n;
int curtest[maxn];

int main()
{
	freopen(TASKNAME ".in", "r", stdin);
	freopen(TASKNAME ".out", "w", stdout);
	scanf("%d", &n);
	int cur = 1;
	int kv = 0;
	while (cur < n)
	{
		cur *= 2;
		kv++;
	}
	printf("%d\n", kv);
	for (int i = 0; i < kv; i++)
	{
		int curkv = 0;
		for (int j = 0; j < n; j++) if ((j & (1 << i)) == 0) curtest[curkv++] = j;
		printf("%d", curkv);
		for (int j = 0; j < curkv; j++) printf(" %d", curtest[j] + 1);
		printf("\n");
	}
	return 0;
}