//Nikolay Kalinin, Liceum 40, 10F, problem 5, GNU C++

#include <iostream>
#include <cstdio>
#include <cstdlib>
#include <vector>
#include <cmath>
#include <algorithm>

using namespace std;

typedef long long ll;
typedef long double ld;

#define TASKNAME "paint"

int main()
{
	freopen(TASKNAME ".in", "r", stdin);
	freopen(TASKNAME ".out", "w", stdout);
	ll l, r;
	cin >> l >> r;
	l--;
	ll answer = 0;
	for (ll cur = 2; cur <= r; cur *= 2)
	{
		answer += r / cur - l / cur;
	}
	cout << answer << endl;
	return 0;
}