#include <fstream>
using namespace std;
inline long long tw(long long n)
{
    if(!n) return 1; else
    if(n==1) return 2; else
    return tw(n-1)*2;
}
inline long mt(long long a){long long i; for(i=0;a>tw(i);i++); return i;}
inline long long get(long long n);
int main()
{
    ifstream in("paint.in");
    long long l,r; in>>l>>r;
    long long s=0;
    for(long long i=l;i<=r;i++) s+=get(i);
    ofstream out("paint.out");
    out<<s;
    in.close();
    out.close();
    return 0;
}
inline long long get(long long n)
{
    long long int x;
    for(x=0;!(n%tw(x));x++);
    return x-1;
}
