#include <iostream>
#include <vector>
#include <string>
#include <cstdio>
#include <algorithm>
#include <cstdlib>
#include <cmath>

using namespace std;

#define LL long long

const int maxn = 200;

pair <int, int> ans[maxn][20];
int cnt[4][20];
int n, uniq;
pair <int, int> list[maxn];

void solve(int step, int left, int groups)
{
	if (left == 0)
	{
		printf("%d\n", groups);
		for (int g = 1; g <= groups; g++)
		{
			printf("%d ", ans[g][0].first);
			for (int j = 1; j <= ans[g][0].first; j++)
				printf("%c%d ", ans[g][j].first + 'A', ans[g][j].second);
			printf("\n");
		}
		exit(0);
	}
	if (left < 3 || step == uniq + 1)
		return;
	int first = list[step].first;
	int second = list[step].second;
	if (cnt[first][second] == 0)
	{
		solve(step + 1, left, groups);
		return;
	}

	bool fail = false;
	for (int i = 0; i <= 3; i++)
		if (cnt[i][second] == 0)
		{
			fail = true;
			break;
		}
	if (!fail)
	{
		ans[groups + 1][0].first = 4;
		for (int i = 0; i <= 3; i++)
		{
			cnt[i][second]--;
			ans[groups + 1][i + 1] = make_pair(i, second);
		}
		solve(step, left - 4, groups + 1);
		for (int i = 0; i <= 3; i++)
			cnt[i][second]++;
	}
	for (int choice = 0; choice <= 3; choice++)
	{
		fail = false;
		for (int i = 0; i <= 3; i++)
			if (cnt[i][second] == 0 && i != choice)
			{
				fail = true;
				break;
			}
		if (fail)
			continue;

		int now = 1;
		ans[groups + 1][0].first = 3;
		for (int i = 0; i <= 3; i++) if (i != choice)
		{
			cnt[i][second]--;
			ans[groups + 1][now] = make_pair(i, second);
			now++;
		}
		solve(step, left - 3, groups + 1);
		for (int i = 0; i <= 3; i++) if (i != choice)
			cnt[i][second]++;
	}

	if (cnt[first][second + 1] != 0)
	{
		cnt[first][second]--;
		cnt[first][second + 1]--;

		ans[groups + 1][1] = make_pair(first, second);
		ans[groups + 1][2] = make_pair(first, second + 1);
		for (int bound = second + 2; bound <= 13; bound++)
		{
			if (cnt[first][bound] == 0)
			{
				for (int g = bound - 1; g >= second + 2; g--)
					cnt[first][g]++;
				break;
			}
			ans[groups + 1][bound - second + 1] = make_pair(first, bound);
			cnt[first][bound]--;
			ans[groups + 1][0].first = bound - second + 1;
			solve(step, left - (bound - second + 1), groups + 1);
		}

		cnt[first][second]++;
		cnt[first][second + 1]++;
	}
}

int main()
{
	freopen("rummikub.in", "r", stdin);
	freopen("rummikub.out", "w", stdout);
	scanf("%d", &n);
	int q;
	for (q = 1; q <= n; q++)
	{
		string s;
		int number;
		cin >> s;
		if (s.length() == 2)
			number = s[1] - '0';
		else number = s[2] - '0' + (s[1] - '0') * 10;
		cnt[s[0] - 'A'][number]++;
	}
	uniq = 0;
	for (int i = 0; i <= 3; i++)
		for (int j = 1; j <= 13; j++)
			if (cnt[i][j] != 0)
			{
				uniq++;
				list[uniq] = make_pair(i, j);
			}
	solve(1, n, 0);
	printf("-1");
}