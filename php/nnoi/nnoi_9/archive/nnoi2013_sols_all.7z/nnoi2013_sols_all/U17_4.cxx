#include <iostream>
#include <vector>
#include <string>
#include <cstdio>
#include <algorithm>
#include <cstdlib>
#include <cmath>

using namespace std;

#define LL long long

const int max_comp = 30;

int n;
vector <int> list[max_comp];

int main()
{
	freopen("testing.in", "r", stdin);
	freopen("testing.out", "w", stdout);
	scanf("%d", &n);
	int ans = 0;
	int p = 1;
	while (p < n)
	{
		ans++;
		p *= 2;
	}
	for (int choice = 1; choice <= n; choice++)
	{
		int cur = choice - 1;
		for (int comp = ans; comp >= 1; comp--)
		{
			if (cur % 2 == 0)
				list[comp].push_back(choice);
			cur /= 2;
		}
	}
	printf("%d\n", ans);
	for (int comp = 1; comp <= ans; comp++)
	{
		printf("%d ",list[comp].size());
		for (int j = 0; j < list[comp].size(); j++)
			printf("%d ", list[comp][j]);
		printf("\n");
	}
}