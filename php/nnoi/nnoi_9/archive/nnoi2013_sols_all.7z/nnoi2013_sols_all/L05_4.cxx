#include <iostream>
#include <cstdio>
#include <cstdlib>

using namespace std;




int main()
{
  FILE *buf, *bufo;

   unsigned int a,b,c,answer,tempPlus,result,int2;


  buf=fopen ("testing.in","r");
  fscanf(buf, "%d", &a);

  fclose (buf);


result=a-2;

 bufo=fopen("testing.out", "w");

 fprintf (bufo, "%d\n", result);

int g;
for (int i=0; i <= result;i++)

{


  g=i+1;

   for (int i2=1; i2!=result+1;i2++)

{

    if (int2 !=g or int2 !=1)
    {
        fprintf (bufo, "%d ", int2);
    }



}
fprintf (bufo, "%d", "\n");
}

  fclose (bufo);





  return 0;

}
