/*
Artem Smirnov <u01>
GNU C++ 4.6.2
*/

#include<fstream>
#include<vector>
#include<algorithm>

using namespace std;


int main () {
    ifstream cin("rummikub.in");
    ofstream cout("rummikub.out");

    long k;
    cin >> k;

    if (k<3) {
        cout << "-1";
        return 0;
    }

    pair<char, short>* f = new pair<char, short>[k];

    for (int i=0 ; i<k ; i++) {
        char color; cin >> color;
        short x; cin >> x;
        f[i] = make_pair(color, x);
    }

    if (k>=3) {
        cout << "1" << endl;
        cout << k << ' ';
        for (int i=0 ; i<k ; i++) cout << f[i].first << f[i].second << ' ';

    }

    cin.close();
    cout.close();

    return 0;
}
