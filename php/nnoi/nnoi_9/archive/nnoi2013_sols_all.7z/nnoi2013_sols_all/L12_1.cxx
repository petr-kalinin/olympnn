#include <fstream>
using namespace std;
inline int abs(int n)
{
    if(n+1) return n; else return -n;
}
int main()
{
    ifstream in("schelude.in");
    int n,m,p,q,i=0; in>>n>>m>>p>>q;
    int a[1000]={0},b[1000]={0}; for(i=0;i<n;i++) in>>a[i]; for(i=0;i<m;i++) in>>b[i];
    int l=0;
    if(n==m)
    {
        for(i=0;i<n;i++) l+=abs(a[i]-b[i]);
    }
    else if(n>m) l=(n-m)*p;
    else l=(m-n)*q;
    in.close();
    ofstream out("schelude.out");
    out<<l;
    out.close();
    return 0;
}
