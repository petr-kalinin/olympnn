#include <iostream>
#include <vector>
#include <string>
#include <cstdio>
#include <algorithm>
#include <cstdlib>
#include <cmath>

using namespace std;

#define LL long long

LL L, R;

int main()
{
	freopen("paint.in", "r", stdin);
	freopen("paint.out", "w", stdout);
	cin >> L >> R;
	LL answer = 0;
	LL p = 2;
	while(p <= R)
	{
		LL tmp = R / p;
		LL right_bound = tmp * p;
		if (right_bound < L || right_bound > R)
			continue;
		LL left_bound = (L % p == 0 ? L : (L / p + 1) * p);
		if (left_bound < L || left_bound > R || left_bound > right_bound)
			continue;

		LL to_add = ((right_bound - left_bound) / p + 1);
		answer += to_add;

		p *= 2;
	}
	cout << answer;
}