/*
Artem Smirnov <u01>
GNU C++ 4.6.2
*/

#include<fstream>
#include<vector>
#include<algorithm>

using namespace std;


int main () {
    ifstream cin("holidays.in");
    ofstream cout("holidays.out");

    long n, h=0;

    cin >> n;

    for (long i=0 ; i<n ; i++) {
        long hi; cin >> hi;
        h+=hi;
        if (h > 0) {
            cout << '+';
            h--;
        } else {
            cout << '-';
        }
    }
    for (long i=0 ; i<h ; i++)cout << '+';

    cin.close();
    cout.close();

    return 0;
}
