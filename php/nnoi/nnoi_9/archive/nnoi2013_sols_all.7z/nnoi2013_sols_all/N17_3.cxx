//Nikolay Kalinin, Liceum 40, 10F, problem 3, GNU C++

#include <iostream>
#include <cstdio>
#include <cstdlib>
#include <vector>
#include <cmath>
#include <algorithm>
#include <cassert>

using namespace std;

typedef long long ll;
typedef long double ld;

#define TASKNAME "http"

const int maxn = 100005;

int a[maxn], b[maxn];
vector<int> gr[maxn];
bool was[maxn];
int c[maxn];
int n, m;

void go(int cur, int curc)
{
	if (was[cur])
	{
//		assert(c[cur] == curc);
		return;
	}
	was[cur] = true;
	c[cur] = curc;
	for (int i = 0; i < gr[cur].size(); i++) go(gr[cur][i], 1 - curc);
}

int main()
{
	freopen(TASKNAME ".in", "r", stdin);
	freopen(TASKNAME ".out", "w", stdout);
	scanf("%d", &n);
	for (int i = 0; i < n; i++) scanf("%d", &a[i]), a[i]--;
	for (int i = 0; i < n; i++) scanf("%d", &b[i]), b[i]--;
	if (n % 2 == 1)
	{
		a[n] = n;
		b[n] = n;
	}
	m = ((n + 1) / 2) * 2;
	for (int i = 0; i < m; i += 2)
	{
		gr[a[i]].push_back(a[i + 1]);
		gr[b[i]].push_back(b[i + 1]);
		gr[a[i + 1]].push_back(a[i]);
		gr[b[i + 1]].push_back(b[i]);
	}
	for (int i = 0; i < m; i++) if (!was[i])
	{
		go(i, 0);
	}
	for (int i = 0; i < n; i++)
	{
		if (c[i] == 0) printf("L");
		else printf("W");
	}
	printf("\n");
	return 0;
}