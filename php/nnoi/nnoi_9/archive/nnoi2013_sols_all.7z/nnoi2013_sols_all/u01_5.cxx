/*
Artem Smirnov <u01>
GNU C++ 4.6.2
*/

#include<fstream>
#include<vector>
#include<algorithm>

using namespace std;


int main () {
    ifstream cin("paint.in");
    ofstream cout("paint.out");

    unsigned long long int l,r,s;

    s=0;
    cin >> l >> r;
    unsigned long long int d=2;
    while (true) {
        unsigned long long int x = r/d - l/d;
        if (x<=0) break;

        s += x;
        d*=2;
    }

    cout << s;

    cin.close();
    cout.close();

    return 0;
}
