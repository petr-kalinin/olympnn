/*
Artem Smirnov <u01>
GNU C++ 4.6.2
*/

#include<fstream>
#include<vector>
#include<algorithm>

using namespace std;


bool **c;
bool *p;
long m;
long *o;
long cn;

bool pattern (long n) {
    if (n!=0) {
        cn = n;
        delete o;
        o = new long[n];
        for (long i=0 ; i<n ; i++) {
            o[i] = i;
        }
        for (long j=0 ; j<m ; j++) p[j] = j<n;
    } else {
        for (long i=cn-1 ; i>=0 ; i--) {
            if (o[i] < m-1-(cn-1)+i) {
                o[i]++;

                for (long j=i+1 ; j<cn ; j++) {
                    o[j] = o[j-1]+1;
                }

                break;
            }
        }
        if (o[0]!=0) {
            return false;
        }

        for (long j=0 ; j<m ; j++) p[j] = false;
        for (long i=0 ; i<cn ; i++) p[o[i]] = true;
    }
    return true;
}

int main () {
    ifstream cin("testing.in");
    ofstream cout("testing.out");

    long n; cin >> n;

    m=0;
    while ((m+1)*m/2+1 < n) m++;

    cout << m << endl;

    c = new bool*[m];
    for (long i=0 ; i<m ; i++) c[i] = new bool[n];
    p = new bool[m];

    for (long i=0 ; i<m ; i++)
        for(long j=0 ; j<n ; j++)
            c[i][j] = false;

    long ct = 0;
    long i=1;
    while (ct<n) {
        pattern(i);

        do {
            long j;
            for (j=1 ; j<m; j++) {
                if (p[m-j]) break;
            }
            for (long i=0 ; i<j ; i++) {
                for (long y=i ; y<m ; y++) {
                    if (p[y-i]) {
                        c[y][ct] = true;
                    }
                }
                ct++;
            }
        } while(pattern(0));
        i++;
    }

    for (long i=0 ; i<m ; i++) {
        long d=0;
        for (long j=0 ; j<n ; j++) {
            if (c[i][j]) d++;
        }

        cout << d << ' ';
        for (long j=0 ; j<n ; j++) {
            if (c[i][j]) cout << j+1 << ' ';
        }
        cout << endl;
    }

    cin.close();
    cout.close();

    return 0;
}

