#include <iostream>
#include <vector>
#include <string>
#include <cstdio>
#include <algorithm>
#include <cstdlib>
#include <cmath>
#include <ctime>

using namespace std;

#define LL long long

const int maxn = 1e5 + 5;

int cur_ans[maxn];
int n;
int arr[2][maxn];
pair <int, int> wher[maxn];
int a[maxn];
int b[maxn];

void go(int step)
{
	if (step == n + 1)
	{
		bool fail = false;
		int cur = 0;
		for (int i = 1; i <= n; i++)
		{
			cur += arr[0][i];
			if (abs(cur) > 1)
			{
				fail = true;
				break;
			}
		}
		if (fail)
			return;

		cur = 0;
		for (int i = 1; i <= n; i++)
		{
			cur += arr[1][i];
			if (abs(cur) > 1)
			{
				fail = true;
				break;
			}
		}
		if (!fail)
		{
			for (int i = 1; i <= n; i++)
				printf("%c", (cur_ans[i] == 1 ? 'W' : 'L'));
			exit(0);
		}
		return;
	}
	cur_ans[step] = 1;
	arr[0][wher[step].first] = arr[1][wher[step].second] = 1;
	go(step + 1);

	arr[0][wher[step].first] = arr[1][wher[step].second] = -1;
	cur_ans[step] = -1;
	go(step + 1);
}

int tmp[maxn];

int main()
{
	int q;
	freopen("http.in", "r", stdin);
	freopen("http.out", "w", stdout);
	scanf("%d", &n);
	for (q = 1; q <= n; q++)
	{
		scanf("%d", &a[q]);
		wher[a[q]].first = q;
	}
	for (q = 1; q <= n; q++)
	{
		scanf("%d", &b[q]);
		wher[b[q]].second = q;
	}
	go(1);
}