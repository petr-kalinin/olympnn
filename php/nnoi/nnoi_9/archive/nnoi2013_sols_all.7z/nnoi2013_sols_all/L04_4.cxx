#include <algorithm>
#include <fstream>
using namespace std;
fstream cin("testing.in");
ofstream cout("testing.out");
int main(){
    int n,ans=0;
    cin>>n;
    int m=1;
    while(m<n){
        m*=2;
        ans++;
    }

    int line=ans;
    int p=2,d=1;
    cout<<ans<<endl;
    while(line--){
        int how=0;
        for(int i=1;i<=m;i++)
            for(int j=1;j<=d;j++)
                if(i%p==j and i<=n)
                 how++;
        cout<<how<<" ";
         for(int i=1;i<=m;i++)
            for(int j=1;j<=d;j++)
                if(i%p==j and i<=n)
                 cout<<i<<" ";

        cout<<endl;
        p*=2;
        d*=2;
    }
    return 0;
}
