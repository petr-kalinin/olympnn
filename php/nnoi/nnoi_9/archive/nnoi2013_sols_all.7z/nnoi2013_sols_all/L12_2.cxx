#include <fstream>
#define sz 100000
using namespace std;
int main()
{
    ifstream in("holidays.in");
    long n; in>>n; long d[sz]={0}; for(long i=0;i<n;i++) in>>d[i];
    bool a[sz]={0};
    long v=0;
    for(long i=0;i<sz;i++){v+=d[i]; if(!a[i]&&v){a[i]=1;v--;}}
    ofstream out("holidays.out");
    long s; for(s=sz-1;s-1&&!a[s];s--); if(s<n) s=n-1;
    for(long i=0;i<=s;i++) a[i]?out<<"+ ":out<<"- ";
    in.close();
    out.close();
    return 0;
}
