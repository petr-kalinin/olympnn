#include <fstream>
using namespace std;
struct fis
{
    int nom;
    char col;
};
inline void srt(fis *f,bool a,int k)
{
    if(a) for(int i=0;i<k-1;i++) for(int j=i;j<k;j++) if((f[i].nom>f[j].nom)||(((f[i].nom==f[j].nom)&&(f[i].col>f[j].col)))){fis x=f[i];f[i]=f[j];f[j]=x;}
    else for(int i=0;i<k-1;i++) for(int j=i;j<k;j++) if((f[i].col>f[j].col)||((f[i].col==f[j].col)&&(f[i].nom>f[j].nom))){fis x=f[i];f[i]=f[j];f[j]=x;}
}
inline bool cmb(fis *f,int a,int b)
{
    for(int i=a;i<=b;i++) if(!(((f[i].nom+1==f[i+1].nom)&&(f[i].col==f[i+1].col))||((f[i].nom==f[i+1].nom)&&(f[i].col!=f[i+1].col)))) return false;
    return true;
}
int main()
{
    ifstream in("rummikub.in");
    int k; in>>k;
    fis f[k]; for(int i=0;i<k;i++) in>>f[i].col>>f[i].nom;
    srt(f,1,k);
    int m=0,s[k][2]; for(int i=0;i<k;i++) s[i][0]=s[i][1]=0;
    for(int i=0;i<k;)
    {
        int z=i+1;
        while(cmb(f,i,z)) z++;
        if(z>=i+2){s[m][0]=i;s[m][1]=z;m++;}
        i=z+1;
    }
    if(!m){
    srt(f,0,k);
    for(int i=0;i<k;)
    {
        int z=i+1;
        while(cmb(f,i,z)) z++;
        if(z>=i+2){s[m][0]=i;s[m][1]=z;m++;}
        i=z+1;
    }}
    ofstream out("rummikub.out");
    if(!m) out<<"-1"; else
    {
        out<<m<<'\n';
        for(int i=0;i<m;i++)
        {
            out<<s[i][1]-s[i][0]+1<<' ';
            for(int j=s[i][0];j<=s[i][1];j++) out<<f[j].col<<f[j].nom<<' ';
            out<<'\n';
        }
    }
    in.close();
    out.close();
    return 0;
}
