delta = 2
for i in reversed(range(1,77+1)):
    print("mv %02d %02d" % (i,i+delta))
    print("mv %02d.a %02d.a" % (i,i+delta))
    