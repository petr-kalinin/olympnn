#!/usr/bin/python2

import sys
import matplotlib.pyplot as plt

n = 0
m = 0

#arrNX = []
#arrNY = []
#arrMX = []
#arrMY = []

nt = int(sys.argv[2])

with open(sys.argv[1]) as f:
    k = int(f.readline())
    for t in range(nt):
        n = int(f.readline())
        arrNX = []
        arrNY = []
        arrMX = []
        arrMY = []
        for i in range(n):
            pair = f.readline().split(' ')
            arrNX.append(int(pair[0]))
            arrNY.append(int(pair[1]))
        m = int(f.readline())
        for i in range(m):
            pair = f.readline().split(' ')
            arrMX.append(int(pair[0]))
            arrMY.append(int(pair[1]))

plt.fill(arrNX, arrNY, alpha=0.5)
plt.fill(arrMX, arrMY, alpha=0.5)
plt.show()
