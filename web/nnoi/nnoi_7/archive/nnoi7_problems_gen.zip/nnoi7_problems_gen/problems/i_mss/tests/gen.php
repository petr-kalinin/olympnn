<?
set_magic_quotes_runtime(0);
$f=file("answers.txt");
$nums=array(0,
 1, 2, 3, 4, 5,
 6, 7,10,13,16,
19,22,25,28,30,
31,32,33,34,35);
for ($i=1;$i<=20;$i++){
  $num=$nums[$i];
  $ans=explode(" ",$f[$num]);
  $ans=$ans[1]+1;
  printf("%02d %d %d\n",$i,$num,$ans);
  file_put_contents(sprintf("%02d.hand",$i),$num);
  file_put_contents(sprintf("%02d.a.hand",$i),$ans);
}
?>