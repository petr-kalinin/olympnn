#include <stdio.h>
#include <assert.h>

#define fin "mss.in"
#define fout "mss.out"

typedef unsigned long long ull;

int n,ans=0;
const ull one=1;
ull used=0,pairs=0,diffs=0;
int a[36],k;

void solve(int min)
{
	int i;
	ans++;
	for (i=min;i<n;i++){
		if (i*2%n!=i && // i,i,i
		    ( used & ( one << (2*i%n)))==0 && // ? i i
		    ( pairs & ( one << i))==0 && // ? ? i
		    ( diffs & ( one << i))==0){ // ? i ?
			ull _used=used,_pairs=pairs,_diffs=diffs;
			used|=one << i;
			pairs|=( ( used << i ) & ( (one << n) - 1 ) ) + ( used  >> ( n - i ) );
			diffs|=( used >> i ) + ( ( used & ( (one << i ) - 1 ) ) << (n-i) );
			a[k++]=i;
			solve(i+1);
			k--;
			used=_used;
			pairs=_pairs;
			diffs=_diffs;
		}
	}
}

int main()
{
	freopen(fin,"rt",stdin);
	freopen(fout,"wt",stdout);
	scanf("%d",&n);
	assert(1<=n&&n<=35);
	solve(1);
	printf("%d\n",ans);
	fflush(stdout);
	return 0;
}
