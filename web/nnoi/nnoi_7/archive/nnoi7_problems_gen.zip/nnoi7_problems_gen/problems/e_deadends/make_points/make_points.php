<?
$backpath=".";
include_once("xml.php");
include_once("ije_proc.php");
set_magic_quotes_runtime(0);

$pts=array(0,
2,2,2,2,2,
5,5,6,6,6,
6,6,10,6,6,
6,7,4,7,4
);


$flist=glob("reports/*");
$nn=array();
for ($i=1;$i<=20;$i++) $nn[$i]=0;
foreach ($flist as $fname){
 printf("%40s : ",$fname);
 loadxml($fname,$rep);
 $tot=0;
 for ($i=1;$i<=20;$i++){
   $res=$rep["testing-report"]["testing"]["results"][$i];
   $res=ije_xmltosresult($res["outcome"]);
   if ($res=="OK") {
      $res="  ";
      $tot+=$pts[$i];
      $nn[$i]++;
   }
   printf($res." ");
   if ($i%5==0) printf(".");
 }
 printf(" = $tot\n");
}
printf("%40s : ","passed");
foreach ($nn as $i=>$n) {
  printf("%2.2d ",$n);
  if ($i%5==0) printf(".");
}
printf("\n");
printf("%40s : ","points");
foreach ($nn as $i=>$n) {
  printf("%2.2d ",$pts[$i]);
  if ($i%5==0) printf(".");
}
printf("\n");

foreach ($nn as $i=>$n) {
  printf("        <test points=\"$pts[$i]\" />\n");
  if ($i%5==0) printf("\n");
} 
printf("\n");
?>
