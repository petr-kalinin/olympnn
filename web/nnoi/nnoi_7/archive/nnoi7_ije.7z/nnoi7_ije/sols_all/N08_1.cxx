#include<stdio.h>
#include<stdlib.h>
#include<string.h>

using namespace std;

char ch;
int n,m;
int dx[5];
int dy[5];

char a[505][505];

int main(){
	freopen("deadends.in","rt",stdin);
	freopen("deadends.out","wt",stdout);
	scanf("%d%d",&n,&m);
	dx[0] = 1; dy[0] = -1;
	dx[1] = 1; dy[1] = 1;
	dx[3] = -1; dy[3] = -1;
	dx[2] = -1; dy[2] = 1;
	int j = 1;
	for(int i = 1; i <=n ;i++){
		scanf("%s",a[i]);
	}
	for(int i = 1; i <= n; i++){
		for(int j = 0; j < m; j++){
			if (a[i][j] == 35) printf("#");
			else{
				int f = 0;
				for (int q = 0;q < 4; q ++){
					if ((a[i+dx[q]][j+dy[q]] == '.')) f ++;
				}
				if (f > 1) printf(".");
				else
					printf("X");
			}
		}
		printf("\n");
	}
	return 0;
}
