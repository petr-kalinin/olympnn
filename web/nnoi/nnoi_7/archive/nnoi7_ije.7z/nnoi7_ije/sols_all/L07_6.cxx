//��������� �������, 9 �����, 82 �����, ������ 6, ���������� GNU C++
#include <stdio.h>
#include <algorithm>

using namespace std;

const long maxn=16002;
long a[maxn];
long sum[4];
long amount[4];
long raz[4];
long answer[4][maxn];
long n,q,tr,j,i,choice,minn;

bool good(long a,long b,long c)
{
    return((sum[a]+sum[b]>sum[c]));
}

int main()
{
    freopen("triangle.in","r",stdin);
    freopen("triangle.out","w",stdout);
    scanf("%ld",&n);
    long sumall=0;
    for (q=1;q<=n;q++)
    {
        scanf("%ld",&a[q]);
        sumall+=a[q];
    }
    sort(a,a+n);

    tr=sumall/3;
    for (j=1;j<=3;j++)
    {
        amount[j]=0;
        sum[j]=0;
    }
    for (i=n;i>=1;i--)
    {
        bool pp=false;
        for (choice=1;choice<=3;choice++)
            if (sum[choice]+a[i]<=tr)
            {
                pp=true;
                amount[choice]++;
                sum[choice]+=a[i];
                answer[choice][amount[choice]]=a[i];
                break;
            }
        if (pp==false)
        {
            for (long h=1;h<=3;h++)
                raz[h]=tr-sum[h];
            minn=min(raz[1],min(raz[2],raz[3]));
            for (long h=1;h<=3;h++)
                if (raz[h]==minn)
                {
                    amount[h]++;
                    sum[h]+=a[i];
                    answer[h][amount[h]]=a[i];
                    break;
                }
        }
    }

    bool f1=good(1,2,3);
    bool f2=good(2,3,1);
    bool f3=good(1,3,2);
    if ((f1==true)&&(f2==true)&&(f3==true))
    {
        printf("yes\n");
        for (q=1;q<=3;q++)
        {
            printf("%ld ",amount[q]);
            for (long h=1;h<=amount[q];h++)
                printf("%ld ",answer[q][h]);
            printf("\n");
        }
    }
    else printf("no");
}
