//��������� �������, 9 �����, 82 �����, ������ 4, ���������� GNU C++
#include <stdio.h>

long maxfirst,maxsecond,v,choice;

/*inline bool solve(long first,long second)
{
    if ((first==0)&&(second==0)) return(true);
    if ((first<0)||(first>maxfirst)||(second<0)||(second>maxsecond)) return(false);
    if (opr[first][second]) return(res[first][second]);

    bool f=false;
    if (first==maxfirst) f=solve(0,second);
    if (f==false) if (second==maxsecond) f=solve(first,0);
    if (f==false) if ((first>0)&&(first<maxfirst)&&(second==maxsecond)) f=solve(maxfirst,second-(maxfirst-first));
    if (f==false) if ((second>0)&&(second<maxsecond)&&(first==maxfirst)) f=solve(first-(maxsecond-second),maxsecond);
    if (f==false) if (first==0)
    {
        for (long choice=1;choice<=maxfirst;choice++)
        {
            f=solve(choice,second);
            if (f==true) break;
        }
    }
    if (f==false) if (second==0)
    {
        for (long choice=1;choice<=maxsecond;choice++)
        {
            f=solve(first,choice);
            if (f==true) break;
        }
    }
    res[first][second]=f;
    opr[first][second]=true;
    return(f);
}*/

int main()
{
    freopen("flow.in","r",stdin);
    freopen("flow.out","w",stdout);
    scanf("%ld%ld%ld",&maxfirst,&maxsecond,&v);
    if (v==0) printf("0");
    else if (maxfirst==v) printf("1\n0 1");
        else if (maxsecond==v) printf("1\n0 2");
        else
        {
            long z=maxsecond/maxfirst;
            if (maxsecond-z*maxfirst==maxfirst-v)
            {
                if (z*maxfirst==maxsecond) z--;
                printf("%ld\n",2*(z+1));
                for (long q=1;q<=z+1;q++)
                {
                    printf("0 1\n");
                    printf("1 2\n");
                }
            }
            else
            {
                long z=maxfirst/maxsecond;
                if (maxfirst-z*maxsecond==maxsecond-v)
                {
                    if (z*maxsecond==maxfirst) z--;
                    printf("%ld\n",2*(z+1));
                    for (long q=1;q<=z+1;q++)
                    {
                        printf("0 2\n");
                        printf("2 1\n");
                    }
                }
            }
        }
          /*  else
            {
                if (maxfirst>maxsecond)
                {
                    long temp=maxfirst;
                    maxfirst=maxsecond;
                    maxsecond=temp;
                    number[1]=2;

                }
                else
                {
                    number[1]=1;
                    number[2]=2;
                }

                bool pos=false;
                for (choice=0;choice<=maxfirst;choice++)
                {
                    bool nnew=solve(choice,v);
                    if (nnew==true)
                    {
                        pos=true;
                        break;
                    }
                }
                if (pos==false) for (choice=0;choice<=maxsecond;choice++)
                {
                    bool nnew=solve(v,choice);
                    if (nnew==true)
                    {
                        pos=true;
                        break;
                    }
                }
                if (pos==true)
                {
                    printf("1");
                }
                else printf("-1");
            }*/

}
