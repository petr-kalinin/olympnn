#include<stdio.h>
#include<stdlib.h>
#include<algorithm>

using namespace std;
int s[16005];
int a[16005];
int n,q,w;

bool check(int s1,int s2,int s3){
	if (s1 > s2 + s3)
		return 0;
	if (s2 > s1 + s3)
		return 0;
	if (s3 > s2 + s1)
		return 0;
	return 1;
}

void out(int q, int w){
	printf("yes\n");
	printf("%d ",q);
	for (int i = 1; i <= q; i++){
		printf("%d ",a[i]);
	}
	printf("\n");
	printf("%d ",w - q);
	for (int i = q + 1; i <= w; i++){
		printf("%d ",a[i]);
	}
	printf("\n");
	printf("%d ",n - w);
	for (int i = w + 1; i <= n; i++){
		printf("%d ",a[i]);
	}
	printf("\n");
}

int bins(int l,int r){
	if (s[l] > s[n] - s[l])
		return l;
	int m;
	while (r-l > 1){
		m = (r+l)/2;
		if (s[m] > s[n] -s[m])
			r = m;
		else
			l = m;
	}
	return r;
}

int main(){
	freopen("triangle.in","rt",stdin);
	freopen("triangle.out","wt",stdout);
	scanf("%d",&n);
	for(int i = 1; i <= n; i++){
		scanf("%d",&a[i]);
	}
	sort(a + 1, a + n + 1);
	s[0] = 0;
	for (int i = 1; i <= n ; i++){
		s[i] = s[i-1] + a[i];
	}
	q = 1;
	while ((s[q] < s[n] - s[q])and(q < n - 1)){
		w = bins(q+1,n - 1);
		while ((s[w] - s[q] < s[n] - s[w] + s[q])and(w < n)){
			if (check(s[q],s[w] - s[q],s[n] - s[w])) {
				out(q,w);
				return 0;
			}
			w ++;
		}
		q ++;
	}
	printf("no");
	return 0;
}
