<?
/* This file is part of IJE: the Integrated Judging Environment system 
   (C) Kalinin Petr 2002-2008
   $Id: lang_english.php 202 2008-04-19 11:24:40Z *KAP* $ */
$lang["ClassicalACMcontest"]="Classical ACM contest";
$lang["Outcome"]="Outcome";
$lang["Test"]="Test";
$lang["Comment"]="Comment";
$lang["NotShown"]="Not shown";

$lang["Penalty"]="Penalty";
$lang["Pl"]="Pl";

$lang["PenaltyTimeForRejectedSubmit"]="Penalty time for rejected submit";
$lang["NMin"]="%d min.";
?>