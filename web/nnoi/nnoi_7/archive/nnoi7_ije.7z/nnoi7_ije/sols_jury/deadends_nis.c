#include <stdio.h>
#include <assert.h>
#include <stdlib.h>

static int mx[] = {1, -1, 0, 0};
static int my[] = {0, 0, 1, -1};
#define CAN_MOVE(i, j, q) \
	((i)+mx[q] < n && (i)+mx[q] >= 0 && (j)+my[q] < m && (j)+my[q] >= 0)

static int degree (char* map, int n, int m, int i, int j)
{
	if (map[i*m + j] != '.')
		return -1;
	int res = 0;
	for (int q = 0; q < 4; q++)
		res += CAN_MOVE (i, j, q) && map[(i+mx[q])*m + (j+my[q])] == '.';
	return res;
}

int main (void)
{
	assert (freopen ("deadends.in", "r", stdin) != NULL);
	assert (freopen ("deadends.out", "w", stdout) != NULL);

	int n, m;
	assert (scanf ("%d %d", &n, &m) == 2);
	assert (1 <= n && n <= 500);
	assert (1 <= m && m <= 500);

	char *map = malloc((n * m) * sizeof(*map));
	assert (map != NULL);
	for (int i = 0; i < n; i++) {
		for (int j = 0; j < m; j++) {
			char c;
			assert (scanf("\t%c", &c) == 1);
			assert (c == '.' || c == '#');
			map[i * m + j] = c;
		}
	}

	int *queue = malloc((n * m) * sizeof(*queue));
	assert (queue != NULL);
	int left = 0, right = -1;
	for (int i = 0; i < n; i++) {
		for (int j = 0; j < m; j++) {
			int deg = degree (map, n, m, i, j);
			if (deg == 1)
				queue[++right] = i * m + j;
			if (deg == 0)
				map[i*m + j] = 'X';
		}
	}

	while (left <= right) {
		int i = queue[left] / m;
		int j = queue[left++] % m;

		map[i * m + j] = 'X';
		for (int q = 0; q < 4; q++) {
			if (CAN_MOVE (i, j, q) && degree(map, n, m, i+mx[q], j+my[q]) == 1)
				queue[++right] = (i+mx[q])*m + (j+my[q]);
		}
	}
	free (queue);

	for (int i = 0; i < n; i++) {
		for (int j = 0; j < m; j++)
			assert (putchar (map[i * m + j]) != EOF);
		assert (putchar ('\n') != EOF);
	}
	free (map);

	return 0;
}
