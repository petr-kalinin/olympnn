#include <stdio.h>
int main() {
  FILE *buf,*bufo;
  bufo=fopen("deadends.out","w");
  fprintf(bufo,"X\n");
  fclose(bufo);
  return 0;
}