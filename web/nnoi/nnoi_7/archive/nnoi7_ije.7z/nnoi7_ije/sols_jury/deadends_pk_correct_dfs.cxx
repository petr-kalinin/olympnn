/*
  ������: deadends
  �������: ���� �������
  ���������� �������, ������������ ����� � �������
*/
#include <stdio.h>
#include <assert.h>
#include <string.h>

using namespace std;

int MAP_WIDTH;
int MAP_HEIGHT;

const int MAX_HEIGHT=500;
const int MAX_WIDTH=500;
int map[MAX_HEIGHT+2][MAX_WIDTH+2];

const int WALL=0;
const int FREE=1;

int di[4]={-1,1,0,0};
int dj[4]={0,0,-1,1};


bool deadend[MAX_HEIGHT+2][MAX_WIDTH+2];
int deadendDegree[MAX_HEIGHT+2][MAX_WIDTH+2];
int degree[MAX_HEIGHT+2][MAX_WIDTH+2];

void CalcDegrees(){
	for (int i=1;i<=MAP_HEIGHT;i++)
		for (int j=1;j<=MAP_WIDTH;j++){
			degree[i][j]=0;
			for (int k=0;k<4;k++){
				if (map[i+di[k]][j+dj[k]]!=WALL) {
//					printf("%d %d %d %d %d %d %d\n",i,j,k,map[i+di[k]][j+dj[k]],WALL,map[i+di[k]][j+dj[k]]==WALL,map[i+di[k]][j+dj[k]]!=WALL);
					degree[i][j]++;
				}
			}
			deadendDegree[i][j]=degree[i][j];
			deadend[i][j]=(degree[i][j]==0);
		}
}

void TraceDeadEnd(int i,int j){
	if (map[i][j]==WALL) return;

	deadend[i][j]=true;
	for (int k=0;k<4;k++){
		deadendDegree[i+di[k]][j+dj[k]]--;
		if (deadendDegree[i+di[k]][j+dj[k]]==1)
			TraceDeadEnd(i+di[k],j+dj[k]);
	}
}

void FindDeadEnds(){
	for (int i=1;i<=MAP_HEIGHT;i++)
		for (int j=1;j<=MAP_WIDTH;j++){
			if (degree[i][j]==1)
				TraceDeadEnd(i,j);
		}
//	DumpDeadEnds();
}

int main(){
  memset(map,WALL,sizeof(map));
  
  FILE* f=fopen("deadends.in","r");
  fscanf(f,"%d %d\n",&MAP_HEIGHT,&MAP_WIDTH);
  for (int i=1;i<=MAP_HEIGHT;i++) {
    for (int j=1;j<=MAP_WIDTH;j++) {
      char c=fgetc(f);
//      printf("%d %d %d\n",i,j,c);
      if (c=='.') map[i][j]=FREE;
      else if (c=='#') map[i][j]=WALL;
      else assert(false);
    }
    fscanf(f,"\n");
  }
  
  CalcDegrees();
  FindDeadEnds();
  
  f=fopen("deadends.out","w");
  for (int i=1;i<=MAP_HEIGHT;i++) {
    for (int j=1;j<=MAP_WIDTH;j++) {
      if (map[i][j]==WALL) fprintf(f,"#");
      else if (deadend[i][j]) fprintf(f,"X");
      else fprintf(f,".");
    }
    fprintf(f,"\n");
  }
  fclose(f);
  return 0;
}