#include <iostream>
#include <cassert>
#include <algorithm>
#include <vector>
#include <fstream>

using namespace std;

vector<pair<int, int> > v;
int n, w, l, r;

int main() {
	freopen("door.in", "r", stdin);
	freopen("door.out", "w", stdout);

	cin >> n >> w >> l >> r;

	if (n < 0 || n > 30000) {
		cerr << "Incorrect input parametr N: " << n << endl;
		assert(0);
	}

	if (w > 2000000000 || w < 0) {
		cerr << "Incorrect input parametr W: " << w << endl;
		assert(0);
	}

	if (abs(l) > 30000) {
		cerr << "Incorrect input parametr L: " << l << endl;
		assert(0);
	}

	if (abs(r) > 30000) {
		cerr << "Incorrect input parametr R: " << r << endl;
		assert(0);
	}

	if (r <= l) {
		cerr << "Error: R <= L" << endl;
		assert(0);
	}

	for (int i = 0; i < n; i++) {
		int x;
		cin >> x;

		if (x >= r || x <= l) {
			cerr << "Incorrect input parameter x[" << i << "]: " << x << endl;
			assert(0);
		}

		v.push_back(make_pair(x, i));
	}

	v.push_back(make_pair(l, n));
	v.push_back(make_pair(r, n + 1));
	n += 2;

	sort(v.begin(), v.end());

	for (int i = 0; i < n - 1; i++) {
		if (v[i].first == v[i + 1].first) {
			cerr << "Identical points: x[" << v[i].second << "] and x[" << v[i + 1].second << "]" << endl;
			assert(0);
		}
	}

	if (w == 0) {
		cout << 0;
		return 0;
	}

	int index = -1, answer = n + 1;
	for (int i = 0; i < n; i++) {
		vector<pair<int, int> >::const_iterator p =
				lower_bound(v.begin(), v.end(), make_pair(v[i].first + w, -1));
		if (p == v.end())
			break;
		if (answer > p - v.begin() - i - 1) {
			answer = p - v.begin() - i - 1;
			index = i;
		}
	}

	if (index == -1)
		cout << -1;
	else {
		cout << answer << endl;
		for (int i = index + 1; i <= index + answer; i++)
			cout << v[i].second + 1 << endl;
	}

	return 0;
}
