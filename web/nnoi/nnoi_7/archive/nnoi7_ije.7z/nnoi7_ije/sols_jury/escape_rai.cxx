#include <algorithm>
#include <cstdio>
#include <utility>
#include <vector>

using namespace std;

int main() {
	freopen("door.in", "r", stdin);
	freopen("door.out", "w", stdout);
	int n, w, l, r;
	scanf("%d%d", &n, &w);
	scanf("%d%d", &l, &r);
	if (r - l < w) {
		printf("-1\n");
		return 0;
	}
	if (!w) {
		printf("0\n");
		return 0;
	}
	vector<pair<int, int> > a;
	a.push_back(make_pair(l, 0));
	a.push_back(make_pair(r, 0));
	for (int i = 0; i < n; i++) {
		int x;
		scanf("%d", &x);
		a.push_back(make_pair(x, i));
	}
	sort(a.begin(), a.end());
	int opt = n + 10;
	for (int i = 0; i <= n + 1; i++) {
		if (a[i].first + w > r) continue;
		int x = (int)(lower_bound(a.begin(), a.end(), make_pair(a[i].first + w, -10)) - a.begin());
		if (x - i - 1 < opt) {
			opt = x - i - 1;
		}
	}
	printf("%d\n", opt);
	for (int i = 0; i <= n + 1; i++) {
		if (a[i].first + w > r) continue;
		int x = (int)(lower_bound(a.begin(), a.end(), make_pair(a[i].first + w, -10)) - a.begin());
		if (x - i - 1 == opt) {
			for (int j = i + 1; j < x; j++) {
				printf("%d\n", a[j].second + 1);
			}
			return 0;
		}
	}
	return 0;
}
