#include <cstdio>
#include <iostream>
#include <queue>
#include <string>
#include <utility>
#include <vector>

using namespace std;

const int dx[] = {-1, 1, 0, 0};
const int dy[] = {0, 0, -1, 1};

int main() {
	freopen("deadends.in", "r", stdin);
	freopen("deadends.out", "w", stdout);
	int n, m;
	cin >> n >> m;
	vector<string> f(n + 2);
	f[0] = f[n + 1] = string(m + 2, '#');
	for (int i = 1; i <= n; i++) {
		cin >> f[i];
		f[i] = '#' + f[i] + '#';
	}
	vector<string> ans(f);
	queue<pair<int, int> > q;
	vector<vector<int> > deg(n + 2, vector<int>(m + 2));
	for (int i = 0; i < n + 2; i++) {
		for (int j = 0; j < m + 2; j++) {
			if (f[i][j] == '#') continue;
			deg[i][j] = 0;
			for (int k = 0; k < 4; k++) {
				if (f[i + dx[k]][j + dy[k]] == '#') continue;
				deg[i][j]++;
			}
			if (deg[i][j] == 1) {
				q.push(make_pair(i, j));
			}
		}
	}
	while (!q.empty()) {
		pair<int, int> cp = q.front();
		q.pop();
		ans[cp.first][cp.second] = 'X';
		for (int k = 0; k < 4; k++) {
			int nx = cp.first + dx[k], ny = cp.second + dy[k];
			if (f[nx][ny] == '#') continue;
			deg[nx][ny]--;
			if (deg[nx][ny] == 1) {
				q.push(make_pair(nx, ny));
			}
		}
	}
	for (int i = 0; i < n; i++) {
		for (int j = 0; j < m; j++) {
			printf("%c", ans[i + 1][j + 1]);
		}
		printf("\n");
	}
	return 0;
}
