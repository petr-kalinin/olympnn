echo [INFO]: Building problem 'divide-to-three'.
cd problems/divide-to-three
./doall.sh
cd -

echo [INFO]: Building problem 'max-multiple'.
cd problems/max-multiple
./doall.sh
cd -

echo [INFO]: Building problem 'conference'.
cd problems/conference
./doall.sh
cd -

echo [INFO]: Building problem 'string-dist'.
cd problems/string-dist
./doall.sh
cd -

echo [INFO]: Building problem 'pie'.
cd problems/pie
./doall.sh
cd -

echo [INFO]: Building problem 'maximum-in-set'.
cd problems/maximum-in-set
./doall.sh
cd -

echo [INFO]: Building russian contest statement.
cd statements/russian
./doall.sh
cd -

