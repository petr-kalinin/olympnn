/**
 * This is gen_binary.cpp
 * 
 * @author: Nikolay Kalinin
 * @date: Thu, 08 Feb 2018 18:46:00 +0300
 */
#include "testlib.h"
#include <iostream>
#include <numeric>

using namespace std;

int main(int argc, char* argv[]) {
    registerGen(argc, argv, 1);
    
    int n = atoi(argv[1]);
    int freedom = atoi(argv[2]);
    
    string type = "sort";
    if (argc > 3) type = string(argv[3]);
    
    ensure(((n + 1) & (n)) == 0);
    
    vector<int> lengths;
    for (int i = 0, suml = 0; suml < n; suml += 2 * (1 << i), i++)
    {
        lengths.push_back(1 << i);
        lengths.push_back(1 << i);
    }
    
    if (type == "shuffle") shuffle(lengths.begin(), lengths.end());
    
    vector<pair<int, int>> segments;
    int start = 0;
    int last = -1;
    for (int i = 0; i < (int)lengths.size(); i++)
    {
        int m = start + lengths[i];
        int l = max(m - freedom, last + 1);
        int r = min(m + freedom, (i + 1 == (int)lengths.size() ? 2 * n : m + lengths[i + 1] - 1));
        l = rnd.next(l, m);
        r = rnd.next(m, r);
        segments.push_back({l, r});
        last = r;
        start = m;
    }
    
    printf("%d %d\n", n, (int)segments.size());
    for (auto t : segments) printf("%d %d\n", t.first, t.second);
}
