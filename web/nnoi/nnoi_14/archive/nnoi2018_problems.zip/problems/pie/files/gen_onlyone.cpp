#include "testlib.h"
#include <iostream>
#include <numeric>

using namespace std;

int main(int argc, char* argv[]) {
    registerGen(argc, argv, 1);
    
    int n = atoi(argv[1]);
    int maxlen = atoi(argv[2]);
    int ways = atoi(argv[3]);
    int freedom = atoi(argv[4]);
    
    vector<int> cnt(2 * n + 1, 0);
    cnt[0] = 1;
    
    vector<int> lengths;
    int reml = 2 * n;
    while (reml > 0 && cnt[n] + (reml > n ? 0 : cnt[n - reml]) < ways)
    {
        int l = rnd.next(1, min(reml, maxlen));
        for (int i = n - l; i >= 0; i--) cnt[i + l] = min(1000000000, cnt[i + l] + cnt[i]);
        lengths.push_back(l);
        reml -= l;
    }
    cerr << cnt[n] + (reml > n ? 0 : cnt[n - reml]) << endl;
    if (reml > 0) lengths.push_back(reml);
    shuffle(lengths.begin(), lengths.end());
    
    vector<pair<int, int>> segments;
    int start = 0;
    int last = -1;
    for (int i = 0; i < (int)lengths.size(); i++)
    {
        int m = start + lengths[i];
        int l = max(m - freedom, last + 1);
        int r = min(m + freedom, (i + 1 == (int)lengths.size() ? 2 * n : m + lengths[i + 1] - 1));
        l = rnd.next(l, m);
        r = rnd.next(m, r);
        segments.push_back({l, r});
        last = r;
        start = m;
    }

    printf("%d %d\n", n, (int)segments.size());
    for (auto t : segments) printf("%d %d\n", t.first, t.second);
}
