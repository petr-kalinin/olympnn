#include "testlib.h"
#include <iostream>
#include <numeric>

using namespace std;

int main(int argc, char* argv[]) {
    registerGen(argc, argv, 1);
    
    int n = atoi(argv[1]);
    int k = atoi(argv[2]);
    
    vector<int> p(2 * n + 1);
    iota(p.begin(), p.end(), 0);
    shuffle(p.begin(), p.end());
    
    vector<bool> incl(2 * n + 2, false); // element 2 * n + 1 is always false
    for (int i = 0; i < k; i++) incl[p[i]] = true;
    
    vector<pair<int, int>> segments;
    int start = -1;
    for (int i = 0; i <= 2 * n + 1; i++)
    {
        if (incl[i] && start == -1) start = i;
        if (!incl[i] && start != -1)
        {
            segments.push_back({start, i - 1});
            start = -1;
        }
    }
    printf("%d %d\n", n, (int)segments.size());
    for (auto t : segments) printf("%d %d\n", t.first, t.second);
}
