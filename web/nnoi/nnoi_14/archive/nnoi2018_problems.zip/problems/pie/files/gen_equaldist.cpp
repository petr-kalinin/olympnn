/**
 * This is gen_binary.cpp
 * 
 * @author: Nikolay Kalinin
 * @date: Thu, 08 Feb 2018 18:46:00 +0300
 */
#include "testlib.h"
#include <iostream>
#include <numeric>

using namespace std;

int main(int argc, char* argv[]) {
    registerGen(argc, argv, 1);
    
    int n = atoi(argv[1]);
    int l_busy = atoi(argv[2]);
    int l_free = atoi(argv[3]);
    
    vector<pair<int, int>> segments;
    int start = 0;
    while (start + l_busy <= 2 * n)
    {
        int l = start + l_busy;
        int r = min(2 * n, l + l_free);
        segments.push_back({l, r});
        start = r;
    }
    
    printf("%d %d\n", n, (int)segments.size());
    for (auto t : segments) printf("%d %d\n", t.first, t.second);
}
