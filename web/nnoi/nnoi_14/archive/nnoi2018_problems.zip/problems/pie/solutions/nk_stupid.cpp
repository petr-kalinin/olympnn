#include <bits/stdc++.h>

using namespace std;

using ll = long long;
using ld = long double;
using D = double;
using uint = unsigned int;
template<typename T>
using pair2 = pair<T, T>;

#ifdef WIN32
    #define LLD "%I64d"
#else
    #define LLD "%lld"
#endif

#define pb push_back
#define mp make_pair
#define all(x) (x).begin(),(x).end()
#define fi first
#define se second

const int maxn = 1003;
const int inf = 1e9;

bool was[2 * maxn][maxn][2];
int ans[2 * maxn][maxn][2];
int n, k;
bool can[2 * maxn];

int go(int botht, int onet, int side)
{
    if (onet > n || botht - onet > n) return inf;
    if (botht == 2 * n) return 0;
    if (was[botht][onet][side]) return ans[botht][onet][side];
    was[botht][onet][side] = true;
    int &curans = ans[botht][onet][side];
    curans = inf;
    curans = min(curans, go(botht + 1, onet + (side == 0), side));
    if (can[botht]) curans = min(curans, go(botht + 1, onet + (side == 1), 1 - side) + 1);
    return curans;
}

int main()
{
    scanf("%d%d", &n, &k);
    if (n > 1000) while (true);
    for (int i = 0; i < k; i++)
    {
        int l, r;
        scanf("%d%d", &l, &r);
        for (int j = l; j <= r; j++) can[j] = true;
    }
    int ans = go(0, 0, 0);
    if (ans == inf)
    {
        printf("Hungry\n");
        return 0;
    }
    printf("Full\n");
    printf("%d\n", ans);
    return 0;
}
