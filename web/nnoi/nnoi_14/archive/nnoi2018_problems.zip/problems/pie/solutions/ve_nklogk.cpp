#include <bits/stdc++.h>

using namespace std;

#define fi first
#define se second
#define mp make_pair
#define pb push_back
#define all(x) (x).begin (),(x).end()
#define sqrt(x) sqrt(abs(x))
#define re return
#define sz(x) ((int)(x).size ())
#define prev PREV
#define next NEXT

using ll = long long;
using ii = pair<int, int>;
using ld = long double;
using D = double;
using vi = vector<int>;
using vii = vector<ii>;
using vvi = vector<vi>;
using vs = vector<string>;

template<typename T> T abs (T x) { re x < 0 ? -x : x; }
template<typename T> T sgn (T x) { re x < 0 ? -1 : (x > 0 ? 1 : 0); }
template<typename T> T sqr (T x) { re x * x; }
template<typename T> T gcd (T a, T b) { re a ? gcd (b % a, a) : b; }

int n;
int m;
int k;

int res[2][500001][2];
vii add[2][500001][2];
int x[101];
int y[101];
int cnt[2][210];
set<int> all[2];

int main () {
	scanf ("%d%d", &n, &k);
	int last = 0;
	for (int i = 0; i < k; i++) {
		int l, r;
		scanf ("%d%d", &l, &r);
		x[i] = l - last;
		y[i] = r - l;
		last = r;
	}
	x[k] = 2 * n - last;
	y[k] = 0;
	k++;
	for (int i = 0; i < 2; i++)
		for (int j = 0; j <= n; j++)
			for (int t = 0; t < 2; t++)
				res[i][j][t] = 1e9;
	res[0][0][0] = 0;
	for (int i = 0; i < k; i++) {	
		int ci = i & 1;
		int ni = 1 - ci;
		all[0].clear ();
		all[1].clear ();
		for (int j = 0; j <= n; j++)
			for (int t = 0; t < 2; t++) {
				add[ni][j][t].clear ();
				res[ni][j][t] = 1e9;
			}
		for (int j = 0; j <= n; j++)
			for (int t = 0; t < 2; t++) {
				for (int e = 0; e < sz (add[ci][j][t]); e++) {
					int a = add[ci][j][t][e].fi;
					int b = add[ci][j][t][e].se;
					if (b == 1) {
						if (cnt[t][a] == 0) all[t].insert (a);
						cnt[t][a]++;
					} else {
						cnt[t][a]--;
						if (cnt[t][a] == 0) all[t].erase (a);
					}
				}	
				if (!all[t].empty ()) res[ci][j][t] = min (res[ci][j][t], *all[t].begin ());
				if (res[ci][j][t] < 1e8) {
					int nj = j + (1 - t) * (x[i] + y[i]);
					if (nj <= n)
						res[ni][nj][t] = min (res[ni][nj][t], res[ci][j][t]);
					nj = j + (1 - t) * x[i] + t * y[i];
					if (nj <= n)
						res[ni][nj][t] = min (res[ni][nj][t], res[ci][j][t] + 2);
					int a = min (j + (1 - t) * x[i] + t * y[i], j + (1 - t) * (x[i] + y[i]));
					int b = max (j + (1 - t) * x[i] + t * y[i], j + (1 - t) * (x[i] + y[i])) + 1;
					if (a > n) continue;
					add[ni][a][t ^ 1].pb (mp (res[ci][j][t] + 1, 1));
					if (b > n) continue;
					add[ni][b][t ^ 1].pb (mp (res[ci][j][t] + 1, -1));
				}
			}
	}
	int ans = min (res[k & 1][n][0], res[k & 1][n][1]);
	if (ans < 1e9) printf ("Full\n%d\n", ans); else printf ("Hungry\n");
	re 0;
}
