#include <bits/stdc++.h>

using namespace std;

using ll = long long;
using ld = long double;
using D = double;
using uint = unsigned int;
template<typename T>
using pair2 = pair<T, T>;

#ifdef WIN32
    #define LLD "%I64d"
#else
    #define LLD "%lld"
#endif

#define pb push_back
#define mp make_pair
#define all(x) (x).begin(),(x).end()
#define fi first
#define se second

const int maxk = 102;
const int maxn = 100005;
const int inf = 1e9;

bool was[maxk][maxn][2];
int ans[maxk][maxn][2];
int n, k;
int l[maxk], r[maxk];
int cnt = 0;
bool timeout = false;
int max_clock;

int go(int cur, int onet, int side)
{
    cnt++;
    if (cnt == 100000)
    {
        timeout = clock() > max_clock;
        cnt = 0;
    }
    if (timeout) return inf;
    if (onet > n || l[cur] - onet > n) return inf;
    if (l[cur] == 2 * n) return 0;
    int &curans = ans[cur][onet][side];
    if (was[cur][onet][side]) return curans;
    was[cur][onet][side] = true;
    curans = inf;
    curans = min(curans, go(cur + 1, onet + (side == 0) * (l[cur + 1] - l[cur]), side));
    for (int t = 0; t <= r[cur] - l[cur]; t++)
    {
        curans = min(curans, 1 + go(cur + 1, onet + (side == 0) * t + (side == 1) * (l[cur + 1] - l[cur] - t), 1 - side));
        curans = min(curans, 2 + go(cur + 1, onet + (side == 1) * t + (side == 0) * (l[cur + 1] - l[cur] - t), side));
    }
    return curans;
}

int main()
{
    scanf("%d%d", &n, &k);
    if (n > 100000) while (true);
    for (int i = 1; i <= k; i++)
    {
        scanf("%d%d", &l[i], &r[i]);
        if (l[i] <= n && r[i] >= n)
        {
            printf("Full\n1\n");
            return 0;
        }
    }
    for (int i = 1; i <= k; i++)
    {
        for (int j = i + 1; j <= k; j++) if (max(l[i], l[j] - n) <= min(r[i], r[j] - n))
        {
            printf("Full\n2\n");
            return 0;
        }
    }
    l[0] = 0;
    r[0] = 0;
    l[k + 1] = 2 * n;
    r[k + 1] = 2 * n;
    max_clock = 3 * CLOCKS_PER_SEC;
    int ans = go(0, 0, 0);
    if (ans == inf)
    {
        printf("Hungry\n");
    } else
    {
        printf("Full\n");
        printf("%d\n", ans);
    }
    return 0;
}
