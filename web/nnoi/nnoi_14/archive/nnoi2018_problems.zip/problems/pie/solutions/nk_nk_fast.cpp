#include <bits/stdc++.h>

using namespace std;

using ll = long long;
using ld = long double;
using D = double;
using uint = unsigned int;
template<typename T>
using pair2 = pair<T, T>;

#ifdef WIN32
    #define LLD "%I64d"
#else
    #define LLD "%lld"
#endif

#define pb push_back
#define mp make_pair
#define all(x) (x).begin(),(x).end()
#define fi first
#define se second

const int maxn = 500006;
const int maxk = 103;
const int inf = 1e9;

int ops = 0;

struct my_queue
{
    int q[2 * maxn];
    int v[2 * maxn];
    int b, e;
    
    my_queue(): b(0), e(0) {}
};


inline void add(my_queue &q, int toadd, int addv)
{
    while (q.e > q.b && addv < q.v[q.e - 1])
    {
        ops++;
        q.e--;
    }
    q.v[q.e] = addv;
    q.q[q.e++] = toadd;
}

inline void remove(my_queue &q, int upto)
{
    while (q.e > q.b && q.q[q.b] < upto)
    {
        q.b++;
        ops++;
    }
}

inline int get(my_queue &q)
{
    if (q.b == q.e) return inf;
    return q.v[q.b];
}

inline void clear(my_queue &q)
{
    q.b = q.e = 0;
}

my_queue qsame, qother;
int answer[2][maxn];
int n, k;
int l[maxk], r[maxk];

inline void upd(int &a, int b)
{
    a = min(a, b);
}

int main()
{
    scanf("%d%d", &n, &k);
    for (int i = 1; i <= k; i++)
    {
        scanf("%d%d", &l[i], &r[i]);
    }
    l[0] = r[0] = 0;
    l[k + 1] = r[k + 1] = 2 * n;
    for (int i = 0; i <= n; i++)
    {
        answer[0][i] = inf;
        answer[1][i] = inf;
    }
    answer[0][0] = 0;
    for (int i = 1; i <= k + 1; i++)
    {
        clear(qsame);
        clear(qother);
        
        for (int tone = 0; tone <= n; tone++)
        {
            answer[i & 1][tone] = inf;
            if (tone > l[i]) continue;
            // zero
            if (tone - (l[i] - l[i - 1]) >= 0) {
                upd(answer[i & 1][tone], answer[1 - (i & 1)][tone - (l[i] - l[i - 1])]);
            }
            
            // one
            int from = l[i] - tone - (r[i - 1] - l[i - 1]);
            int to   = l[i] - tone;
            // reverse direction
            if (from >= 0 && from <= n) add(qother, -from, answer[1 - (i & 1)][from]);
            remove(qother, -to);
            upd(answer[i & 1][tone], get(qother) + 1);
            
            // two
            from = tone - (l[i] - l[i - 1]);
            to   = tone - (l[i] - r[i - 1]);
            if (to >= 0 && to <= n) add(qsame, to, answer[1 - (i & 1)][to]);
            remove(qsame, from);
            upd(answer[i & 1][tone], get(qsame) + 2);
//             cout << i << ' ' << l[i] << ' ' << tone << ' ' << answer[i % 2][tone] << endl;
//             cout << "ll " << from << ' ' << to << ' ' << qsame.get() << ' ' << qsame.b << ' ' << qsame.e << endl;
        }
    }
    int result = answer[(k + 1) & 1][n];
    if (result == inf)
    {
        printf("Hungry\n");
    } else
    {
        printf("Full\n");
        printf("%d\n", result);
    }
    cerr << ops << endl;
    return 0;
}
