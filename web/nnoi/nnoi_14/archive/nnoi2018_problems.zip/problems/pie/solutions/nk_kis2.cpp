#include <bits/stdc++.h>

using namespace std;

using ll = long long;
using ld = long double;
using D = double;
using uint = unsigned int;
template<typename T>
using pair2 = pair<T, T>;

#ifdef WIN32
    #define LLD "%I64d"
#else
    #define LLD "%lld"
#endif

#define pb push_back
#define mp make_pair
#define all(x) (x).begin(),(x).end()
#define fi first
#define se second

const int maxk = 1003;

int l[maxk], r[maxk];
int n, k;

int main()
{
    scanf("%d%d", &n, &k);
    for (int i = 0; i < k; i++)
    {
        scanf("%d%d", &l[i], &r[i]);
        if (l[i] <= n && r[i] >= n)
        {
            printf("Full\n1\n");
            return 0;
        }
    }
    for (int i = 0; i < k; i++)
    {
        for (int j = i + 1; j < k; j++) if (max(l[i], l[j] - n) <= min(r[i], r[j] - n))
        {
            printf("Full\n2\n");
            return 0;
        }
    }
    printf("Hungry\n");
    return 0;
}
