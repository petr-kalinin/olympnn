#include<bits/stdc++.h>

using namespace std;

const int MAXN = 5e5 + 5;
const int LG = 19;
const int inf = 1e6;

int n, k;
int dp[2][MAXN];
int t[4*MAXN];
int l[MAXN], r[MAXN];
int pw[MAXN];
int leaf = inf;

void build(){
	for(int i = n/2; i <= n/2 + n/2; i++)t[i] = dp[0][i-n/2];
	for(int i = n/2-1; i > 0; i--)t[i] = min(t[i<<1], t[i<<1|1]);
}

int get_tree(int l, int r){
	l += n/2; r += n/2;
	++r;
	int al = inf, ar = inf;
	while(l < r){
		if(l&1)al = min(al, t[l++]);
		if(r&1)ar = min(ar, t[--r]);
		l /= 2; r /= 2;
	}
	return min(al, ar);
}

inline int get(int l, int r){
	if(l > r)return inf;
	if(l > n/2)return inf;
	if(r < 0)return inf; else l = max(l, 0);
	r = min(r, n/2);
	return get_tree(l, r);
}

int main(){
	pw[0] = 1;
	for(int i = 1; i < MAXN; i++){
		pw[i] = pw[i - 1];
		while((1<<pw[i]) <= i)++pw[i];
		--pw[i];
	}
	scanf("%d%d", &n, &k);
	n *= 2;
	for(int i = 0; i < k; i++)
		scanf("%d%d", &l[i], &r[i]);
	dp[0][0] = 0;
	for(int i = 1; i <= n/2; i++)dp[0][i] = inf;
	int passed = 0;
	for(int i = 0; i < k; i++){
		int delta = i == 0 ? l[i] : (l[i] - r[i - 1]);
		passed += delta;
		for(int j = 0; j <= n/2; j++)dp[1][j] = inf;
		for(int j = 0; j <= n/2; j++)if(j + delta <= n/2)dp[1][j + delta] = dp[0][j];
		memcpy(dp[0], dp[1], sizeof(dp[0]));
		for(int j = 0; j <= n/2; j++)dp[1][j] = inf;
		build();
		delta = r[i] - l[i];
		for(int j = 0; j <= n/2; j++){
			if(j >= delta)dp[1][j] = dp[0][j - delta];
			dp[1][j] = min(dp[1][j], min(1 + get(passed - j, passed - j + delta), 2 + get(j - delta, j)));
		}
		memcpy(dp[0], dp[1], sizeof(dp[0]));
		passed += r[i] - l[i];
	}
	int ex = n - r[k - 1];
	int pos = n/2 - ex;
	int l = pos < 0 ? inf : dp[0][pos];
	int r = ex <= n/2 ? dp[0][n/2] : inf;
	++r;
	if(min(l, r) == inf)printf("Hungry");
	else printf("Full\n%d", min(l, r));
	return 0;
}
