#include <bits/stdc++.h>

using namespace std;

using ll = long long;
using ld = long double;
using D = double;
using uint = unsigned int;
template<typename T>
using pair2 = pair<T, T>;

#ifdef WIN32
    #define LLD "%I64d"
#else
    #define LLD "%lld"
#endif

#define pb push_back
#define mp make_pair
#define all(x) (x).begin(),(x).end()
#define fi first
#define se second

const int maxn = 500004;
const int maxk = 103;
const int inf = 1e9;

int answer[2][maxn][2];
int n, k;
int l[maxk], r[maxk];

void upd(int &a, int b)
{
    a = min(a, b);
}

int main()
{
    scanf("%d%d", &n, &k);
    for (int i = 1; i <= k; i++)
    {
        scanf("%d%d", &l[i], &r[i]);
    }
    l[0] = r[0] = 0;
    l[k + 1] = r[k + 1] = 2 * n;
    for (int i = 0; i <= n; i++)
    {
        answer[0][i][0] = inf;
        answer[0][i][1] = inf;
    }
    answer[0][0][0] = 0;
    answer[0][0][1] = 0;
//     int ops = 0;
    for (int i = 1; i <= k + 1; i++)
    {
        for (int side = 0; side < 2; side++)
        {
            for (int tone = 0; tone <= n; tone++)
            {
                answer[i % 2][tone][side] = inf;
                // zero
                if (tone - (side == 0) * (l[i] - l[i - 1]) >= 0) {
                    upd(answer[i % 2][tone][side], answer[1 - i % 2][tone - (side == 0) * (l[i] - l[i - 1])][side]);
                }
                
                // one
                int from = tone - (side == 0 ? l[i] - l[i - 1] : r[i - 1] - l[i - 1]);
                int to   = tone - (side == 0 ? l[i] - r[i - 1] : 0);
                for (int j = max(0, from); j <= to; j++)
                {
//                     ops++;
                    upd(answer[i % 2][tone][side], answer[1 - i % 2][j][1 - side] + 1);
                }
                
                // two
                from = tone - (side == 0 ? l[i] - l[i - 1] : r[i - 1] - l[i - 1]);
                to   = tone - (side == 0 ? l[i] - r[i - 1] : 0);
                for (int j = max(0, from); j <= to; j++)
                {
//                     ops++;
                    upd(answer[i % 2][tone][side], answer[1 - i % 2][j][side] + 2);
                }
//                 cout << i << ' ' << l[i] << ' ' << side << ' ' << tone << ' ' << answer[i % 2][tone][side] << endl;
            }
        }
    }
//     cerr << ops << endl;
    int result = min(answer[(k + 1) % 2][n][0], answer[(k + 1) % 2][n][1]);
    if (result == inf)
    {
        printf("Hungry\n");
    } else
    {
        printf("Full\n");
        printf("%d\n", result);
    }
    return 0;
}
