#include <bits/stdc++.h>

using namespace std;

using ll = long long;
using ld = long double;
using D = double;
using uint = unsigned int;
template<typename T>
using pair2 = pair<T, T>;

#ifdef WIN32
    #define LLD "%I64d"
#else
    #define LLD "%lld"
#endif

#define pb push_back
#define mp make_pair
#define all(x) (x).begin(),(x).end()
#define fi first
#define se second

const int maxn = 500005;
const int maxk = 103;
const int inf = 1e9;

deque<pair2<int>> qsame, qother;
int answer[2][maxn][2];
int n, k;
int l[maxk], r[maxk];

void add(deque<pair2<int>> &q, pair2<int> toadd)
{
    while (!q.empty() && toadd.fi < q.back().fi) q.pop_back();
    q.push_back(toadd);
}

void remove(deque<pair2<int>> &q, int upto)
{
    while (!q.empty() && q.front().se < upto) q.pop_front();
}

int get(deque<pair2<int>> &q)
{
    if (q.empty()) return inf;
    return q.front().fi;
}

void upd(int &a, int b)
{
    a = min(a, b);
}

int main()
{
    scanf("%d%d", &n, &k);
    for (int i = 1; i <= k; i++)
    {
        scanf("%d%d", &l[i], &r[i]);
    }
    l[0] = r[0] = 0;
    l[k + 1] = r[k + 1] = 2 * n;
    for (int i = 0; i <= n; i++)
    {
        answer[0][i][0] = inf;
        answer[0][i][1] = inf;
    }
    answer[0][0][0] = 0;
    answer[0][0][1] = 0;
    for (int i = 1; i <= k + 1; i++)
    {
        for (int side = 0; side < 2; side++)
        {
            while (!qsame.empty()) qsame.pop_back();
            while (!qother.empty()) qother.pop_back();
            
            for (int tone = 0; tone <= n; tone++)
            {
                answer[i % 2][tone][side] = inf;
                // zero
                if (tone - (side == 0) * (l[i] - l[i - 1]) >= 0) {
                    upd(answer[i % 2][tone][side], answer[1 - i % 2][tone - (side == 0) * (l[i] - l[i - 1])][side]);
                }
                
                // one
                int from = tone - (side == 0 ? l[i] - l[i - 1] : r[i - 1] - l[i - 1]);
                int to   = tone - (side == 0 ? l[i] - r[i - 1] : 0);
                if (to >= 0) add(qother, {answer[1 - i % 2][to][1 - side] + 1, to});
                remove(qother, from);
                upd(answer[i % 2][tone][side], get(qother));
                
                // two
                from = tone - (side == 0 ? l[i] - l[i - 1] : r[i - 1] - l[i - 1]);
                to   = tone - (side == 0 ? l[i] - r[i - 1] : 0);
                if (to >= 0) add(qsame, {answer[1 - i % 2][to][side] + 2, to});
                remove(qsame, from);
                upd(answer[i % 2][tone][side], get(qsame));
//                 cout << i << ' ' << l[i] << ' ' << side << ' ' << tone << ' ' << answer[i % 2][tone][side] << endl;
            }
        }
    }
    int result = min(answer[(k + 1) % 2][n][0], answer[(k + 1) % 2][n][1]);
    if (result == inf || result > 6)
    {
        printf("Hungry\n");
    } else
    {
        printf("Full\n");
        printf("%d\n", result);
    }
    return 0;
}
