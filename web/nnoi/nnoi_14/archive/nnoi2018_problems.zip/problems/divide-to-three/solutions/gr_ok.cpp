#include <bits/stdc++.h>

using namespace std;

typedef long long ll;
typedef unsigned long long ull;
typedef long double ld;

int cnt[3];

map<string, int> dict;

int ans[3][3];
int main() {
#ifdef LOCAL
    freopen("in", "r", stdin);
#endif
    ios_base::sync_with_stdio(false); cin.tie(0); cout.tie(0);
    for (int i = 0; i < 3; i++) {
        string s;
        cin >> s;
        dict[s] = i;
    }
    int n;
    cin >> n;
    for (int i = 0; i < n; i++) {
        string s;
        int x;
        cin >> s >> x;
        cnt[dict[s]] += x;
    }

    int sm = (cnt[0] + cnt[1] + cnt[2]) / 3;
    int d1 = cnt[0] - sm;
    ans[0][1] = -d1;
    ans[1][0] = d1;
    cnt[0] -= d1;
    cnt[1] += d1;
    int d2 = cnt[1] - sm;
    ans[1][2] = -d2;
    ans[2][1] = d2;
    for (int i = 0; i < 3; i++) {
        for (int j = 0; j < 3; j++) {
            cout << ans[i][j] << " ";
        }
        cout << endl;
    }
}