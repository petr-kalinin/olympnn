#include <iostream>
#include <cstdio>
#include <ctime>
#include <cassert>
#include <cmath>
#include <stack>
#include <set>
#include <map>
#include <vector>
#include <queue>
#include <algorithm>
#include <utility>
#include <cstdlib>
#include <cstring>
#include <string>
using namespace std;

#ifdef WIN32
    #define lld "%I64d"
#else
    #define lld "%lld"
#endif

#define mp make_pair
#define pb push_back
#define put(x) { cout << #x << " = "; cout << (x) << endl; }

typedef long long ll;
typedef long double ld;
typedef unsigned long long ull;
typedef double db;

const int M = 1e6 + 15;
const int Q = 1e9 + 7;

int a[3][3];
int cnt[3];

int nxt(int k) { return k <= 0 ? -k + 1 : -k; }
void test() {
	int res[3] = {0, 0, 0};
	for (int i = 0; i < 3; i++) {
		res[i] = cnt[i];
		for (int j = 0; j < 3; j++) {
			res[i] += a[i][j];
		}
	}
	if (res[0] == res[1] && res[1] == res[2]) {
		for (int i = 0; i< 3; i++) {
			for (int j = 0; j < 3; j++) {
				cout << a[i][j] << " ";
			}
			cout << endl;
		}
		exit(0);
	}
}

int main(){
    srand(time(NULL));
#ifndef ONLINE_JUDGE
    freopen("input.txt", "r", stdin);
    freopen("output.txt", "w", stdout);
#endif
	string name[3];
	map<string, int> pos;
	for (int i = 0; i < 3; i++) {
		cin >> name[i];
		pos[name[i]] = i;
	}

	int n;
	cin >> n;
	for (int i = 0; i < n; i++) {	
		string boy;
		int c;
		cin >> boy >> c;
		cnt[pos[boy]] += c; 
	}
	assert((cnt[0] + cnt[1] + cnt[2]) % 3 == 0);
	int T = 100;
	for (a[1][0] = -T; a[1][0] <= T; a[1][0]++) {
		for (a[2][0] = -T; a[2][0] <= T; a[2][0]++) {
			for (a[2][1] = -T; a[2][1] <= T; a[2][1]++) {
				a[0][1] = -a[1][0];
				a[0][2] = -a[2][0];
				a[1][2] = -a[2][1];
				test();
			}
		}
	}
    return 0;
}   