#include <bits/stdc++.h>

using namespace std;

#define mp make_pair
#define pb push_back
#define makeunique(x) sort(all(x)), (x).resize(unique(all(x)) - (x).begin())
#define re return
#define fi first
#define se second
#define sz(x) ((int) (x).size())
#define all(x) (x).begin(), (x).end()
#define sqrt(x) sqrt(abs(x))
#define y0 y3487465
#define y1 y8687969
#define j0 j5743892
#define j1 j542893
                         
typedef vector<int> vi;
typedef long long ll;
typedef unsigned long long ull;
typedef long double ld;
typedef double D;
typedef pair<int, int> ii;
typedef vector<ii> vii;
typedef vector<string> vs;
typedef vector<vi> vvi;

template<class T> T abs(T x) { re x > 0 ? x : -x; }
template<class T> T gcd(T a, T b) { re a ? gcd (b % a, a) : b; }
template<class T> T sqr(T a) { re a * a; }
template<class T> T sgn(T a) { re a > 0 ? 1 : (a < 0 ? -1 : 0); }

#define filename ""

int n;
int m;

int ans[3][3];

int main () {
//  freopen (filename".in", "r", stdin);
//  freopen (filename".out", "w", stdout);
    string s1, s2, s3;
    cin >> s1 >> s2 >> s3 >> n;
    map <string, ii> a = {{s1, {0, 0}}, {s2, {0, 1}}, {s3, {0, 2}}};
    int cnt = 0;
    for (int i = 0; i < n; i++) {
        string s;
        int x;
        cin >> s >> x;
        a[s].fi += x;
        cnt += x;
    }
    for (auto & x : a) {
        for (auto & y : a) {    
            if (x.se.fi < cnt / 3) {
                int z = min (max (y.se.fi - cnt / 3, 0), cnt / 3 - x.se.fi);
                x.se.fi += z;
                y.se.fi -= z;
                ans[x.se.se][y.se.se] += z;
                ans[y.se.se][x.se.se] -= z;
            }
        }
    }
    for (int i = 0; i < 3; i++, puts (""))
        for (int j = 0; j < 3; j++)
            printf ("%d ", ans[i][j]);
    
    return 0;
}
