#include <iostream>
#include <string>

using namespace std;

int b[5];
string s[5];
int n;
double a[3][3];

int main()
{
	cin >> s[0] >> s[1] >> s[2];
	cin >> n;
	for (int i = 0; i < n; ++i)
	{
		double x;
		cin >> s[3] >> x;
		if (s[0] == s[3])
		{
			a[0][1] -= x / 3;
			a[1][0] += x / 3;
			a[0][2] -= x / 3;
			a[2][0] += x / 3;
		}

		if (s[1] == s[3])
		{
			a[1][0] -= x / 3;
			a[0][1] += x / 3;
			a[1][2] -= x / 3;
			a[2][1] += x / 3;
		}
		if (s[2] == s[3])
		{
			a[2][0] -= x / 3;
			a[0][2] += x / 3;
			a[2][1] -= x / 3;
			a[1][2] += x / 3;
		}
	}

	for (int i = 0; i < 3; ++i)
	{
		for (int j = 0; j < 3; ++j)
			if (a[i][j] > 0)
				cout << (int)(a[i][j] + 0.5) << " ";
			else 
				cout << (int)(a[i][j] - 0.5) << " ";
		cout << endl;
	}
}