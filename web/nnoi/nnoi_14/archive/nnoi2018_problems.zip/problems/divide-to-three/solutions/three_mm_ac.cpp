#include <iostream>
#include <string>

using namespace std;

int b[5];
string s[5];
int n;
int a[3][3];

int main()
{
	cin >> s[0] >> s[1] >> s[2];
	cin >> n;
	for (int i = 0; i < n; ++i)
	{
		int x;
		cin >> s[3] >> x;
		if (s[0] == s[3])
			b[0] += x;
		if (s[1] == s[3])
			b[1] += x;
		if (s[2] == s[3])
			b[2] += x;
	}

	int q = (b[0] + b[1] + b[2]) / 3;
	a[1][0] = b[0] - q;
	a[0][1] = q - b[0];
	b[1] += b[0] - q;
	a[2][1] = b[1] - q;
	a[1][2] = q - b[1];
	for (int i = 0; i < 3; ++i)
	{
		for (int j = 0; j < 3; ++j)
			cout << a[i][j] << " ";
		cout << endl;
	}
}