names = {}
for i in range(3):
    s = input()
    names[s] = i

cur = [0] * 3

n = int(input())
for i in range(n):
    name, c = input().split()
    c = int(c)
    cur[names[name]] += c

need = sum(cur) // 3
answer = [[0] * 3 for i in range(3)]
answer[0][1] = -(cur[0] - need)
answer[1][0] = cur[0] - need
cur[1] += cur[0] - need
answer[1][2] = -(cur[1] - need)
answer[2][1] = cur[1] - need

for i in range(3):
    print(*answer[i])
