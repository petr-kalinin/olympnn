#include "testlib.h"
#include <iostream>

using namespace std;

const int MIN_NAME_LEN = 1;
const int MAX_NAME_LEN = 10;

const int MIN_N = 1;
const int MAX_N = 1e2;

const int MIN_C = 1;
const int MAX_C = 1e4;

const int ALP = 26;

string randName() {
	int len = rnd.next(MIN_NAME_LEN, MAX_NAME_LEN);
	string s = "";
	for (int i = 0; i < len; i++) {
		s += char((rnd.next(0, 1) ? 'a' : 'A') + rnd.next(0, ALP - 1));
	}
	return s;
}

int main(int argc, char* argv[])
{
    registerGen(argc, argv, 1);

    string name[3];
    for (int i = 0; i < 3; i++) {
    	name[i] = randName();
    	cout << name[i] << endl;
    }
    int n = MAX_N;
    cout << n << endl;
    int cnt = 0;
    for (int i = 0; i < n - 1; i++) {
    	int c = MAX_C;
    	cout << name[rnd.next(0, 2)] << " " << c << endl;
    	cnt += c;
    }
   	cout << name[rnd.next(0, 2)] << " " << 9999 << endl;

    return 0;
    	
}	