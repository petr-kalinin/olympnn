#include "testlib.h"
#include <string>
#include <iostream>
using namespace std;


const int MAX_A = 1e7;


int main(int argc, char* argv[]) {
    registerTestlibCmd(argc, argv);
    
    string name[3];
    map<string, int> pos;
    for (int i = 0; i < 3; i++) {
    	name[i] = inf.readLine();
    	pos[name[i]] = i;
    }
    int n = inf.readInt();
    inf.readEoln();
    int cnt[3] = {0, 0, 0};

    for (int i = 0; i < n; i++) {
   		string s = inf.readToken();
   		inf.readSpace();
   		int c = inf.readInt();
   		cnt[pos[s]] += c;
   	}
   	int a[3][3];
   	for (int i = 0; i < 3; i++) {
   		for (int j = 0; j < 3; j++) {
   			a[i][j] = ouf.readInt(-MAX_A, MAX_A);
   		}
   	}
   	for (int i = 0; i < 3; i++) {
   		for (int j = 0; j < 3; j++) {
   			if (a[i][j] + a[j][i] != 0) quitf(_wa, "a[%d][%d] + a[%d][%d] != 0", i, j, j, i);
   			cnt[i] += a[i][j];
   		}
   	}	
   	for (int i = 0; i < 2; i++) {
   		if (cnt[i] != cnt[i + 1]) quitf(_wa, "cnt[%d] != cnt[%d]", i, i + 1);
   	}	
   	quitf(_ok, "participant provided correct solution");
}