#include "testlib.h"
#include <iostream>
#include <cassert>

using namespace std;

const int MIN_NAME_LEN = 1;
const int MAX_NAME_LEN = 10;

const int MIN_N = 1;
const int MAX_N = 1e2;

const int MIN_C = 1;
const int MAX_C = 1e4;

const int ALP = 26;

string randName() {
	int len = rnd.next(MIN_NAME_LEN, MAX_NAME_LEN);
	string s = "";
	for (int i = 0; i < len; i++) {
		s += char((rnd.next(0, 1) ? 'a' : 'A') + rnd.next(0, ALP - 1));
	}
	return s;
}

int main(int argc, char* argv[])
{
    registerGen(argc, argv, 1);

    string name[3];
    for (int i = 0; i < 3; i++) {
    	name[i] = randName();
    	cout << name[i] << endl;
    }
    int n[3];
    n[0] = rnd.next(MIN_N, MAX_N - 2);
    n[1] = rnd.next(MIN_N, MAX_N - 1 - n[0]);
    n[2] = rnd.next(MIN_N, MAX_N - n[0] - n[1]);
                                  
    int sum = rnd.next(max(n[0], max(n[1], n[2])), min(n[0], min(n[1], n[2])) * MAX_C); 
    cout << n[0] + n[1] + n[2] << endl;
    vector<pair<int, int> > res;
    for (int i = 0; i < 3; i++) {
    	vector<int> g;
    	int cnt = 0;
    	for (int j = 0; j < n[i]; j++) {
    		g.push_back(1), cnt++;
    	}
    	while (cnt < sum) {
    		int j = rnd.next(0, n[i] - 1);
    		if (MAX_C == g[j]) continue;
    		int cur = rnd.next(0, min(sum - cnt, MAX_C - g[j]));
    		cnt += cur;
    		g[j] += cur;
    	}	
    	for (auto c : g) 
    		res.push_back({i, c});
    }

    shuffle(res.begin(), res.end());
    int cnt[3] = {0, 0, 0};
    for (auto p : res) {
    	cnt[p.first] += p.second;
    	cout << name[p.first] << " " << p.second << endl;
    }	
    assert(cnt[0] == cnt[1] && cnt[1] == cnt[2]);
    
    return 0;
    	
}	