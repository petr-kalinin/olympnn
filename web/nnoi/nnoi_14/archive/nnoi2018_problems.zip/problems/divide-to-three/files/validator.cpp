#include "testlib.h"
#include <iostream>

using namespace std;

const int MAX_N = 1e2;
const int MAX_C = 1e4;
const string NAME_REGEX = "[a-zA-Z]{1,10}";

int main(int argc, char **argv) {
    registerValidation(argc, argv);

    map<string, bool> names;
    for (int i = 0; i < 3; i++) {
    	string s = inf.readLine(NAME_REGEX, "name");
//     	cerr << s << endl;
    	ensuref(!names[s], "input contains equal names");
    	names[s] = true;
    }
    int n = inf.readInt(1, MAX_N, "n");
    inf.readEoln();
    int sum = 0;
    for (int i = 0; i < n; i++) {
    	string s = inf.readToken(NAME_REGEX, "name");
    	ensuref(names[s], "this person is not a fisher");
    	inf.readSpace();
    	int c = inf.readInt(1, MAX_C, "c");
    	inf.readEoln();
        sum += c;
    }
    inf.readEof();
    ensuref(sum % 3 == 0, "sum should be divisible by 3");
}
