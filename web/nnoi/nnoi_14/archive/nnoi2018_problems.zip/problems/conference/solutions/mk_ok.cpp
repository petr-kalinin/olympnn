#include <bits/stdc++.h>

using namespace std;

#define mp make_pair
#define pb push_back
#define makeunique(x) sort(all(x)), (x).resize(unique(all(x)) - (x).begin())
#define re return
#define fi first
#define se second
#define sz(x) ((int) (x).size())
#define all(x) (x).begin(), (x).end()
#define sqrt(x) sqrt(abs(x))
#define y0 y3487465
#define y1 y8687969
#define j0 j5743892
#define j1 j542893
                         
typedef vector<int> vi;
typedef long long ll;
typedef unsigned long long ull;
typedef long double ld;
typedef double D;
typedef pair<int, int> ii;
typedef vector<ii> vii;
typedef vector<string> vs;
typedef vector<vi> vvi;

template<class T> T abs(T x) { re x > 0 ? x : -x; }
template<class T> T gcd(T a, T b) { re a ? gcd (b % a, a) : b; }
template<class T> T sqr(T a) { re a * a; }
template<class T> T sgn(T a) { re a > 0 ? 1 : (a < 0 ? -1 : 0); }

#define filename "teleconference"

int n;
int m;

const int N = 1e5 + 10;
int a[N];
ll t[N];

int main () {
    freopen (filename".in", "r", stdin);
    freopen (filename".out", "w", stdout);
    scanf ("%d", &n);
    for (int i = 0; i < n; i++) {
        scanf ("%d", &a[i]);
    }
    int s, f;
    scanf ("%d%d", &s, &f); s--; f--;
    for (int i = 0; i < n; i++) {
        t[(s - i + n) % n] += a[i];
        t[(f - i + n) % n] -= a[i];
        if (s - i < 0 && f - i >= 0) t[0] += a[i], t[n] -= a[i];
    }
    pair <ll, int> ans = mp (-1, 1);
    for (int i = 0; i < n; i++) {
        ans = max (ans, mp (t[i], -i));
        t[i + 1] += t[i];
    }
    cout << -ans.se + 1 << endl;
    return 0;
}
