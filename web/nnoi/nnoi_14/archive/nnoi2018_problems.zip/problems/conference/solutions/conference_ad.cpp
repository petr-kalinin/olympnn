#include <bits/stdc++.h>  
 
using namespace std;
#define forn(i, n) for (int i = 0; i < int(n); i++)
#define re return
#define fi first
#define mp make_pair
#define se second
#define sz(a) (int)a.size()
#define prev previ
#define tm tmmm
#define div divv
typedef long long ll;
typedef pair<ll, ll> pll;
typedef pair<int, int> pii;
 
const ll CMAX = ll(1e9);
 
int n, a[2 * 100000 + 100];

int main() {
    iostream::sync_with_stdio(0), cin.tie(0);
	freopen("teleconference.in", "r", stdin);
	freopen("teleconference.out", "w", stdout);
    cin >> n;
    forn (i, n) {
        cin >> a[i + 1];
        a[i + n + 1] = a[i + 1]; 
    }
    forn (i, 2 * n)
        a[i + 1] += a[i];
    int s, f;
    cin >> s >> f;
    s--;
    f--;
    int ln = f - s + 1;
    int ans = 0, tmm = 0;
    forn (i, n) {
        if (ans < (a[n - i + f] - a[n - i + s])) {
            ans = a[n - i + f] - a[n - i + s];
            tmm = i;
        }
        //cout << n - i + s << " " << n - i + f << "\n";
        //cout << a[i + f] - a[i + s] << " ";
    }
    cout << tmm + 1 << "\n";
}