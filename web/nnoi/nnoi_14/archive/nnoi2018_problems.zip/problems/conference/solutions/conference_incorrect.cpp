#include <bits/stdc++.h>


using namespace std;

#define re return
#define sz(a) (int)a.size()
#define mp(a, b) make_pair(a, b)
#define fi first
#define se second
#define re return
#define forn(i, n) for (int i = 0; i < int(n); i++)

typedef long long ll;
typedef vector<int> vi;
typedef pair<int, int> pii;
typedef pair<long long, long long> pll;
typedef long double ld;

int n;
vector<int> a;

int main() {
	iostream::sync_with_stdio(0), cin.tie(0);
	freopen("teleconference.in", "r", stdin);
	freopen("teleconference.out", "w", stdout);
	cin >> n;
	a.resize(n);
	int s, f;
	forn (i, n) cin >> a[i];
	cin >> s >> f;
	s--;
	f--;
	int ps = 0, ans = 0;
	for (int j = 0; j < n && j * n < 700000000; j++) {
		int sum = 0;
		forn (i, n) {	
			if ((j + i) % n >= s && (j + i) % n < f)
				sum += a[i];
		}
		if (sum > ans) {
			ans = sum;
			ps = j;
		}
	}
	cout << ps + 1;
	re 0;

}
