#include <bits/stdc++.h>
#include "testlib.h"
#define forn(i,n) for (int i = 0; i < n; i++)

using namespace std;
typedef long long ll;
const int MAXN = int(1e5), CMAX = int(1e4);

map<pair<int, int>, int> ps;

int main(int argc, char **argv)
{
	registerValidation(argc, argv);
	int n = inf.readInt(2, MAXN, "n");
	inf.readEoln();
	forn (i, n) {
		int a = inf.readInt(1, CMAX, "bad a");
		if (i + 1 == n) inf.readEoln();
		else
			inf.readSpace();
	}
	int s = inf.readInt(1, n, "start");
	inf.readSpace();
	int f = inf.readInt(s + 1, n, "start");
	inf.readEoln();
	inf.readEof();
	return 0;
}
