#include "testlib.h"
#include <bits/stdc++.h>
#define re return
#define forn(i,n) for (int i = 0; i < n; i++)
#define sz(a) (int)a.size()
using namespace std;
typedef long long ll;

const int MAXN = int(1e5), CMAX = int(1e4);

int main(int argc, char **argv) {
	registerGen(argc, argv, 1);
	int n = atoi(argv[1]);
	int len = atoi(argv[2]);
	cout << n << "\n";
	forn(i, n) {
		int x = rnd.next(1, CMAX);
		if (i + 1 < n) cout << x << " ";
		else
			cout << x << "\n";
	}
	//exit(0);
	int s = rnd.next(1, n - len), f = s + len;
	cout << s << " " << f << "\n";
	return 0;
}

