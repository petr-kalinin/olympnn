#include <cstdio>
#include <cstring>
#include <algorithm>
#include <vector>
#include <iostream>
#include <cassert>
#include <cmath>
#include <string>
#include <queue>
#include <set>
#include <map>
#include <cstdlib>

using namespace std;

#define INF 1e+9
#define mp make_pair
#define pb push_back
#define fi first
#define fs first
#define se second
#define i64 long long
#define li long long
#define lint long long
#define pii pair<int, int>
#define vi vector<int>

#define forn(i, n) for (int i = 0; i < (int)n; i++)
#define fore(i, b, e) for (int i = (int)b; i <= (int)e; i++)

int main() {
#ifdef LOCAL
    freopen("inp", "r", stdin);
    //freopen("outp", "w", stdout);
#else
    // freopen(TASKNAME ".in", "r", stdin);
    // freopen(TASKNAME ".out", "w", stdout);
#endif
    int Q;
    scanf("%d", &Q);
    vi v;
    forn(q, Q) {
        int typ;
        scanf("%d", &typ);
        assert(q != 0 || typ == 1);
        if (typ == 1) {
            int x;
            scanf("%d", &x);
            assert(v.empty() || v.back() <= x);
            v.pb(x);
        } else {
            double answer = 0;
            forn(prof, (1 << v.size())) {
                int maxx = 0;
                int sum = 0;
                int cnt = 0;
                forn(i, v.size())
                    if (prof & (1 << i)) {
                        cnt++;
                        sum += v[i];
                        maxx = max(maxx, v[i]);
                    }
                if (cnt)
                    answer = max(answer, maxx - (double)sum / cnt);
            }
            printf("%.10lf\n", answer);
        }
    }
}

