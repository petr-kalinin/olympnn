#include<bits/stdc++.h>

using namespace std;

typedef long double dbl;

const dbl eps = 1e-12;

inline bool le(const dbl & l, const dbl & r){return l < r + eps;}
inline bool gr(const dbl & l, const dbl & r){return le(r, l);}

struct Line{
    dbl k, b;
	Line(){}
	Line(dbl _k, dbl _b):k(_k),b(_b){}
	dbl operator () (const dbl & x)const{return k * x + b;}
};

template<size_t MAXN>
struct ConvexHull{
	Line hull[MAXN];
	int l = 0, r = -1;
	void insert_line(dbl k, dbl b){
		Line ln(k, b);
		while((r-l+1) >= 2){
			Line &l1 = hull[r], &l2 = hull[r - 1];
			if(gr((l2.b - l1.b)*(ln.k - l1.k), (l1.b - ln.b)*(l1.k - l2.k)))--r;
			else break;
		}
		hull[++r] = ln;
	}
	dbl eval(dbl x){
		while((r-l+1) >= 2){
			if(le(hull[l](x), hull[l+1](x)))++l;
			else break;
		}
		return hull[l](x);
	}
};

ConvexHull<500005> t;

int main(){
	int n;
	long long pref = 0;
	int cnt = 0;
	int mx;
	scanf("%d", &n);
	for(int i = 0; i < n; i++){
		int type;
		scanf("%d", &type);
		if(type == 1){
			++cnt;
			t.insert_line(-1.0/cnt, -pref * 1.0/cnt);
			scanf("%d", &mx);
			pref += mx;
		}
		else{
			printf("%.15lf\n", double(mx + t.eval(mx)));
		}
	}
	return 0;
}
