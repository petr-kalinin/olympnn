#include <cstdio>
#include <vector>

using namespace std;

int main() {
    int Q;
    scanf("%d", &Q);
    vector<int> v;
    vector<long long> pref_sums(1);
    long double answer = 0;
    for (int q = 0; q < Q; ++q) {
        int typ;
        scanf("%d", &typ);
        if (typ == 1) {
            int x;
            scanf("%d", &x);
            v.push_back(x);
            pref_sums.push_back(pref_sums.back() + x);
            int start = 0;
            int finish = (int)v.size() - 1;
            while(start < finish) {
                int middle = (start + finish) / 2;
                long long sgn = (long long)-v[middle] * (middle + 1) + pref_sums[middle] + v.back();
                if (sgn <= 0) {
                    finish = middle;
                } else {
                    start = middle + 1;
                }
            }
            long double new_val = v.back() - (long double)(pref_sums[start] + v.back()) / (start + 1);
            answer = max(answer, new_val);
        } else {
            printf("%.10lf\n", (double)answer);
        }
    }
}

