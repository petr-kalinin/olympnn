#include <bits/stdc++.h>

using namespace std;

typedef long long ll;

int n;
int m;

ll sum[500001];
int x[500000];

int main () {
    scanf ("%d", &n);
    m = 0;
    sum[0] = 0;
    for (int i = 0; i < n; i++) {
        int t;
        scanf ("%d", &t);
        if (t == 1) {
            scanf ("%d", &x[m]);
            sum[m + 1] = sum[m] + x[m];
            m++;
        } else {
            if (m == 1) printf ("%.10f\n", 0.0); else {
                int l = 0, r = m - 1;
                while (r - l > 1) {
                    int s = (l + r) / 2;
                    if ((sum[s] + x[m - 1]) > (ll)x[s] * (s + 1)) l = s; else r = s;
                }
                printf ("%.10f\n", (x[m - 1] - (double)(sum[r] + x[m - 1]) / (r + 1)));
            }
        }
    }
    return 0;
}