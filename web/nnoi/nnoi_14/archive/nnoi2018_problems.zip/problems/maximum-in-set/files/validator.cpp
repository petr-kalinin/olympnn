#include <iostream>
#include <cstdio>
#include <cmath>
#include <algorithm>
#include <vector>
#include <map>
#include <set>
#include <bitset>
#include <queue>
#include <stack>
#include <sstream>
#include <cstring>
#include <numeric>
#include <ctime>

#include "testlib.h"

using namespace std;

const int maxQ = 5e5;
const int maxX = 1e9;

int main(int argc, char* argv[]) {
    registerValidation(argc, argv);

    int Q = inf.readInt(1, maxQ, "Q");
    inf.readEoln();
    int prev = 1;
    for (int i = 0; i < Q; ++i) {
        int typ = inf.readInt(1, 2, "type");
        if (typ == 1) {
            inf.readSpace();
            int x = inf.readInt(prev, maxX, "x");
            prev = x;
        } else {
            ensuref(i > 0, "first operation can not have type 2");
        }
        inf.readEoln();
    }
    inf.readEof();
}


