#include "testlib.h"
#include <iostream>
#include <cassert>

using namespace std;

const int maxQ = 5e5;

int main(int argc, char* argv[]) {
    registerGen(argc, argv, 1);
    if (argc != 4 && argc != 3) {
        cout << "usage: <first> <second> <limit-optional>";
        exit(1);
    }
    int first = atoi(argv[1]);
    assert(first > 0);
    int second = atoi(argv[2]);
    int limit = (argc == 3 ? 1e9 : atoi(argv[3]));
    assert(limit >= 1);
    int Q = first + second;
    assert(Q <= maxQ);
    vector<bool> types(Q);
    for(int i = 0; i < second; ++i)
        types[first + i] = 1;
    shuffle(types.begin() + 1, types.end());
    /*for (int x : types) {
        printf("%d ", x);
    }*/
    vector<int> values(first);
    int bound = first / 10;
    for (int i = bound; i >= 0; --i) {
        values[i] = rnd.next(1, i == bound ? limit / 10 : values[i + 1]);
        //values[i] = rnd.next(i == first - 1 ? 1 : values[i + 1], limit);
    }
    for (int i = bound + 1; i < first; ++i) {
        values[i] = rnd.next(values[0], limit);
    }
    sort(values.begin(), values.end());
    int pointer = 0;
    printf("%d\n", Q);
    for (int i = 0; i < Q; ++i) {
        if (!types[i])
            printf("1 %d\n", values[pointer++]);
        else
            printf("2\n");
    }
    assert(pointer == first);
	return 0;
}
