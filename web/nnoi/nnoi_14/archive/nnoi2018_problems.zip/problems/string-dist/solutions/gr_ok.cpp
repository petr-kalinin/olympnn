#include <bits/stdc++.h>

using namespace std;

typedef long long ll;
typedef unsigned long long ull;
typedef long double ld;

vector<int> g[26];
vector<pair<int, int> > ans;
bool was[26];

void dfs(int v) {
    was[v] = true;
    for (int to : g[v]) {
        if (!was[to]) {
            ans.emplace_back(v, to);
            dfs(to);
        }
    }
}
int main() {
#ifdef LOCAL
    freopen("in", "r", stdin);
#endif
    ios_base::sync_with_stdio(false); cin.tie(0); cout.tie(0);
    int n;
    cin >> n;
    string s, t;
    cin >> s >> t;
    for (int i = 0; i < n; i++) {
        int u = s[i] - 'a', v = t[i] - 'a';
        g[u].push_back(v);
        g[v].push_back(u);
    }
    for (int i = 0; i < 26; i++) {
        if (!was[i]) {
            dfs(i);
        }
    }

    cout << ans.size() << endl;
    for (const auto& spell : ans) {
        cout << char(spell.first + 'a') << " " << char(spell.second + 'a') << endl;
    }
}