#include <bits/stdc++.h>

using namespace std;

#define fi first
#define se second
#define mp make_pair
#define pb push_back
#define all(x) (x).begin (),(x).end()
#define sqrt(x) sqrt(abs(x))
#define re return
#define sz(x) ((int)(x).size ())
#define prev PREV
#define next NEXT

using ll = long long;
using ii = pair<int, int>;
using ld = long double;
using D = double;
using vi = vector<int>;
using vii = vector<ii>;
using vvi = vector<vi>;
using vs = vector<string>;

template<typename T> T abs (T x) { re x < 0 ? -x : x; }
template<typename T> T sgn (T x) { re x < 0 ? -1 : (x > 0 ? 1 : 0); }
template<typename T> T sqr (T x) { re x * x; }
template<typename T> T gcd (T a, T b) { re a ? gcd (b % a, a) : b; }

int n;
int m;
string s, t;
int p[26];
vector<pair<char, char> > res;

int gp (int x) {
	if (p[x] != x) p[x] = gp (p[x]);
	re p[x];
}

int main () {
	cin >> n;
	cin >> s >> t;
	for (int i = 0; i < 26; i++) p[i] = i;
	for (int i = 0; i < n; i++) {
		int a = gp (s[i] - 'a');
		int b = gp (t[i] - 'a');
		if (a != b) p[a] = b;
	}
	for (int i = 0; i < 26; i++) {
		int j = i + 1;
		while (j < 26 && gp (i) != gp (j)) j++;
		if (j < 26) res.pb (mp (i + 'a', j + 'a'));
	}
	printf ("%d\n", sz (res));
	for (int i = 0; i < sz (res); i++) printf ("%c %c\n", res[i].fi, res[i].se);
	re 0;
}