#include <iostream>
#include <cstdio>
#include <ctime>
#include <cassert>
#include <cmath>
#include <stack>
#include <set>
#include <map>
#include <vector>
#include <queue>
#include <algorithm>
#include <utility>
#include <cstdlib>
#include <cstring>
#include <string>
using namespace std;

#ifdef WIN32
    #define lld "%I64d"
#else
    #define lld "%lld"
#endif

#define mp make_pair
#define pb push_back
#define put(x) { cout << #x << " = "; cout << (x) << endl; }

typedef long long ll;
typedef long double ld;
typedef unsigned long long ull;
typedef double db;

const int M = 1e5 + 15;
const int Q = 1e9 + 7;
const int ALP = 26;

vector<int> g[M];
int used[M];
int comp[M];
vector<pair<int, int> > c;
map<pair<int, int>, int> was;

void dfs(int v, int color) {
	used[v] = true;
	comp[v] = color;
	for (int u : g[v]) {
		if (!used[u]) {
			dfs(u, color);
		}
	}
}	


int main(){
    srand(time(NULL));
#ifndef ONLINE_JUDGE
    freopen("input.txt", "r", stdin);
    freopen("output.txt", "w", stdout);
#endif
	int n;
	cin >> n;
	string s1, s2;
	cin >> s1 >> s2;
	
	for (int i = 0; i < n; i++) {
		int x = s1[i] - 'a';
		int y = s2[i] - 'a';
		if (x == y) continue;
		if (!was[{x, y}])
			c.pb({x, y});
	}
	
	int ans = Q;
	int ans_mask = 0;

	for (int mask = 0; mask < (1 << (int)c.size()); mask++) {
		for (int i = 0; i < ALP; i++) {
			g[i].resize(0);
			used[i] = false;
		}
		int cnt  = 0;
		for (int i = 0; i < (int)c.size(); i++) {
			if ((mask >> i) & 1) {
				cnt++;
				g[c[i].first].pb(c[i].second);
				g[c[i].second].pb(c[i].first);
			}
		}
		int color = 0;
		for (int i = 0; i < ALP; i++) {
			if (!used[i]) {
				dfs(i, color);
				color++;
			}
		}

		bool ok = true;
		for (int i = 0; i < n; i++) {
			if (comp[s1[i] - 'a'] != comp[s2[i] - 'a']) {
				ok = false;
				break;
			}
		}	
		if (ok) {
			if (ans > cnt) {
				ans = cnt;
				ans_mask = mask;
			}
		}	
	} 
	cout << ans << endl;
	for (int i = 0; i < (int)c.size(); i++) {
		if ((ans_mask >> i) & 1) {
			cout << char('a' + c[i].first) << " " << char('a' + c[i].second) << endl;
		}
	}	


			
    return 0;
}   