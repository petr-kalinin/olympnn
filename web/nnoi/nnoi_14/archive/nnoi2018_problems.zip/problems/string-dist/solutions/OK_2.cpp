#include <iostream>
#include <cstdio>
#include <ctime>
#include <cassert>
#include <cmath>
#include <stack>
#include <set>
#include <map>
#include <vector>
#include <queue>
#include <algorithm>
#include <utility>
#include <cstdlib>
#include <cstring>
#include <string>
using namespace std;

#ifdef WIN32
    #define lld "%I64d"
#else
    #define lld "%lld"
#endif

#define mp make_pair
#define pb push_back
#define put(x) { cout << #x << " = "; cout << (x) << endl; }

typedef long long ll;
typedef long double ld;
typedef unsigned long long ull;
typedef double db;

const int M = 1e5 + 15;
const int Q = 1e9 + 7;
const int ALP = 26;

int used[M];
vector<int> g[M];

vector<pair<int, int> > ans;

int cnt;
void dfs(int v, int p) {
	if (p != -1) ans.pb({v, p});
	used[v] = true;
	cnt++;
	for (int u : g[v]) {
		if (!used[u]) {
			dfs(u, v);
		}
	}
}



int main(){
    srand(time(NULL));
#ifndef ONLINE_JUDGE
    freopen("input.txt", "r", stdin);
    freopen("output.txt", "w", stdout);
#endif
    int n;
    cin >> n;
    string s1, s2;
    cin >> s1 >> s2;
    for (int i = 0; i < n; i++) {
    	g[s1[i] - 'a'].pb(s2[i] - 'a');
    	g[s2[i] - 'a'].pb(s1[i] - 'a');
    }
    for (int i = 0; i < ALP; i++) {
    	if (!used[i]) {
    		dfs(i, -1);
    	}
    }	
    cout << (int)ans.size() << endl;
    for (auto p : ans) {
    	char c1 = char('a' + p.first), c2 = char('a' + p.second);
    	cout << c1 << " " << c2 << endl;
    }
    return 0;
}   