#include <iostream>
#include <string>

using namespace std;

string s;
string g;
int n;

int a[40][40];
int w[40];

char x[30];
char y[30];
int ans = 0;

void iwrit(int v)
{
	int p = 0;
	for (int i = 0; i < 26; ++i)
		if (a[v][i])
		{
			p = i;
			break;
		}

	for (int j = p + 1; j < 26; ++j)
		if (a[v][j])
		{
			x[ans] = p + 'a';
			y[ans] = j + 'a';
			p = j;
			++ans;
		}
}

int main()
{
	cin >> n;
	cin >> s >> g;
	for (int i = 0; i < n; ++i)
	{
		a[s[i] - 'a'][g[i] - 'a'] = 1;
	}
	
	for (int k = 0; k < 26; ++k)
		for (int i = 0; i < 26; ++i)
			for (int j = 0; j < 26; ++j)
				if (a[i][k] && a[k][j])
					a[i][j] = 1;

	for (int i = 0; i < 26; ++i)
		if (w[i] == 0)
		{
			iwrit(i);
			for (int j = i + 1; j < 26; ++j)
			{
				int q = 1;
				for (int k = 0; k < 26; ++k)
					if (a[i][k] != a[j][k])
					{
						q = 0;
						break;
					}
				if (q)
					w[j] = 1;
			}
		}
	cout << ans << endl;
	for (int i = 0; i < ans; ++i)
		cout << x[i] << " " << y[i] << endl;
}	







