#include <iostream>
#include <string>

using namespace std;

string s;
string g;
int n;

int a[40][40];
int p[40];
int w[40];
int ans, k;

void get(int v)
{
	w[v] = 1;
	for (int i = 0; i < 26; ++i)
		if (a[v][i] == 1 && w[i] == 0)
		{
			p[i] = v;
			get(i);
		}
}

int main()
{
	cin >> n;
	cin >> s >> g;
	for (int i = 0; i < n; ++i)
	{
		a[s[i] - 'a'][g[i] - 'a'] = 1;
	}
	ans = 26;
	for (int i = 0; i < 26; ++i)
		if (w[i] == 0)
		{
			p[i] = -1;
			--ans;
			get(i);
		}
	cout << ans << endl;
	for (int i = 0; i < 26; ++i)
		if (p[i] != -1)
			cout << char(i + 'a') << " " << char(p[i] + 'a') << endl;
}	