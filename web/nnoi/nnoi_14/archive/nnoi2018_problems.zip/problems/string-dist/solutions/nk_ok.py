n = int(input())
s1 = input()
s2 = input()

s = [0] * 26
p = [i for i in range(26)]

def find(x):
    if p[x] == x:
        return x
    p[x] = find(p[x])
    return p[x]

answer = []
for i in range(n):
    a = find(ord(s1[i]) - ord('a'))
    b = find(ord(s2[i]) - ord('a'))
    if a != b:
        answer.append([chr(ord('a') + a), chr(ord('a') + b)])
        if s[a] < s[b]:
            a, b = b, a
        p[b] = a
        if s[a] == s[b]:
            s[b] += 1

print(len(answer))
for x in answer:
    print(*x)
