#include <iostream>
#include <cstdio>
#include <ctime>
#include <cassert>
#include <cmath>
#include <stack>
#include <set>
#include <map>
#include <vector>
#include <queue>
#include <algorithm>
#include <utility>
#include <cstdlib>
#include <cstring>
#include <string>
using namespace std;

#ifdef WIN32
    #define lld "%I64d"
#else
    #define lld "%lld"
#endif

#define mp make_pair
#define pb push_back
#define put(x) { cout << #x << " = "; cout << (x) << endl; }

typedef long long ll;
typedef long double ld;
typedef unsigned long long ull;
typedef double db;

const int M = 1e6 + 15;
const int Q = 1e9 + 7;


int main(){
    srand(time(NULL));
#ifndef ONLINE_JUDGE
    freopen("input.txt", "r", stdin);
    freopen("output.txt", "w", stdout);
#endif
	int n;
	cin >> n;
	string s1, s2;
	cin >> s1 >> s2;
	set<pair<int, int> >se;
	for (int i = 0; i < n; i++) {
		int x = s1[i] - 'a', y = s2[i] - 'a';
		if (x == y) continue;
		if (x > y) swap(x, y);
		se.insert({x, y});
	}
	cout << (int)se.size() << endl;
	for (auto p : se) {
		cout << char('a' + p.first) << " " << char('a' + p.second) << endl;
	}

    return 0;
}   