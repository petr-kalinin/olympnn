#include "testlib.h"
#include <iostream>

using namespace std;

const int M = 1e5 + 10;
const int ALP = 26;

int pr[M];

int get(int s) { return s == pr[s] ? s : get(pr[s]); }

bool un(int s, int f) {
	int i = get(s), j = get(f);
	if (i != j) {
		pr[i] = j;
		return true;
	}
	return false;
}

int main(int argc, char* argv[])
{
    registerGen(argc, argv, 1);
    int n = atoi(argv[1]);
   	for (int i = 0; i < ALP; i++) {
   		pr[i] = i;
   	}
   	string s1 = "", s2 = "";
   	while ((int)s1.size() < n) {
   		int c1 = rnd.next(0, ALP - 1);
   		int c2 = rnd.next(0, ALP - 1);
   		if (un(c1, c2)) {
	   		s1 += char('a' + c1);
   			s2 += char('a' + c2);
   	   	}
   	}
   	cout << (int)s1.size() << endl;
   	cout << s1 << endl;
   	cout << s2 << endl;
}	