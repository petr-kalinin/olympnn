#include "testlib.h"
#include <iostream>

using namespace std;

const int ALP = 26;


int main(int argc, char* argv[])
{
    int M = atoi(argv[1]);
    int n;
    cin >> n;
    string s1, s2;
    cin >> s1 >> s2;
    cout << M << endl;
    for (;n < M; n++) {
    	int pos = rnd.next(0, n - 1);
    	if (rnd.next(0, 2)) {
    		s1 += s1[pos];
    		s2 += s2[pos];
    	} else {
    		s1 += s2[pos];
    		s2 += s1[pos];
    	}
    }
    cout << s1 << endl;
    cout << s2 << endl;
    return 0;	
}	