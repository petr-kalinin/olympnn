#include "testlib.h"
#include <iostream>

using namespace std;

const int M = 1e5 + 10;
const int ALP = 26;

void putString(int n, int k) {
	for (int i = 0; i < n; i++) {
		cout << char('a' + rnd.next(0, k - 1));
	}
	cout << endl;
}	


int main(int argc, char* argv[])
{
    registerGen(argc, argv, 1);
    int n = atoi(argv[1]);
    int k = atoi(argv[2]);
    if (k == -1) k = ALP;
    cout << n << endl;
    putString(n, k);	
    putString(n, k);
}	