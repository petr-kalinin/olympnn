#include "testlib.h"
#include <iostream>

using namespace std;

const int M = 1e5 + 10;
const int ALP = 26;

int let[ALP];

int main(int argc, char* argv[])
{
    registerGen(argc, argv, 1);
   	string s1 = "", s2 = "";
   	for (int i = 0; i < ALP; i++) 
   		let[i] = i;
   	shuffle(let, let + ALP);
   	int pos = 0;
   	while (pos < ALP) {
   		int j = rnd.next(1, ALP - pos);
   		for (int k1 = pos; k1 < pos + j; k1++) {
   			for (int k2 = pos; k2 < pos + j; k2++) {
   				s1 += char('a' + let[k1]);
   				s2 += char('a' + let[k2]);
   			}
   		}	
   		pos += j;
   	}
   	cout << (int)s1.size() << endl;
   	cout << s1 << endl;
   	cout << s2 << endl;
}	