#include "testlib.h"
#include <string>
#include <iostream>
using namespace std;

#define pb push_back

const int ALP = 26;
vector<int> g[ALP];
int comp[ALP];
int used[ALP];

void dfs(int v, int c) {
	used[v] = true;
	comp[v] = c;
	for (auto u : g[v]) {
		if (!used[u]) {
			dfs(u, c);
		}           
	}
}

char rChar() {
	char c = ouf.readChar();
	if (c < 'a' || c > 'z') quitf(_pe, "symbol is not a small English letter");
	return c;
}

int main(int argc, char* argv[]) {
    registerTestlibCmd(argc, argv);
    
    int n = inf.readInt();
    inf.readEoln();
    string s1 = inf.readLine();
    string s2 = inf.readLine();
    int jans = ans.readInt();

    int pans = ouf.readInt();
    ouf.readEoln();
    for (int i = 0; i < pans; i++) {
    	char c1 = ouf.readToken("[a-z]{1}")[0];
    	char c2 = ouf.readToken("[a-z]{1}")[0];
    	g[c1 - 'a'].pb(c2 - 'a');
    	g[c2 - 'a'].pb(c1 - 'a');
    }

    int cnt = 0;
    for (int i = 0; i < ALP; i++) {
    	if (!used[i]) {
    		dfs(i, cnt);
    		cnt++;
    	}
    }

    for (int i = 0; i < n; i++) {
    	if (comp[s1[i] - 'a'] != comp[s2[i] - 'a']) quitf(_wa, "set of spells don't allow to convert %d symbol", i);
    }


    if (jans == pans)
        quitf(_ok, "jury and contestant agree");
    else if (jans < pans)
        quitf(_wa, "contestant have found a non-optimal answer");
    else
        quitf(_fail, "PANIC! contestant's answer is better than jury's one");
}