#include "testlib.h"
#include <string>
using namespace std;


const int MIN_LENGTH = 1;
const int MAX_LENGTH = 1e5;

int main(int argc, char **argv) {
    registerValidation(argc, argv);
    int n = inf.readInt(MIN_LENGTH, MAX_LENGTH, "n");
    inf.readEoln();
    string s1 = inf.readLine("[a-z]+");
    string s2 = inf.readLine("[a-z]+");
    ensuref((int)s1.size() == n, "Length of the first string is not n");
    ensuref((int)s2.size() == n, "Length of the second string is not n");    
    inf.readEof();
}
