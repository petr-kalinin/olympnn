#include "testlib.h"
#include <iostream>

using namespace std;

int main(int argc, char* argv[]) {
    registerGen(argc, argv, 1);

    /* Read number from command line. */
    long long n = atoll(argv[1]);
    int k = atoi(argv[2]);
    int k1 = atoi(argv[3]);
    long long min = atoll(argv[4]);
    long long max = atoll(argv[5]);
    
    vector<long long> a;
    for (int i = 0; i < k1; i++) {
        a.push_back(rnd.next(min, max));
    }
    
    cout << n << " " << k << endl;

    for (int i = 0; i < k; i++) {
        cout << a[rnd.next(0, k1 - 1)];
        if (i + 1 < k)
            cout << " ";
    }
    cout << endl;
}
