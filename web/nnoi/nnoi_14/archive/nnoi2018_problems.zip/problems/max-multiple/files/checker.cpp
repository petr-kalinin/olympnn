#include <bits/stdc++.h>
#include "testlib.h"

using namespace std;

long long readans(InStream& in, long long n, const vector<long long>& a) {
    int num = in.readInt(1, a.size()) - 1;
    long long cnt = in.readLong(0, n);
    if (cnt > n / a[num]) {
        in.quitf(_wa, "Too many butyavkas: %I64d*%I64d of %I64d", a[num], cnt, n);
    }
    return a[num] * cnt;
}

int main(int argc, char* argv[]) {
    registerTestlibCmd(argc, argv);
    
    long long n = inf.readLong();
    int k = inf.readInt();
    vector<long long> a(k);
    for (auto& x: a)
        x = inf.readLong();
    
    long long pans = readans(ouf, n, a);
    long long jans = readans(ans, n, a);
    

    if (pans < jans)
        quitf(_wa, "Jury has better solution");
    if (pans > jans)
        quitf(_fail, "Participant has better solution");
    quitf(_ok, "n=%I64d, k=%d", n, k);
}