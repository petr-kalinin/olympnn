## This line was copied from template
#  This is nk_wa.py
#
#  @author: Nikolay Kalinin
#  @date: Thu, 08 Feb 2018 20:41:17 +0300

with open("butyavki.in") as f:
    lines = f.readlines()

n, k = map(int, lines[0].split())
a = list(map(int, lines[1].split()))
ans = min([(a[x], x) for x in range(k)])[1]

with open("butyavki.out", "w") as f:
    f.write("%d %d" % (ans + 1, n // a[ans]))
