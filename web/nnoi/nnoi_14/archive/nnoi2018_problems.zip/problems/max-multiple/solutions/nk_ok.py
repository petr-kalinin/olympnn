## This line was copied from template
#  This is nk_ok.py
#
#  @author: Nikolay Kalinin
#  @date: Thu, 08 Feb 2018 20:19:12 +0300

with open("butyavki.in") as f:
    lines = f.readlines()

n, k = map(int, lines[0].split())
a = list(map(int, lines[1].split()))
ans = min([(n % a[x], x) for x in range(k)])[1]

with open("butyavki.out", "w") as f:
    f.write("%d %d\n" % (ans + 1, n // a[ans]))
