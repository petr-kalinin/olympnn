#!/usr/bin/python3
import sys
data = open("butyavki.in", "r").readlines()
n, k = map(int, data[0].split())
if n > 1000 or k > 1000:
    sys.exit(1)
a = list(map(int, data[1].split()))
min = n + 1
for i in range(len(a)):
    if a[i] > 1000:
        sys.exit(1)
    if n % a[i] < min:
        min = n % a[i]
        mini = i
open("butyavki.out", "w").write("{} {}".format(mini + 1, n // a[mini]))
