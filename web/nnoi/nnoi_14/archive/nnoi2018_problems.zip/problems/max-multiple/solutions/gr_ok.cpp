#include <bits/stdc++.h>

using namespace std;

typedef long long ll;
typedef unsigned long long ull;
typedef long double ld;

constexpr int MX = 100 * 1000 + 7;

ll a[MX];

int main() {
#ifdef LOCAL
    freopen("in", "r", stdin);
#else
    freopen("butyavki.in", "r", stdin);
    freopen("butyavki.out", "w", stdout);
#endif
    ios_base::sync_with_stdio(false); cin.tie(0); cout.tie(0);
    ll n;
    int k;
    cin >> n >> k;
    for (int i = 0; i < k; i++) {
        cin >> a[i];
    }

    ll ans = -1;
    int ansk = -1;
    for (int i = 0; i < k; i++) {
        ll x = n - n % a[i];
        if (x > ans) {
            ans = x;
            ansk = i + 1;
        }
    }

    cout << ansk << " " << n / a[ansk - 1] << endl;
}