echo [INFO]: Wiping problem 'divide-to-three'.
cd problems/divide-to-three
./wipe.sh
cd -

echo [INFO]: Wiping problem 'max-multiple'.
cd problems/max-multiple
./wipe.sh
cd -

echo [INFO]: Wiping problem 'conference'.
cd problems/conference
./wipe.sh
cd -

echo [INFO]: Wiping problem 'string-dist'.
cd problems/string-dist
./wipe.sh
cd -

echo [INFO]: Wiping problem 'pie'.
cd problems/pie
./wipe.sh
cd -

echo [INFO]: Wiping problem 'maximum-in-set'.
cd problems/maximum-in-set
./wipe.sh
cd -

echo [INFO]: Wiping russian contest statement.
cd statements/russian
./wipe.sh
cd -

