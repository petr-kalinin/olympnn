//��������� ������� 10 �����, 82 �����, ������ 3, gnu c++
//#include <stdafx.h>
#include <cmath>
#include <cstdio>
#include <cstdlib>
#include <string>
#include <vector>
#include <algorithm>
#include <ctime>
#include <cassert>

using namespace std;

bool lucky[105];

long dist[105];
vector <long> answer;
long n;

void case1()
{
	long q;
	for (q=0;q<=99;q++)
	{
		lucky[q]=((q % 10)==(q/10));
		//if (lucky[q])
		//	printf("%ld\n",q);
	}
	long maxx=0;
	for (long choice=0;choice<=99;choice++)
	{
		long delta=0;
		while(true)
		{
			if (choice-delta>=0)
				if (lucky[choice-delta])
				{
					dist[choice]=delta;
					break;
				}
			if (choice+delta<=99)
				if (lucky[delta+choice])
				{
					dist[choice]=delta;
					break;
				}
			delta++;
		}
		//printf("%ld %ld\n",choice,dist[choice]);
		maxx=max(maxx,dist[choice]);
	}
	for (q=0;q<=99;q++)
		if (dist[q]==maxx)
			answer.push_back(q);
	printf("%ld\n",answer.size());
	printf("05\n06\n");
	for (long j=2;j<answer.size();j++)
		printf("%ld\n",answer[j]);
	exit(0);
}

void print(long cifr,long amount)
{
	if (amount<=0)
		return;
	for (long j=1;j<=amount;j++)
		printf("%ld",cifr);
}

int main()
{
	freopen("tickets.in","r",stdin);
	freopen("tickets.out","w",stdout);
	scanf("%ld",&n);
	if (n==1)
		case1();
	printf("4\n");
	print(0,n);
	printf("5");
	print(0,n-1);
	printf("\n");
	
	print(0,n);
	printf("5");
	print(0,n-2);
	printf("1\n");

	print(9,n);
	printf("4");
	print(9,n-2);
	printf("8\n");

	print(9,n);
	printf("4");
	print(9,n-1);
	printf("\n");
}