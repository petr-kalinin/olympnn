//�������� ������, 11 �����, 38 �����, ������ 4, CXX: GNU C++

#include <conio.h>
#include <stdio.h>

main()
{
    int i, N, n, c, j;
    long res, tmp;
    int t[10000];
    FILE *finp, *fout;
finp=fopen("bubble.in", "r");
fout=fopen("bubble.out", "w+");
n=fscanf(finp, "%d", &N);
for (i=1;i<=N;i++)
n=fscanf(finp, "%d", &t[i]);
fclose(finp);
for (i=1;i<=N-1;i++)
{
    for (j=i+1;j<=N;j++)
    if (t[j]<t[i])
    {
        c=t[j];t[j]=t[i];t[i]=c;
    }
}
res=t[N];
if (t[N]%t[1]!=0)
res=res*(t[1]-t[N]%t[1]);
if (res%t[1]!=0)
res=res+t[N]*(t[N]%t[1]);
//if (N>2)
for (i=2;i<=N-1;i++)
{
    if (res%t[i]!=0)
    {tmp=res;
    res=res*(t[i]-t[N]%t[i]);}
    if (res%t[i]!=0)
    res=res+tmp*(t[N]%t[i]);
}
//printf("%d %d %d %d", N, t[1], t[2], t[3]);
fprintf(fout, "%d", res);
printf("%d", res);
fclose(fout);
}
