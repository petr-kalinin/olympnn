#include <iostream>
#include <fstream>
using namespace std;

struct Gem{
    int cost_a;
    int cost_b;
    bool used;
    bool operator > (Gem &a){
        return (a.cost_a<cost_a)||(a.cost_b>cost_b);
    };
    bool operator <(Gem& a){
        return (a.cost_a>cost_a)||(a.cost_b<cost_b);
    };
};


int bestGem(Gem* arr, int size)
{
    int mi=0;
    for(int i=0; i<size; i++){
        if(!(arr[mi]>arr[i])&&(!arr[i].used)) mi=i;
    }
    arr[mi].used = true;
    return mi;
}

int worstGem(Gem* arr, int size)
{
    int mi=0;
    for(int i=0; i<size; i++){
        if(!(arr[mi]<arr[i])&&(!arr[i].used)) mi=i;
    }
    arr[mi].used=true;
    return mi;
}


int main()
{
    ifstream in("treasure.in");
    ofstream out("treasure.out");

    int n;
    in>>n;

    Gem* gems = new Gem[n];

    for(int i=0; i<n; i++){
        in>>gems[i].cost_a;
        gems[i].used =false;
    }

    for(int i=0; i<n; i++){
        in>>gems[i].cost_b;
    }

    for(int i=0; i<n/2; i++){
        int min = bestGem(gems, n);
        int max = worstGem(gems, n);

        out<<min+1<<max+1<<endl;
    }



    return 0;
}
