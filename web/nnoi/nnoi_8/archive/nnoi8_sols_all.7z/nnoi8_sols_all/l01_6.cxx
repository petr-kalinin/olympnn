//��������� ������� 10 �����, 82 �����, ������ 6, gnu c++
//#include <stdafx.h>
#include <cmath>
#include <cstdio>
#include <cstdlib>
#include <string>
#include <vector>
#include <algorithm>
#include <ctime>
#include <cassert>

using namespace std;

struct elem
{
	long a;
	long b;
	long number;
};
const long maxn=5005;
bool operator <(elem first,elem second)
{
	if (first.b!=second.b)
		return(first.b<second.b);
	return(first.a>second.a);
}

long q,n;
elem a[maxn];
bool used[maxn];

int main()
{
	freopen("treasure.in","r",stdin);
	freopen("treasure.out","w",stdout);
	scanf("%ld",&n);
	long q;
	for (q=1;q<=n;q++)
	{
		scanf("%ld",&a[q].a);
		a[q].number=q;
	}
	for (q=1;q<=n;q++)
		scanf("%ld",&a[q].b);
	sort(a+1,a+n+1);
	for (long it=n;it>=1;it--) if (!used[it])
	{
		bool found=false;
		long best=0;
		for (long choice=1;choice<=n;choice++) if ((!used[choice])&&(a[choice].a>a[it].a))
		{
			if ((!found)||(a[choice].b<a[best].b))
			{
				found=true;
				best=choice;
			}
		}
		if (found)
		{
			used[it]=true;
			used[best]=true;
			printf("%ld %ld\n",a[it].number,a[best].number);
		}
	}
}