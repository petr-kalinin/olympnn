#include <iostream>
#include <fstream>
#include <stdio.h>
using namespace std;

struct Duhi{
    int type;
    float V;
};



int main()
{
    int n, m;
    ifstream in("flow.in");
    //ofstream out("flow.out");
    FILE* out = fopen("flow.out", "w");
    in>>n>>m;

    Duhi **bs = new Duhi*[n];
    for(int i=0; i<n; i++){
        bs[i] = new Duhi[m];
    }

    cerr<<"Memory OK"<<endl;

    for(int i=0; i<n; i++){
        int t;
        float v;
        in>>t>>v;
        bs[i][t-1].V = v;
    }

    cerr<<"Bottles Read OK"<<endl;

    int flows;
    in>>flows;

    for(int i=0; i<flows; i++){
        int src, dst;
        float col;
        in>>src>>dst>>col;
        for(int j=0; j<m; j++){
            bs[dst-1][j].V += bs[src-1][j].V*col;
        }
    }

    cerr<<"Flows read OK"<<endl;

    float sumV=0;
    for(int i=0; i<m; i++){
        sumV += bs[0][i].V;
    }

    for(int i=0; i<m; i++){
        float c = bs[0][i].V;

        fprintf(out, "%f ", (c/sumV)*100.0);

    }
    cerr<<"Results OK";
    delete bs;
    return 0;
}











