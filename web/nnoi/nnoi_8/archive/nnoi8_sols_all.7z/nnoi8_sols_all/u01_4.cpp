/*
    36 �����
    ������� �����
    ��: C++
    ����������: g++
*/

#include<iostream>
#include<fstream>
#include<vector>
#include<algorithm>

long gcd(long a, long b){
    if (b==0) return a;
    return gcd(b, a%b);
}

using namespace std;
int main () {
    ifstream inp ("bubble.in");
    ofstream out ("bubble.out");

    int n; inp >> n;
    long p=1, d;
    inp >> d;
    p=d;

    for (int i=1 ; i<n ; i++) {
        int x; inp >> x;
        d=gcd(d, x);
        if (x%p==0) {
            d=x/p;
            p=x*d;
        } else if (p%x!=0) {
            p *= x / d;
        }
    }
    out << p / d;
    inp.close();
    out.close();
    return 0;
}
