#include <iostream>
#include <cstdio>

using namespace std;

int main()
{
    freopen("tickets.in","r",stdin);
    freopen("tickets.out","w",stdout);
    int n;
    cin >> n;
    if (n==1)
    {
        cout << "2\n05\n94\n";
        return 0;
    }
    cout << "4\n";
    for (int i=0;i<n;i++) cout << "0";
    cout << "5";
    for (int i=1;i<n;i++) cout << "0";
    cout << "\n";
    for (int i=0;i<n;i++) cout << "0";
    cout << "5";
    for (int i=1;i<n-1;i++) cout << "0";
    cout << "1\n";
    for (int i=0;i<n;i++) cout << "9";
    cout << "4";
    for (int i=1;i<n-1;i++) cout << "9";
    cout << "8\n";
    for (int i=0;i<n;i++) cout << "9";
    cout << "4";
    for (int i=1;i<n;i++) cout << "9";
    cout << "\n";
    return 0;
}
