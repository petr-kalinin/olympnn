/*
    36 �����
    ������� �����
    ��: C++
    ����������: g++
*/

#include<iostream>
#include<fstream>
#include<vector>
#include<algorithm>
#include<utility>

using namespace std;

bool comp (pair<int, pair<int,int> > a, pair<int, pair<int,int> > b) {
    return a.second.second - b.second.second;
}

int main () {
    ifstream inp ("treasure.in");
    ofstream out ("treasure.out");

    int n; inp >> n;

    vector< pair<int, pair<int,int> > > a;
    for (int i=0 ; i<n ; i++) {
        int x;
        inp >> x;
        a.push_back(make_pair(i, make_pair(x,0)));
    }

     for (int i=0 ; i<n ; i++) {
        int x;
        inp >> x;
        a[i].second.second = x;
    }
    sort(a.begin(), a.end(), comp);
    for (int j=0 ; j<n ; j+=2) {
        int i = 0;
        while(a[i].first == -1)i++;
        for (int t=n-1 ; t>=0 ; t--) {
            if (a[t].first!= -1 && a[t].second.first >= a[i].second.first && a[i].first > -1 && t != i) {
                out << a[i].first+1 << ' ' << a[t].first+1 << endl;
                a[i].first = -1;
                a[t].first = -1;
            }
        }
    }

    for (int i = 0 ; i < n ; i++) if (a[i].first != -1) out << a[i].first+1 << ' ';



    inp.close();
    out.close();
    return 0;
}
