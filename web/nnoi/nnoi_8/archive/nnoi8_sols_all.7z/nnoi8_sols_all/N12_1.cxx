#include <iostream>
#include <cstdio>
#include <cstdlib>

using namespace std;

const int maxn=105;
const int MAXE=2500;

struct LLong
{
    int len;
    int e[MAXE];
};

typedef LLong * plong;

struct duh
{
    plong c;
    int z;
};

duh kv[maxn][maxn];
long double v[maxn];

void mul(plong ANS,int a)
{
    if (a==0)
    {
        ANS->len=0;
        return;
    }
    for (int i=0;i<ANS->len;i++)
    {
        ANS->e[i]=ANS->e[i]*a;
    }
    int t=0;
    for (int i=0;i<ANS->len;i++)
    {
        ANS->e[i]=ANS->e[i]+t;
        t=ANS->e[i]/10;
        ANS->e[i]=ANS->e[i]%10;
    }
    while (t>0)
    {
        ANS->e[ANS->len]=t%10;
        t=t/10;
        ANS->len++;
    }
}

void add(plong ANS,plong a)
{
    while (ANS->len<a->len)
    {
        ANS->e[ANS->len]=0;
        ANS->len++;
    }
    while (ANS->len>a->len)
    {
        a->e[a->len]=0;
        a->len++;
    }
    for (int i=0;i<ANS->len;i++)
    {
        ANS->e[i]=ANS->e[i]+a->e[i];
    }
    int t=0;
    for (int i=0;i<ANS->len;i++)
    {
        ANS->e[i]=ANS->e[i]+t;
        t=ANS->e[i]/10;
        ANS->e[i]=ANS->e[i]%10;
    }
    while (t>0)
    {
        ANS->e[ANS->len]=t%10;
        t=t/10;
        ANS->len++;
    }
}

void sett(plong a,int b)
{
    a->len=1;
    a->e[0]=1;
    mul(a,b);
}

void cpy(plong a,plong b)
{
    a->len=b->len;
    for (int i=0;i<a->len;i++) a->e[i]=b->e[i];
}

long double calc(plong a,int t)
{
    long double ans=0;
    for (int i=a->len-1;i>=0;i--)
    {
        ans=ans*10+a->e[i];
    }
    for (int i=0;i<t;i++) ans=ans/100.0;
    return ans;
}

int main()
{
    freopen("flow.in","r",stdin);
    freopen("flow.out","w",stdout);
    int n,m;
    cin >> n >> m;
    for (int i=1;i<=n;i++)
    {
        for (int j=1;j<=m;j++)
        {
            kv[i][j].c=new(LLong);
            kv[i][j].c->len=0;
            kv[i][j].z=0;
        }
    }
    for (int i=1;i<=n;i++)
    {
        int T,V;
        cin >> T >> V;
        sett(kv[i][T].c,V);
    }
    int k;
    cin >> k;
    for (int i=0;i<k;i++)
    {
        int s,t,a;
        cin >> s >> t >> a;
        for (int T=1;T<=m;T++)
        {
            kv[s][T].z++;
            plong tmp=new(LLong);
            int tmpz=kv[s][T].z;
            cpy(tmp,kv[s][T].c);
            mul(tmp,a);
            while (tmpz<kv[t][T].z)
            {
                tmpz++;
                mul(tmp,100);
            }
            while (tmpz>kv[t][T].z)
            {
                kv[t][T].z++;
                mul(kv[t][T].c,100);
            }
            add(kv[t][T].c,tmp);
            mul(kv[s][T].c,(100-a));
        }
    }
    int maxt=-4005;
    for (int i=1;i<=m;i++)
    {
        if (kv[1][i].c->len>0 && kv[1][i].c->len-2*kv[1][i].z>maxt) maxt=kv[1][i].c->len-2*kv[1][i].z;
    }
    int notd=0;
    if (maxt<0) notd=(-maxt)/2;
    long double allv=0;
    for (int i=1;i<=m;i++)
    {
        v[i]=calc(kv[1][i].c,kv[1][i].z-notd);
        allv+=v[i];
    }
//    cerr << allv << endl;;
    cout.precision(6);
    for (int i=1;i<=m;i++) cout << 100*v[i]/allv << ' ';
    cout << endl;
    return 0;
}
