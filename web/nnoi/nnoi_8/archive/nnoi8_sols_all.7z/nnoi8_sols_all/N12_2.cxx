#include <iostream>
#include <cstdio>
#include <algorithm>

using namespace std;

typedef long long ll;

#ifdef WIN32
    #define LLD "%I64d"
#else
    #define LLD "%lld"
#endif

struct pt
{
    ll x,y;
    inline pt(){}
    inline pt (ll _x,ll _y) {x=_x; y=_y;}
};

inline ll operator *(pt a,pt b)
{
    return a.x*b.y-a.y*b.x;
}

inline pt operator -(pt a,pt b)
{
    return pt(a.x-b.x,a.y-b.y);
}

pt p[10],q[10];
int ans[10],st[10];

int main()
{
    freopen("light.in","r",stdin);
    freopen("light.out","w",stdout);
    int NT;
    cin >> NT;
    for (int T=0;T<NT;T++)
    {
        cin >> p[1].x >> p[1].y >> p[2].x >> p[2].y >> p[3].x >> p[3].y;
        p[0]=p[3];
        p[4]=p[1];
        for (int i=1;i<=3;i++) st[i]=i;
/*        if ((p[3]-p[2])*(p[2]-p[1])>0)
        {
//            cerr << "reversed" << endl;
            reverse(p,p+5);
            st[1]=2;
            st[2]=1;
            st[3]=3;
        }*/
        cin >> q[0].x >> q[0].y >> q[1].x >> q[1].y >> q[2].x >> q[2].y;
        for (int i=0;i<3;i++) ans[i]=i+1;
        bool find=false;
        while (true)
        {
            bool can=true;
            for (int i=0;i<3;i++)
            {
                for (int j=0;j<3;j++) if (i!=j && (ans[j]+1)%3==ans[i]%3)
                {
                    int x=ans[i];
                    if (((q[i]-p[x])*(q[j]-p[x]))*((p[3]-p[2])*(p[2]-p[1]))<0) can=false;
//                    cout << i << ' ' << j << ' ' << x << ' ' << p[x].x << ' ' << p[x].y << ' ' << (q[i]-p[x])*(q[j]-p[x]) << endl;
                }
            }
//            cout << endl;
            if (can)
            {
                find=true;
                break;
            }
            if (!next_permutation(ans,ans+3)) break;
        }
        if (!find)
        {
            cout << "-1 -1 -1\n";
        } else
        {
            cout << st[ans[0]] << ' ' << st[ans[1]] << ' ' << st[ans[2]] << "\n";
        }
    }
    return 0;
}
