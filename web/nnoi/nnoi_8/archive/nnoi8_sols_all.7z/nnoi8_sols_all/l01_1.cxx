//��������� ������� 10 �����, 82 �����, ������ 1, gnu c++
//#include <stdafx.h>
#include <cmath>
#include <cstdio>
#include <cstdlib>
#include <string>
#include <vector>
#include <algorithm>
#include <ctime>
#include <cassert>

using namespace std;

const long maxn=105;

long n,m,k;
double amount[maxn][maxn];

int main()
{
	freopen("flow.in","r",stdin);
	freopen("flow.out","w",stdout);
	scanf("%ld%ld",&n,&m);
	long q;
	for (q=1;q<=n;q++)
	{
		long t1,t2;
		scanf("%ld%ld",&t1,&t2);
		amount[q][t1]=t2;
	}
	scanf("%ld",&k);
	for (long it=1;it<=k;it++)
	{
		long from,to,per;
		scanf("%ld%ld%ld",&from,&to,&per);
		if (per==0)
			continue;
		double mn=(double)per/100.0;
		for (long typ=1;typ<=m;typ++)
		{
			double temp=amount[from][typ]*mn;
			amount[from][typ]-=temp;
			amount[to][typ]+=temp;
		}
	}
	double sum=0.0;
	for (q=1;q<=m;q++)
		sum+=amount[1][q];
	for (q=1;q<=m;q++)
		printf("%0.3lf ",100.0*amount[1][q]/sum);
}