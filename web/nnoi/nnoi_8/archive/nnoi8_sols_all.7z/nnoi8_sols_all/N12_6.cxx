#include <iostream>
#include <algorithm>
#include <cstdio>

using namespace std;

const int maxn=5005;

struct tp
{
    int a,b,id;
};

bool operator <(tp a,tp b)
{
    return a.b<b.b;
}

tp p[maxn];
int pr[maxn];

inline int cnt(int a,int b)
{
    if (p[a].a<p[b].a) return p[a].b;
    else return p[b].b;
}

int main()
{
    freopen("treasure.in","r",stdin);
    freopen("treasure.out","w",stdout);
    int n;
    cin >> n;
    for (int i=0;i<n;i++) cin >> p[i].a;
    for (int i=0;i<n;i++) cin >> p[i].b;
    for (int i=0;i<n;i++) p[i].id=i+1;
    sort(p,p+n);
    for (int i=0;i<n;i+=2)
    {
        pr[i]=i+1;
        pr[i+1]=i;
    }
    srand(105);
    for (int i=0;i<5000000;i++)
    {
        int n1=rand()%n;
        int n2=n1;
        while (n2==pr[n1] || n2==n1) n2=rand()%n;
        if (cnt(n1,pr[n1])+cnt(n2,pr[n2])<cnt(n2,pr[n1])+cnt(n1,pr[n2]))
        {
            int x=pr[n1];
            int y=pr[n2];
            pr[n1]=y;
            pr[n2]=x;
            pr[x]=n2;
            pr[y]=n1;
        }
    }
    for (int i=0;i<n;i++)
    {
        if (pr[i]!=-1)
        {
            printf("%d %d\n",p[i].id,p[pr[i]].id);
            pr[pr[i]]=-1;
        }
    }
    return 0;
}
