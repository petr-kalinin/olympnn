//�������� ������, 11 �����, 38 �����, ������ 1, CXX: GNU C++

#include <conio.h>
#include <stdio.h>

main()
{
    int c, maxi, vars[5000], n, l, i, j, k, N, res[5000];
    long a[5000], b[5000], max;
    FILE *finp, *fout;
finp=fopen("treasure.in", "r");
fout=fopen("treasure.out", "w+");
n=fscanf(finp, "%d", &N);
for (i=1;i<=N;i++)
n=fscanf(finp, "%d", &a[i]);
for (i=1;i<=N;i++)
n=fscanf(finp, "%d", &b[i]);
fclose(finp);

/*for (i=1;i<=N-1;i++)
{
    for (j=i+1;j<=N;j++)
    if (b[j]<b[i])
    {
        c=b[j];b[j]=b[i];b[i]=c;
        c=a[j];a[j]=a[i];a[i]=c;
    }
}
l=1;
for (k=N;k>=1;k--)
{
if (a[k]==0) continue;
i=1; j=1;
while (i<=k)
{
    if (a[k]<a[i])
    {
        vars[j]=i;
        j++;
    }
    i++;
}
max=a[k];
for (i=1;i<=j;i++)
{
    if (a[k]-a[vars[i]]<max)
    {
        max=a[k]-a[vars[i]]; maxi=vars[i];
    }
}
res[l]=k; res[l+1]=maxi; l=l+2; a[k]=0, a[maxi]=0;
}*/
//printf("%d %d %d %d %d %d %d %d", N, K, P[1], P[2], P[3], P[4], P[5], P[6]);

for (i=1;i<=N;i++)
{
    max=400000;
    for (j=1;j<=N;j++)
    if (a[j]<max && a[j]!=0)
    {
        max=a[j]; maxi=j;
    }
    res[i]=maxi; a[maxi]=0;
}

for (i=1;i<=N;i=i+2)
{
    fprintf(fout, "%d %d\n", res[i], res[i+1]);
    printf("%d %d\n", res[i], res[i+1]);
}
fclose(fout);
}
