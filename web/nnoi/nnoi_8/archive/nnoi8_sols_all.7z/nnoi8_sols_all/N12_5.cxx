#include <iostream>
#include <cstring>
#include <algorithm>
#include <cstdio>
#include <cstdlib>
#include <cmath>

using namespace std;

/*int go(int curn,int curk,int n,int k)
{
//    cerr << "go " << curn << ' ' << curk << endl;
    if (curk==k) return pow(curk,n-curn);
    if (curn==n) return 0;
    return curk*go(curn+1,curk,n,k)+go(curn+1,curk+1,n,k);
}*/

const int maxn=20;

int a[maxn],b[maxn],sum[maxn],was[15005];
int cursum;
long long answer;
int k,n;

void go(int curk,int curn,int n)
{
    if (curk==k)
    {
        if (cursum==sum[0]*k)
        {
            answer++;
            return;
        }
        if (curn==n) return;
        for (int i=1;i<curk;i++) if (sum[i]+b[curn]<=sum[0])
        {
            cursum+=b[curn];
            sum[i]+=b[curn];
            go(curk,curn+1,n);
            cursum-=b[curn];
            sum[i]-=b[curn];
        }
        return;
    }
    if (curn==n) return;
    for (int i=1;i<curk;i++) if (sum[i]+b[curn]<=sum[0])
    {
        cursum+=b[curn];
        sum[i]+=b[curn];
        go(curk,curn+1,n);
        cursum-=b[curn];
        sum[i]-=b[curn];
    }
    if (b[curn]<=sum[0])
    {
        cursum+=b[curn];
        sum[curk]+=b[curn];
        go(curk+1,curn+1,n);
        cursum-=b[curn];
        sum[curk]-=b[curn];
    }
    go(curk,curn+1,n);
    return;
}

int main()
{
    freopen("choco.in","r",stdin);
    freopen("choco.out","w",stdout);
    cin >> n >> k;
    int allsum=0;
    for (int i=0;i<n;i++)
    {
        cin >> a[i];
        allsum+=a[i];
    }
    if (k>n)
    {
        cout << 0 << endl;
        return 0;
    }
//    cout << "sdag" << endl;
//    cout << go(0,0,1,1) << endl;
/*    for (int k=1;k<=15;k++)
    {
        int ans=0;
        for (int n=1;n<=15;n++)
        {
            ans+=go(0,0,n,k);
        }
        cout << k << " : " << ans << endl;
    }*/
//    cout << go(0,0,i,j) << ' ';
    int KM=1<<n;
    memset(sum,0,sizeof(sum));
    memset(was,0,sizeof(was));
    for (int mask=1;mask<KM;mask++)
    {
        sum[0]=0;
        int kv=0;
        for (int i=0;i<n;i++)
        {
            if (mask&(1<<i))
            {
                kv++;
                sum[0]+=a[i];
            } else
            {
                b[i-kv]=a[i];
            }
        }
        if (was[sum[0]]) continue;
        was[sum[0]]=1;
        if (sum[0]*k>allsum) continue;
        cursum=sum[0];
        go(1,0,n-kv);
    }
//    cerr << answer << endl;
    for (int i=1;i<=k;i++) answer=answer*i;
    cout << answer << endl;
    return 0;
}
