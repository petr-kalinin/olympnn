//��������� ������� 10 �����, 82 �����, ������ 5, gnu c++
//#include <stdafx.h>
#include <cmath>
#include <cstdio>
#include <cstdlib>
#include <string>
#include <vector>
#include <algorithm>
#include <ctime>
#include <cassert>
#include <iostream>

using namespace std;

const long maxn=17;
const long maxprof=33000;
const long maxsum=15005;

long n,k;
long a[maxn];
long long dp[maxn][maxprof];
vector <long> list[maxsum];
long dv[maxn];
short int bitmask[maxprof][maxn];

inline void solve(long sum)
{
	for (long it=1;it<=k+1;it++)
		for (long prof=0;prof<dv[n];prof++)
			dp[it][prof]=0;

	dp[1][0]=1;
	for (long it=1;it<=k;it++)
		for (long prof=0;prof<dv[n];prof++) if (dp[it][prof]>0)
		{
			for (long j=0;j<list[sum].size();j++)
			{
				long u=list[sum][j];
				/*bool failed=false;
				for (long r=1;r<=n;r++)
					//if ((bitmask[u][r]==1)&&(bitmask[prof][r]==1))
					if (bitmask[u][r] & bitmask[prof][r]==1)
					{
						failed=true;
						break;
					}*/
				if ((u & prof)==0)
					dp[it+1][u | prof]+=dp[it][prof];
			}
		}
}

void get_dv()
{
	dv[0]=1;
	for (long j=1;j<=n;j++)
		dv[j]=dv[j-1]*2;
}

int main()
{
	/*freopen("choco.in","w",stdout);
	printf("15 3\n");
	for (long q=1;q<=15;q++)
		printf("%ld ",q);
	fclose(stdout);*/
	freopen("choco.in","r",stdin);
	freopen("choco.out","w",stdout);
	scanf("%ld%ld",&n,&k);
	long limit=0;
	long q,prof;
	for (q=1;q<=n;q++)
	{
		scanf("%ld",&a[q]);
		limit+=a[q];
	}
	get_dv();
	
	for (prof=0;prof<dv[n];prof++)
	{
		long now=prof;
		for (long j=n;j>=1;j--)
		{
			bitmask[prof][j]=now % 2;
			now=now/2;
		}
	}
	for (prof=0;prof<dv[n];prof++)
	{
		long sum=0;
		for (long j=n;j>=1;j--)
			if (bitmask[prof][j])
				sum+=a[j];
		list[sum].push_back(prof);
	}
	long long answer=0;
	for (long sum=1;sum<=limit;sum++) if ((list[sum].size()>=k)&&(sum*k<=limit))
	{
		solve(sum);
		for (long j=1;j<dv[n];j++)
			answer+=dp[k+1][j];
	}
	cout<<answer;
}