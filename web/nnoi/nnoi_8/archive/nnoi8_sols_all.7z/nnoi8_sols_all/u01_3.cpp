/*
    36 �����
    ������� �����
    ��: C++
    ����������: g++
*/

#include<iostream>
#include<fstream>
#include<vector>
#include<algorithm>

using namespace std;
int main () {
    ifstream inp ("tickets.in");
    ofstream out ("tickets.out");

    int n; inp >> n;

    if (n==1){
        out << 2 << endl;
        out << "90" << endl;
        out << "09" << endl;
        return 0;
    }

    out << 4 << endl;

    for (int i=0 ; i<n ; i++) out << '0';
    out << '5';
    for (int i=1 ; i<n ; i++) out << '0';
    out << endl;

    for (int i=0 ; i<n ; i++) out << '0';
    out << '5';
    for (int i=2 ; i<n ; i++) out << '0';
    out << '1' << endl;

    for (int i=0 ; i<n ; i++) out << '9';
    out << '4';
    for (int i=2 ; i<n ; i++) out << '9';
    out << '8' << endl;

    for (int i=0 ; i<n ; i++) out << '9';
    out << '4';
    for (int i=2 ; i<n ; i++) out << '9';
    out << '9' << endl;

    inp.close();
    out.close();
    return 0;
}

