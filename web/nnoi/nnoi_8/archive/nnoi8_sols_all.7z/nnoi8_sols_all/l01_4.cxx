//��������� ������� 10 �����, 82 �����, ������ 4, gnu c++
//#include <stdafx.h>
#include <cmath>
#include <cstdio>
#include <cstdlib>
#include <string>
#include <vector>
#include <algorithm>
#include <ctime>
#include <cassert>
#include <iostream>

using namespace std;

//const long maxn=10005;
const long maxlen=1e7+5;

short int pr[maxlen];
long n,g,amount,cht;
long primes[1005];
long maxx[1005];

inline void print()
{
	for (long j=amount;j>=1;j--)
		printf("%ld",pr[j]);
	printf("\n");
}

/*long gcd(long x,long y)
{
	if ((x==0)||(y==0))
		return(x+y);
	if (x>y)
		return(gcd(x % y,y));
	else return(gcd(y % x,x));
}*/

/*inline void div()
{	
	long now=0;
	bool flag=false;
	for (long it=amount;it>=1;it--)
//	for (long it=1;it<=amount;it++)
	{
		now=now * 10+pr[it];
		if (now<g)
		{
			if (flag)
				printf("0");
			//now=now*10+pr[it];
		}
		else
		{
			flag=true;
			printf("%ld",now/g);
			now=now % g;
		}
	}
}*/

inline void process(long number)
{
	long ost=0;
	for (long j=1;j<=amount;j++)
	{
		long tmp=((long)pr[j])*number+ost;
		pr[j]=tmp % 10;
		ost=tmp/10;
	}
	while(ost>0)
	{
		amount++;
		pr[amount]=ost % 10;
		//pr.push_back(ost % 10);
		ost=ost/10;
	}
}

inline void get_primes()
{
	cht=0;
	for (long choice=2;choice<=1000;choice++)
	{
		bool f=false;
		for (long d=2;d*d<=choice;d++)
			if (choice % d==0)
			{
				f=true;
				break;
			}
		if (!f)
		{
			cht++;
			primes[cht]=choice;
		}
	}
}

int main()
{
	/*freopen("bubble.in","w",stdout);
	printf("10000\n");
	for (long q=1;q<=10000;q++)
		printf("999 ");
	fclose(stdout);*/
	freopen("bubble.in","r",stdin);
	freopen("bubble.out","w",stdout);
	get_primes();
	scanf("%ld",&n);
	long q;
	/*long long tocheck=1;
	for (q=1;q<=n;q++)
	{
		scanf("%ld",&mas[q]);
		tocheck=tocheck*mas[q];
		if (q==1)
			g=mas[1];
		else
		{
			long g1=gcd(g,mas[q]);
			g=g1;
		}
	}*/
	for (q=1;q<=n;q++)
	{
		long x;
		scanf("%ld",&x);
		
		for (long j=1;j<=cht;j++)
		{
			long temp=0;
			while(x % primes[j]==0)
			{
				x=x/primes[j];
				temp++;
			}
			maxx[j]=max(maxx[j],temp);
		}	
	}
	/*amount=0;
	long now=mas[1];
	while(now>0)
	{
		amount++;
		pr[amount]=now % 10;
		//pr.push_back(now % 10);
		now=now/10;
	}
	for (long it=2;it<=n;it++)
	{
		long ost=0;
		for (long j=1;j<=amount;j++)
		{
			long tmp=((long)pr[j])*mas[it]+ost;
			pr[j]=tmp % 10;
			ost=tmp/10;
		}
		while(ost>0)
		{
			amount++;
			pr[amount]=ost % 10;
			//pr.push_back(ost % 10);
			ost=ost/10;
		}
	}
	cout<<tocheck/g<<endl;
	div();
	//print();*/
	amount=1;
	pr[1]=1;
	for (long prime=1;prime<=cht;prime++)
	{
		for (long it=1;it<=maxx[prime];it++)
			process(primes[prime]);
	}
	print();	
}