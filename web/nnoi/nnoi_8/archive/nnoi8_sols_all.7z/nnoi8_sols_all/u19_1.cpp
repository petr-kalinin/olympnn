//�������� ������, 11 �����, 38 �����, ������ 1

#include <conio.h>
#include <stdio.h>

main()
{
    int n, i, k, N, M, K;
    int L[100], V[100], S[1000], T[1000], A[1000], res[100], types[100], vols[100];
    FILE *finp, *fout;
finp=fopen("flow.in", "r");
fout=fopen("flow.out", "w+");
n=fscanf(finp, "%d %d", &N, &M);
for (i=1;i<=N;i++)
n=fscanf(finp, "%d %d", &L[i], &V[i]);
n=fscanf(finp, "%d", &K);
for (k=1;k<=K;k++)
n=fscanf(finp, "%d %d %d", &S[k], &T[k], &A[k]);
fclose(finp);
for (i=1;i<=N;i++)
{
    types[]
}
//printf("%d %d %d %d %d %d %d %d", N, M, L[1], V[1], K, S[1], T[1], A[1]);
for (i=1;i<=M;i++)
{
    fprintf(fout, "%f ", res[i]);
    printf("%f ", res[i]);
}
fclose(fout);
getch();
}
