//��������� ������� 10 �����, 82 �����, ������ 2, gnu c++
//#include <stdafx.h>
#include <cmath>
#include <cstdio>
#include <cstdlib>
#include <string>
#include <vector>
#include <algorithm>
#include <ctime>
#include <cassert>
#include <iostream>

using namespace std;

const double eps=1.0e-10;

struct point
{
	double x;
	double y;
};
struct Vector
{
	double x;
	double y;
	Vector(){}
	Vector (point p1,point p2) { x=p2.x-p1.x; y=p2.y-p1.y; }
	double operator %(Vector v2) { return(x*v2.y-y*v2.x); }
	double operator *(Vector v2) { return(x*v2.x+y*v2.y); }
};

struct trian
{
	point p1;
	point p2;
	point p3;
	Vector v12;
	Vector v23;
	Vector v31;
	trian(){}
	trian(point pt1,point pt2,point pt3) { p1=pt1; p2=pt2; p3=pt3; v12=Vector(pt1,pt2); v23=Vector(pt2,pt3); v31=Vector(pt3,pt1); }
};


point p[5];
point f1,f2,f3;
bool found;
double maxx,maxy,miny,minx;
trian maintr;

/*inline double get_angle(point p1,point p2,point p3)
{
	Vector v1(p1,p2);
	Vector v2(p1,p3);
	return(atan2((double)(v1 % v2),(double)(v1 * v2)));
	//atan2(-1.0,0.0);
}*/

inline bool into(point p,trian tr)
{
	/*double sum=0.0;
	sum+=get_angle(p,tr.p1,tr.p2);
	sum+=get_angle(p,tr.p2,tr.p3);
	sum+=get_angle(p,tr.p3,tr.p1);
	return(abs(sum)>eps);*/
	Vector v1p(tr.p1,p);
	Vector v2p(tr.p2,p);
	Vector v3p(tr.p3,p);
	double t1=v1p % tr.v12;
	double t2=v2p % tr.v23;
	double t3=v3p % tr.v31;
	bool f1=(t1>=0.0)&&(t2>=0.0)&&(t3>=0.0);
	bool f2=(t1<=0.0)&&(t2<=0.0)&&(t3<=0.0);
	return(f1 || f2);
}

inline void trying(long first,long second,long third)
{
	trian tr1(p[first],p[first+1],f1);
	trian tr2(p[second],p[second+1],f2);
	trian tr3(p[third],p[third+1],f3);
	if ((!into(f1,tr2)) && (!into(f1,tr3))) return;
	if ((!into(f2,tr1)) && (!into(f2,tr3))) return;
	if ((!into(f3,tr1)) && (!into(f3,tr2))) return;
	point choice;
	for (choice.x=minx;choice.x<=maxx;choice.x+=0.3)
		for (choice.y=miny;choice.y<=maxy;choice.y+=0.3) if (into(choice,maintr))
		{
			if ((!into(choice,tr2)) && (!into(choice,tr3))&&(!into(choice,tr1))) return;
		}
	found=true;
	printf("%ld %ld %ld\n",first,second,third);
}

inline void read(point & p)
{
	scanf("%lf%lf",&p.x,&p.y);
}

int main()
{
	freopen("light.in","r",stdin);
	freopen("light.out","w",stdout);
	long tests;
	scanf("%ld",&tests);
	for (long test=1;test<=tests;test++)
	{
		for (long j=1;j<=3;j++)
			read(p[j]);
		maxx=max(max(p[1].x,p[2].x),p[3].x);
		minx=min(min(p[1].x,p[2].x),p[3].x);
		maxy=max(max(p[1].y,p[2].y),p[3].y);
		miny=min(min(p[1].y,p[2].y),p[3].y);
		maintr=trian(p[1],p[2],p[3]);
		p[4]=p[1];
		read(f1);
		read(f2);
		read(f3);
		found=false;
		trying(1,2,3);
		if (!found) trying(1,3,2);
		if (!found) trying(2,1,3);
		if (!found) trying(2,3,1);
		if (!found) trying(3,1,2);
		if (!found) trying(3,2,1);
		if (!found)
			printf("-1 -1 -1\n");
	}
}