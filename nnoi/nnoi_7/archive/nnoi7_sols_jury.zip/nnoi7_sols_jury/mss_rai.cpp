#include <bitset>
#include <cassert>
#include <fstream>

using namespace std;

const int MAXN = 35;

int n;
bitset<2 * MAXN> s1, s2, m1, m2, tmp;

long long f(int x) {
	if (x == n) return 1;
	long long res = f(x + 1);
	bitset<2 * MAXN> _s1 = s1, _s2 = s2;
	s1[x] = 1;
	tmp = s2 | (s1 << x);
	s2 = (tmp & m1) | ((tmp & m2) >> n);
	if (!(s1 & s2).count()) res += f(x + 1);
	s1 = _s1, s2 = _s2;
	return res;
}

int main() {
	ifstream input("mss.in");
	input >> n;
	assert(1 <= n && n <= MAXN);
	ofstream output("mss.out");
	for (int i = 0; i < 2 * n; i++) {
		if (i < n) m1[i] = 1;
		else m2[i] = 1;
	}
	output << f(0) << endl;
	return 0;
}
