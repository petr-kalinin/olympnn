#include<stdio.h>
#include<stdlib.h>
#include<algorithm>

using namespace std;

int x[30006];
int a[30006];
int r,l,n,w,min_n,xn,xk;

bool less_f(int i,int j){
	return (x[a[i]] < x[a[j]]);
}

int binsearch(int l, int r,int i){
	if (x[a[l]] >= x[a[i]] + w)
		return l;
	if (x[a[r]] < x[a[i]] + w)
		return -1;
	int m;
	while (r - l > 1){
		m = (r + l) / 2;
		if (x[a[m]] >= x[a[i]] + w)
			r = m;
		else
			l = m;
	}
	return r;
}

int main(){
	freopen("door.in","rt",stdin);
	freopen("door.out","wt",stdout);
	scanf("%d%d%d%d",&n,&w,&l,&r);
	x[0] = l;
	x[n+1] = r;
	a[0] = 0;
	a[n+1] = n + 1;
	if (r - l < w) {
		printf("-1");
		return 0;
	}
	for(int i = 1;i <= n; i++){
		scanf("%d",&x[i]);
		a[i] = i;
	}
	sort(a, a + n + 2, less_f);
	min_n = n + 3;
	for (int i = 0; i <= n; i++){
		r = binsearch(i + 1,n + 1,i);
		if (r == -1) break;
		if (r - i - 1 < min_n) {
			min_n = r - i - 1;
			xn = i;
			xk = r;
		}
	}
	printf("%d\n",min_n);
	for (int i = xn + 1; i < xk; i++){
		printf("%d\n",a[i]);
	}
	return 0;
}
