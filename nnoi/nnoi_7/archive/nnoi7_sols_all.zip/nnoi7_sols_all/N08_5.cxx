#include<stdio.h>
#include<stdlib.h>

using namespace std;

struct point{
	int x,y;
};

int na,nb,k;
point a[105];
point b[105];

int main(){
	freopen("sect.in","rt",stdin);
	freopen("sect.out","wt",stdout);
	scanf("%d",&k);
	for(int q = 0; q < k; q++){
		scanf("%d",&na);
		for(int i = 0; i < na; i++){
			scanf("%d%d",&a[i].x,&a[i].y);
		}
		a[na] = a[0];
		a[na+1] = a[1];
		scanf("%d",&nb);
		for(int i = 0; i < nb; i++){
			scanf("%d%d",&b[i].x,&b[i].y);
		}
		b[nb] = b[0];
		b[nb + 1] = b[1];
		int yes = 0;
		for(int i = 0; i< na; i++){
			int m = 0;
			for(int j = 0; j < nb; j++){
				//printf("x%d %d %d\n",a[i].x,b[j].x,b[j+1].x);
				if ((a[i].x == b[j].x)&&(a[i].x == b[j + 1].x)){
					if (((a[i].y <= b[j].y)&&(b[j+1].y <= a[i].y))||((a[i].y <= b[j + 1].y)&&(b[j].y <= a[i].y))){
					printf("YES\n");
					yes = 1;
					break;
					}	
				}
				if (((b[j].x < a[i].x)&&(a[i].x < b[j+1].x))||((b[j+1].x < a[i].x)&&(a[i].x < b[j].x))){
                                        if (b[j].y + 1.0 * (b[j+1].y - b[j].y)*(a[i].x - b[j].x)/(b[j+1].x - b[j].x) >= a[i].y){
                                        	m++;
                                        //	printf("m\n");
                                        }
                                }
                                if ((a[i].x == b[j+1].x)&&(a[i].x != b[j].x)&&(b[j+1].y >= a[i].y)){
                                	int kk = (j + 2)%nb;
                                	while (b[kk].x == a[i].x) 
                                		kk = (kk+1)%nb;
                                	if (((b[j].x < a[i].x)&&(a[i].x < b[kk].x))||((b[kk].x < a[i].x)&&(a[i].x < b[j].x)))
                                		m++;
                                }

			}
			if ((m % 2 == 1)&&(yes != 1)){
				printf("YES\n");
				yes = 1;
				break;
			}
			if (yes == 1) break;
		}
		if (yes != 1) {
		for(int i = 0; i< nb; i++){
			int m = 0;
			for(int j = 0; j < na; j++){
				//printf("x%d %d %d\n",a[i].x,b[j].x,b[j+1].x);
				if ((b[i].x == a[j].x)&&(b[i].x == a[j + 1].x)){
					if (((b[i].y <= a[j].y)&&(a[j+1].y <= b[i].y))||((b[i].y <= a[j + 1].y)&&(a[j].y <= b[i].y))){
					printf("YES\n");
					yes = 1;
					break;
					}	
				}
				if (((a[j].x < b[i].x)&&(b[i].x < a[j+1].x))||((a[j+1].x < b[i].x)&&(b[i].x < a[j].x))){
                                        if (a[j].y + 1.0 * (a[j+1].y - a[j].y)*(b[i].x - a[j].x)/(a[j+1].x - a[j].x) >= b[i].y){
                                        	m++;
                                        //	printf("m\n");
                                        }
                                }
                                if ((b[i].x == a[j+1].x)&&(b[i].x != a[j].x)&&(a[j+1].y >= b[i].y)){
                                	int kk = (j + 2)%na;
                                	while (a[kk].x == b[i].x) 
                                		kk = (kk+1)%na;
                                	if (((a[j].x < b[i].x)&&(b[i].x < a[kk].x))||((a[kk].x < b[i].x)&&(b[i].x < a[j].x)))
                                		m++;
                                }

			}
			if ((m % 2 == 1)&&(yes != 1)){
				printf("YES\n");
				yes = 1;
				break;
			}
			if (yes == 1) break;
		}
			
		}
		if (yes != 1)
			printf("NO\n");
	}
	return 0;
}
