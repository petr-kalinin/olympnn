#include<stdio.h>
#include<stdlib.h>
#include<algorithm>

using namespace std;
int ans[5];
int v1,v2,v;

int main(){
	freopen("flow.in","rt",stdin);
	freopen("flow.out","wt",stdout);
	scanf("%d%d%d",&v1,&v2,&v);
	ans[1] = 1;
	ans[2] = 2;
	if (v1 > v2){
		swap(ans[1],ans[2]);
		swap(v1,v2);
	}
	if ((v1 == v2)&&(v1 != v)) {
		printf("-1");
		return 0;
	}
	if (v1== v){
		printf("1\n0 %d",ans[1]);
		return 0;
	}
	if (v2== v){
		printf("1\n0 %d",ans[2]);
		return 0;
	}
	if (v % v1 == 0){
		printf("%d\n",2*(v / v1));
		for (int i = 0; i < (v / v1); i++){
			printf("0 %d\n",ans[1]);
			printf("%d %d\n",ans[1],ans[2]);
		}
		return 0;
	}
	if (v == v2 - v1){
		printf("2\n0 %d\n%d %d",ans[2],ans[2],ans[1]);
		return 0;
	}
	if ((v -(v1 - (v2 % v1))) % v1 == 0){
		printf("%d\n",2*(v2 / v1 + 1) + 2 * (v -(v1 - (v2 % v1))) / v1 + 2);
		for (int i = 0; i < (v2 / v1 + 1); i++){
			printf("0 %d\n",ans[1]);
			printf("%d %d\n",ans[1],ans[2]);
		}
		printf("%d 0\n",ans[2]);
		printf("%d %d\n",ans[1],ans[2]);
		for (int i = 0; i < (v -(v1 - (v2 % v1))); i++){
			printf("0 %d\n",ans[1]);
			printf("%d %d\n",ans[1],ans[2]);
		}
		return 0;
	}
	printf("-1");
	return 0;
}