#include <iostream>
#include <fstream>
#include <string>
using namespace std;
class Sosud{
    public:
        Sosud(int vmax){vmax=vmax;curv=0;};
        void flow(){curv=vmax;};
        void flow_to(Sosud* other){
            if(!other->over()){
                int pv = other->curv;
                other->flow();
                this->curv-=pv;
            }
        };
        void clear(){curv=0;};
        int getCurv(){return curv;};
        bool over(){return curv>=vmax;};
    private:
        int curv, vmax;


};
int main()
{
    ifstream in("flow.in");
    ofstream out("flow.out");
    int v1, v2, v;
    in>>v1>>v2>>v;
    in.close();
    int vmax = v1>v2?v1:v2;
    int vmin = v1<v2?v1:v2;
    int nmin = v1>v2?'2':'1';
    int nmax = v1<v2?'2':'1';
    if((v<vmin)||(v>vmax)){
        out<<-1;
        return 0;
    }else if(v==vmin){
        out<<"1"<<endl;
        out<<0<<" "<<(v1>v2?v2:v1)<<endl;
    }else if(v==vmax){
        out<<"1"<<endl;
        out<<0<<" "<<(v1<v2?v2:v1)<<endl;
    }else{
        int steps=0;
        string resh="";
        Sosud* big = new Sosud(vmax);
        Sosud* small = new Sosud(vmin);
        big->flow();

        Sosud* curr = big;
        while(curr->getCurv()!=v){
            if(curr->getCurv()<v){
                small->flow();
                small->flow_to(curr);
                resh+=nmin;
                resh+=" ";
                resh+=nmax;
                resh+="\n";
            }else{
                small->clear();
                curr->flow_to(small);
                resh+=nmax;
                resh+=" ";
                resh+=nmin;
                resh+="\n";
            }
        }
        out<<steps<<endl<<resh;
    }

    out.close();
    return 0;
}
