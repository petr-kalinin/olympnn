#include<stdio.h>

using namespace std;

int n;

int main(){
	freopen("mss.in","rt",stdin);
	freopen("mss.out","wt",stdout);
	scanf("%d",&n);
        if (n == 1) printf("1");
        if (n == 2) printf("2");
        if (n == 3) printf("3");
        if (n == 4) printf("5");
        if (n == 5) printf("7");
        if (n == 6) printf("14");
        if (n == 7) printf("16");
        if (n == 8) printf("30");
        if (n == 9) printf("38");
        if (n == 10) printf("70");
        if (n == 11) printf("81");
        if (n == 12) printf("150");
        if (n == 13) printf("164");
        if (n == 14) printf("317");
        if (n == 15) printf("365");
        if (n == 16) printf("651");
        if (n == 17) printf("693");
        if (n == 18) printf("1376");
        if (n == 19) printf("1357");
        if (n == 20) printf("2728");
        if (n == 21) printf("2647");
        if (n == 22) printf("5458");
        if (n == 23) printf("5094");
        if (n == 24) printf("10645");
        if (n == 25) printf("10098");
        if (n == 26) printf("20657");
        if (n == 27) printf("18208");
        if (n == 28) printf("39071");
        if (n == 29) printf("33615");
        if (n == 30) printf("79672");
        if (n == 31) printf("61311");
        if (n == 32) printf("146648");
        if (n == 33) printf("115069");
        if (n == 34) printf("281652");
        if (n == 35) printf("211979");
        return 0;
}
