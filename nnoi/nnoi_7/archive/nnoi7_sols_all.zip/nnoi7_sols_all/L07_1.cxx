//��������� �������, 9 �����, 82 �����, ������ 1, ���������� GNU C++
#include <stdio.h>

const long maxn=505;

const long dx[4]={1,0,0,-1};
const long dy[4]={0,1,-1,0};
const long opp[4]={3,2,1,0};

long a[maxn][maxn];
bool bad[maxn][maxn];
long used[maxn][maxn][4];
long n,m,code,q,k,startx,starty,startmove;

inline void dfs(long x,long y,long nap)
{
    used[x][y][nap]=code;
    for (long move=0;move<=3;move++) if (opp[nap]!=move)
    {
        long nnewx=x+dx[move];
        long nnewy=y+dy[move];
        if (a[nnewx][nnewy]==0)
            if (used[nnewx][nnewy][move]!=code) dfs(nnewx,nnewy,move);
            else
            {
               if ((nnewx==startx) &&(nnewy==starty)&&(move==startmove)) bad[startx][starty]=false;
            }
    }
}

void solve()
{
    long cht=0;
    for (startx=1;startx<=n;startx++)
        for (starty=1;starty<=m;starty++) if (a[startx][starty]==0)
            for (startmove=0;startmove<=3;startmove++)
            {
                cht++;
                code=cht;
                dfs(startx,starty,startmove);
                if (bad[startx][starty]==false) break;
            }
}

int main()
{
    freopen("deadends.in","r",stdin);
    freopen("deadends.out","w",stdout);
    scanf("%ld%ld\n",&n,&m);
    for (q=1;q<=n;q++)
    {

        for (k=1;k<=m;k++)
        {
            char c=getchar();
            if (c=='#') a[q][k]=1;
            else
            {
                a[q][k]=0;
                bad[q][k]=true;
            }
        }
        scanf("\n");
    }
    for (q=0;q<=n+1;q++)
    {
        a[q][0]=1;
        a[q][m+1]=1;
    }
    for (q=0;q<=m+1;q++)
    {
        a[0][q]=1;
        a[n+1][q]=1;
    }

    solve();

    for (q=1;q<=n;q++)
    {
        for (k=1;k<=m;k++)
            if (a[q][k]==1) printf("#");
            else if (bad[q][k]==true)printf("X");
            else printf(".");
        printf("\n");
    }
}
