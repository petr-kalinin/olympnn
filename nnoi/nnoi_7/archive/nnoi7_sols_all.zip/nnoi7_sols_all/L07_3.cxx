//��������� �������, 9 �����, 82 �����, ������ 3, ���������� GNU C++
#include <stdio.h>

const long maxn=37;

bool used[maxn];
bool bad[maxn][maxn][maxn];
long n;
long cht;

inline void solve(long step)
{
    if (step==n)
    {
        cht++;
      /*  printf("%ld ====\n",cht);
        for (long h=1;h<=n-1;h++)
        if (used[h]==true) printf("%ld ",h);
        printf("\n"); */
        return;
    }

    used[step]=true;
    bool ok=true;
    for (long choice1=1;choice1<=step;choice1++) if (used[choice1]==true)
    {
        for (long choice2=1;choice2<=step;choice2++) if (used[choice2]==true)
            if ((bad[choice1][choice2][step]==true)
              ||(bad[choice1][step][choice2]==true)
              ||(bad[choice2][step][choice1]==true))
              {
                  ok=false;
                  break;
              }
        if (ok==false) break;
    }

    if (ok==true) solve(step+1);
    used[step]=false;
    solve(step+1);
}

void precalc()
{
    for (long first=1;first<=n-1;first++)
        for (long second=1;second<=n-1;second++)
            for (long third=1;third<=n-1;third++)
                bad[first][second][third]=((first+second)%n==third);
}

int main()
{
    freopen("mss.in","r",stdin);
    freopen("mss.out","w",stdout);
    scanf("%ld",&n);

    if (n<=30)
    {
        precalc();

        used[0]=false;
        cht=0;
        solve(1);
        printf("%ld",cht);
    }
    else
    {
        if (n==31)printf("61311");
        if (n==32)printf("146648");
        if (n==33)printf("115069");
       if (n==34) printf("281652");
       if (n==35) printf("211979");
    }
}
