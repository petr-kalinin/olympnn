//��������� �������, 9 �����, 82 �����, ������ 2, ���������� GNU C++
#include <stdio.h>
#include <stdlib.h>

struct elem
{
    long x;
    long number;
};
const long maxn=30005;
const long inf=1000000000;

elem a[maxn];
long n,w,best,ansfirst,anssecond,cht;

void quicksort(long s,long f)
{
    if (s>=f) return;

    long i=s;
    long j=f;
    long m=a[s+rand()%(f-s)].x;
    while (i<=j)
    {
        while (a[i].x<m)
            i++;
        while (a[j].x>m)
            j--;
        if (i<=j)
        {
            elem temp=a[i];
            a[i]=a[j];
            a[j]=temp;
            i++;
            j--;
        }
    }
    if (i<f) quicksort(i,f);
    if (j>s) quicksort(s,j);
}

void solve()
{
    for (long choice=1;choice<=cht-1;choice++)
    {
        long start=choice+1;
        long finish=cht;
        while (start<finish)
        {
            long middle=(start+finish)/2;
            if (a[middle].x-a[choice].x>=w) finish=middle;
            else start=middle+1;
        }
        long dist=a[start].x-a[choice].x;
        if (dist>=w)
            if (start-choice-1<best)
            {
                best=start-choice-1;
                ansfirst=choice;
                anssecond=start;
            }
    }
}

int main()
{
    freopen("door.in","r",stdin);
    freopen("door.out","w",stdout);
    scanf("%ld%ld",&n,&w);
    scanf("%ld%ld",&a[1].x,&a[2].x);
    a[1].number=-1;
    a[2].number=-1;
    for (long q=1;q<=n;q++)
    {
        scanf("%ld",&a[q+2].x);
        a[q+2].number=q;
    }
    cht=n+2;

    srand(n*3+w*2);
    quicksort(1,cht);

    best=inf;
    solve();

    if (best==inf)
    {
        printf("-1");
        return 0;
    }

    printf("%ld\n",best);
    for (long q=ansfirst+1;q<=anssecond-1;q++)
        printf("%ld\n",a[q].number);
}
