#!/usr/bin/python2

import glob
import re

def area(points):
    s = 0
    pt1 = points[-1]
    for pt2 in points:
    s += pt1[1]*pt2[0] - pt1[0]*pt2[1]
    return -s

def dumpLine(line, stream):
    points = []
    absolute = False
    current = [0, 0]
    for element in line.split(' '):
    if element == 'L' or element == 'M':
        absolute = True
        continue
    if element == 'l' or element == 'm':
        absolute = False
        continue
    xy = [float(a) for a in element.split(',')]
    if absolute:
        current = xy
    else:
        current = [current[0] + xy[0], current[1] + xy[1]]
    points.append(current)
#    if area(points) < 0:
#   points.reverse()
    stream.write(str(len(points)))
    stream.write('\n')
    for pt in points:
    stream.write(str(int(pt[0])))
    stream.write(' ')
    stream.write(str(int(-pt[1])))
    stream.write('\n')

for svg in glob.glob('src/*.svg'):
    test = svg.replace('.svg', '.hand').replace('src/', '')
    print svg, " -> ", test
    with open(svg) as inp, open(test, 'w') as outp:
#   outp.write('1\n')
    lines = inp.readlines()
    lines = [x.group(1) for x in [re.match(r'\s*d="\s*(.*[^\s])\s*z"\s', x) for x in lines] if x]
    if len(lines) != 2:
        print "FAILED: Number of polygons: ", len(lines)
        exit(1)
    dumpLine(lines[0], outp)
    dumpLine(lines[1], outp)
