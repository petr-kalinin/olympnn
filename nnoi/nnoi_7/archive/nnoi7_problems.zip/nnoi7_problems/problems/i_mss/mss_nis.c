#include <stdio.h>
#include <assert.h>

typedef unsigned long long u64;
enum { MAX_N = 35 };
static int N;

static int bruteforce (int i)
{
	static u64 used = 0;
	static u64 sums = 0;
	static int numbers[MAX_N];
	static int *number = numbers;

	if (i == N) {
#ifdef TRACE
		for (int* it = numbers; it < number; it++)
			fprintf (stderr, "%d ", *it);
		fprintf (stderr, "\n");
#endif
		return 1;
	}

	int res = bruteforce (i + 1);

	long long tused = used;
	used |= 1ull << i;
	long long tsums = sums;
	*number++ = i;
	if (sums & (1ull << i))
		goto out;
	for (int* it = numbers; it < number; it++) {
		u64 mask = 1ull << ((*it + i) % N);
		if (used & mask)
			goto out;
		sums |= mask; 
	}
	res += bruteforce (i + 1);
out:
	used = tused;
	sums = tsums;
	number--;
	return res;
}

int main(void)
{
#ifndef DEBUG
	assert (freopen ("mss.in", "r", stdin) != NULL);
	assert (freopen ("mss.out", "w", stdout) != NULL);
#endif
	assert (scanf ("%d", &N) == 1);
	assert (1 <= N && N <= MAX_N);
	printf ("%d\n", bruteforce (0));
	return 0;
}
