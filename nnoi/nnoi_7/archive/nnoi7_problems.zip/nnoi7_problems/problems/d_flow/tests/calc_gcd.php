#!/usr/bin/php
<?

function gcd($a,$b){
  if ($b==0) return $a;
  else return gcd($b,$a%$b);
}

for ($i=1;$i<=20;$i++) {
  $test=sprintf("%02d",$i);
  print($test." ");
  $f=fopen($test,"r");
  fscanf($f,"%d %d %d",$v1,$v2,$v);
  fclose($f);
  $g=gcd($v1,$v2);
  print(sprintf("%6d ",$g));
  if ($v%$g==0)
     print("+ (1)");
  else print("- (2)");
  print("\n");
}
?>