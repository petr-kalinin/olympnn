#include <iostream>

using namespace std;

int main() {
	cout << 15000 << ' ' << 30000 << endl;
	cout << -30000 << ' ' << 30000 << endl;

	for (int i = 0; i < 15000; i++) {
		if (i == 0)
			cout << -29998 << ' ';
		else	
		if (i == 14999)
			cout << 29998 << endl;
		else
			cout << -29998 + 4 * i << ' ';	
			
	}

	return 0;
}	