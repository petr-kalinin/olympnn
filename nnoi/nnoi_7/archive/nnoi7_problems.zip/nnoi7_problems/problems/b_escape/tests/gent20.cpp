#include <iostream>

using namespace std;

int main() {
	cout << 30000 << ' ' << 30000 << endl;
	cout << -30000 << ' ' << 30000 << endl;

	for (int i = 0; i < 30000; i++) {
		if (i == 0)
			cout << -29999 << ' ';
		else	
		if (i == 29999)
			cout << 29999 << endl;
		else
			cout << -29999 + 2 * i << ' ';	
			
	}

	return 0;
}	