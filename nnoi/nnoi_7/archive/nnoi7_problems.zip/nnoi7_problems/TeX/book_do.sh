pushd ../problems
./dk examples
popd
latex book.tex
latex book.tex
dvips book.dvi
psbook book.ps book_f.ps
psnup -2 -s1 book_f.ps book_ff.ps
psnup -2 -s1 book.ps book_t.ps