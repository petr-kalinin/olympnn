#include <cstdio>
#include <cstring>
#include <algorithm>
#include <vector>
#include <iostream>
#include <cassert>
#include <cmath>
#include <string>
#include <queue>
#include <set>
#include <map>
#include <cstdlib>

#include "testlib.h"

#define i64 long long

using namespace std;

const int maxk = 1e7;

int counter0[maxk + 5];
int counter[maxk + 5];
int k, maxt = 0, m;
vector <int> additional;
char verdict[100];

int load_answer(InStream & stream) {
    int ans = stream.readInt(-1, m);
    if (ans == -1)
        return ans;
    memcpy(counter, counter0, sizeof(counter0));
    vector <bool> was(m, false);
    for(int i = 0; i < ans; ++i) {
        int x;
        x = stream.readInt(1, m);
        if (was[x - 1]) {
            sprintf(verdict, "Yogurt %d is taken at least twice", x);
            stream.quit(_pe, verdict);
        }
        was[x - 1] = true;
        counter[additional[x - 1]]++;
    }
    int sum = 0;
    for (int day = 0; day <= maxt; day++) {
        sum += counter[day];
        if (sum > (i64)(day + 1) * k) {
            sprintf(verdict, "Incorrect answer. First problem - day %d", day);
            stream.quit(_wa, verdict);
        }
    }
    return ans;
}

int main(int argc, char ** argv) {
    registerTestlibCmd(argc, argv);
    int n = inf.readInt();
    m = inf.readInt();
    k = inf.readInt();
    for (int i = 0; i < n; ++i) {
        int x = inf.readInt();
        maxt = max(maxt, x);
        counter0[x]++;
    }
    additional.resize(m);
    for (int i = 0; i < m; ++i) {
        additional[i] = inf.readInt();
        maxt = max(maxt, additional[i]);
    }
    int jury_ans = load_answer(ans);
    int contestant_ans = load_answer(ouf);
    if (jury_ans == -1) {
        if (contestant_ans == -1)
            quit(_ok, "-1 impossible");
        else quit(_fail, "Jury didnt find the answer but contestant did");
    }
    if (contestant_ans == -1)
        quit(_wa, "Contestand didn't find the answer but it exists");
    if (contestant_ans < jury_ans)
        quitf(_wa, "Contestant found the answer %d, jury has better answer %d", contestant_ans, jury_ans);
    if (contestant_ans == jury_ans)
        quitf(_ok, "answer is %d", jury_ans);
    quitf(_fail, "Contestant found the answer %d which is better than jury answer %d", contestant_ans, jury_ans);
}
