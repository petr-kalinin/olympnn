#include <cstdio>
#include <cstring>
#include <algorithm>
#include <vector>
#include <iostream>
#include <cassert>
#include <cmath>
#include <string>
#include <queue>
#include <set>
#include <map>
#include <cstdlib>

#include "testlib.h"

using namespace std;

#define INF 1e+9
#define mp make_pair
#define pb push_back
#define fi first
#define fs first
#define se second
#define i64 long long
#define li long long
#define lint long long
#define pii pair<int, int>
#define vi vector<int>

#define forn(i, n) for (int i = 0; i < (int)n; i++)
#define fore(i, b, e) for (int i = (int)b; i <= (int)e; i++)

int t, k;

void gen_and_print(int n, bool flag) {
    int v = t / 10 + 1;
    int r = t / 30 + 1;
    int center = t / 2;
    vi cnt(t + 1, 0);
    forn(i, n) {
        if (rnd.next(v) == 0) {
            center = rnd.next(t);
        }
        int val;
        if (flag) {
            while (true) {
                val = rnd.next(max(0, center - r), min(center + r, t));
                if (cnt[val] == k) {
                    center = rnd.next(t);
                    continue;
                }
                cnt[val]++;
                break;
            }
        } else {
            val = rnd.next(max(0, center - r), min(center + r, t));
        }
        
        printf("%d", val);
        if (i != n - 1)
            printf(" ");
    }
    printf("\n");

}

int main(int argc, char ** argv) {
    registerGen(argc, argv, 1);
    if (argc != 5 && argc != 4) {
        printf("usage: <N> <M> <K> <T> (optional)");
        exit(0);
    }
    t = argc == 4 ? 1e7 : atoi(argv[4]);

    int n = atoi(argv[1]);
    int m = atoi(argv[2]);
    k = atoi(argv[3]);
    printf("%d %d %d\n", n, m, k);
    gen_and_print(n, true);
    gen_and_print(m, false);
}

