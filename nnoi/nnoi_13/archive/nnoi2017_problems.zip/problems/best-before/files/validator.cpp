#include "testlib.h"

const int maxn = 1e6;
const int maxT = 1e7;

int main(int argc, char ** argv)
{
    registerValidation(argc, argv);

    int n = inf.readInt(1, maxn, "n");
    inf.readSpace();
    int m = inf.readInt(1, maxn, "m");
    inf.readSpace();
    int k = inf.readInt(1, n + m, "k");
    inf.readEoln();
    for (int i = 1; i <= n; i++)
    {
        int t = inf.readInt(0, maxT, "expire time");
        if (i != n)
            inf.readSpace();
    }
    inf.readEoln();
    for (int i = 1; i <= m; i++) {
        int t = inf.readInt(0, maxT, "expire time");
        if (i != m)
            inf.readSpace();
    }
    inf.readEoln();
    inf.readEof();
    return 0;
}