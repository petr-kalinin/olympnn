#include <cstdio>
#include <cstring>
#include <algorithm>
#include <vector>
#include <iostream>
#include <cassert>
#include <cmath>
#include <string>
#include <queue>
#include <set>
#include <map>
#include <cstdlib>

#include "testlib.h"

using namespace std;

#define INF 1e+9
#define mp make_pair
#define pb push_back
#define fi first
#define fs first
#define se second
#define i64 long long
#define li long long
#define lint long long
#define pii pair<int, int>
#define vi vector<int>

#define forn(i, n) for (int i = 0; i < (int)n; i++)
#define fore(i, b, e) for (int i = (int)b; i <= (int)e; i++)

int t, k;

void gen_and_print(int n, bool flag) {
    int v = t / 10 + 1;
    int r = t / 30 + 1;
    int center = t / 2;
    vi cnt(t + 1, 0);
    vi result(n);
    forn(i, n) {
        if (rnd.next(v) == 0) {
            center = rnd.next(t);
        }
        int val;
        if (flag) {
            while(true) {
                val = rnd.next(max(0, center - r), min(center + r, t));
                if (cnt[val] > k) {
                    center = rnd.next(t);
                    continue;
                }
                cnt[val]++;
                break;
            }
        } else {
            val = rnd.next(max(0, center - r), min(center + r, t));
        }
        result[i] = val;
    }
    if (flag) {
        int crit_pos = -1;
        int sum = 0;
        forn(j, t + 1) {
            sum += cnt[j];
            if (sum + 1 > k * (j + 1)) {
                crit_pos = j;
                break;
            }
        }
        assert(crit_pos != -1);
        int change_pos = rnd.next(crit_pos + 1, n - 1);
        result[change_pos] = crit_pos;
    }
    forn(j, n) {
        printf("%d", result[j]);
        if (j != n - 1)
            printf(" ");
    }
    printf("\n");

}

int main(int argc, char ** argv) {
    registerGen(argc, argv, 1);
    if (argc != 4) {
        printf("usage: <N> <M> <K>");
        exit(0);
    }
    int n = atoi(argv[1]);
    int m = atoi(argv[2]);
    k = atoi(argv[3]);
    t = n / k;
    printf("%d %d %d\n", n, m, k);
    gen_and_print(n, true);
    gen_and_print(m, false);
}
