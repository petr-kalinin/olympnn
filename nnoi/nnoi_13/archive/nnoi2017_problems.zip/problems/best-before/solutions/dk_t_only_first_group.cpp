#include <cstdio>
#include <cstring>
#include <algorithm>
#include <vector>
#include <iostream>
#include <cassert>
#include <cmath>
#include <string>
#include <queue>
#include <set>
#include <map>
#include <cstdlib>

using namespace std;

#define INF 1e+9
#define mp make_pair
#define pb push_back
#define fi first
#define fs first
#define se second
#define i64 long long
#define li long long
#define lint long long
#define pii pair<int, int>
#define vi vector<int>

#define forn(i, n) for (int i = 0; i < (int)n; i++)
#define fore(i, b, e) for (int i = (int)b; i <= (int)e; i++)

const int maxk = 1e7;

vi lst[maxk + 5];
int used[maxk + 5];

int main() {
#ifdef LOCAL
    freopen("inp", "r", stdin);
    //freopen("outp", "w", stdout);
#endif
    int n, m, k;
    scanf("%d%d%d", &n, &m, &k);
    assert(n <= 10000 && m <= 10000 && k <= 10000);
    int maxt = 0;
    forn(j, n) {
        int x;
        scanf("%d", &x);
        assert(x <= 10000);
        assert(x >= 0 && x <= maxk);
        maxt = max(maxt, x);
        used[x]++;
    }
    int carry = 0;
    for (int t = maxt; t >= 0; t--) {
        used[t] += carry;
        if (used[t] > k) {
            carry = used[t] - k;
            used[t] = k;
        } else {
            carry = 0;
        }
    }
    if (carry > 0) {
        printf("-1");
        exit(0);
    }
    forn(j, m) {
        int x;
        scanf("%d", &x);
        assert(x <= 10000);
        assert(x >= 0 && x <= maxk);
        maxt = max(maxt, x);
        lst[x].pb(j + 1);
    }
    int pointer = maxt;
    vi ans;
    for (int add = maxt; add >= 0; add--) {
        pointer = min(pointer, add);
        bool fail = false;
        for (int number : lst[add]) {
            while(pointer >= 0 && used[pointer] == k) {
                pointer--;
            }
            if (pointer < 0) {
                fail = true;
                break;
            }
            used[pointer]++;
            ans.pb(number);
        }
        if (fail)
            break;
    }
    fprintf(stderr, "%d\n", (int)ans.size());
    printf("%d\n", (int)ans.size());
    for (int x : ans)
        printf("%d ", x);
}

