#include <cstdio>
#include <cstring>
#include <algorithm>
#include <vector>
#include <iostream>
#include <cassert>
#include <cmath>
#include <string>
#include <queue>
#include <set>
#include <map>
#include <cstdlib>

using namespace std;

#define INF 1e+9
#define mp make_pair
#define pb push_back
#define fi first
#define fs first
#define se second
#define i64 long long
#define li long long
#define lint long long
#define pii pair<int, int>
#define vi vector<int>

#define forn(i, n) for (int i = 0; i < (int)n; i++)
#define fore(i, b, e) for (int i = (int)b; i <= (int)e; i++)

const int maxk = 1e7+5;

int suff[maxk];
vi lst[maxk];
int counter[maxk];

inline int calc_taken(int j, int x) {
    return suff[j] < x ? lst[j].size() : min((int)lst[j].size(), max(0, x - suff[j + 1]));
}

int maxt = 0, k;

inline bool check(int x) {
    int sum = 0;
    fore(day, 0, maxt) {
        sum += counter[day];
        sum += calc_taken(day, x);
        if (sum > (i64)(day + 1) * k)
            return false;
    }
    return true;
}

int main() {
#ifdef LOCAL
    freopen("inp", "r", stdin);
    //freopen("outp", "w", stdout);
#endif
    int n, m;
    scanf("%d%d%d", &n, &m, &k);
    forn(i, n) {
        int x;
        scanf("%d", &x);
        maxt = max(maxt, x);
        counter[x]++;
    }
    forn(j, m) {
        int x;
        scanf("%d", &x);
        maxt = max(maxt, x);
        lst[x].pb(j + 1);
    }
    //fore(j, 0, maxt)
    //    printf("counter[%d] = %d\n", j, counter[j]);
    for (int j = maxt; j >= 0; j--) {
        suff[j] = suff[j + 1] + lst[j].size();
        //printf("suff[%d] = %d\n", j, suff[j]);
    }
    for (int start = m; start >= 0; start--)
        if (check(start)) {
            printf("%d\n", start);
            for (int j = maxt; j >= 0; j--) {
                int taken = calc_taken(j, start);
                forn(h, taken)
                    printf("%d ", lst[j][h]); 
            }
            exit(0);
        }
    printf("-1");
}

