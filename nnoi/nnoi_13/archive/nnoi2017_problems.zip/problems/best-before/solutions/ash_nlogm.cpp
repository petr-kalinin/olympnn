#include <iostream>
#include <cstdio>
#include <cstdlib>
#include <cmath>
#include <algorithm>
#include <vector>
#include <map>
#include <set>
#include <bitset>
#include <queue>
#include <stack>
#include <sstream>
#include <cstring>
#include <numeric>
#include <ctime>

#define re return
#define fi first
#define se second
#define mp make_pair
#define pb push_back
#define all(x) (x).begin(), (x).end()
#define sz(x) ((int) (x).size())
#define rep(i, n) for (int i = 0; i < (n); i++)
#define rrep(i, n) for (int i = (n) - 1; i >= 0; i--)
#define y0 y32479
#define y1 y95874
#define fill(x, y) memset(x, y, sizeof(x))
#define sqr(x) ((x) * (x))
#define sqrt(x) sqrt(abs(x))
#define unq(x) (x.resize(unique(all(x)) - x.begin()))
#define spc(i,n) " \n"[i == n - 1]
#define next next239
#define prev prev239

using namespace std;

typedef vector<int> vi;
typedef vector<vi> vvi;
typedef pair<int, int> ii;
typedef vector<ii> vii;
typedef vector<string> vs;
typedef double D;
typedef long double LD;
typedef long long ll;
typedef pair<ll, ll> pll;
typedef vector<ll> vll;

template<class T> T abs(T x) { return x > 0 ? x : -x;}

int m;
int n;
int k;
int ans;

int nint() {
	int x;
	scanf("%d", &x);
	re x;
}

vi v1;
vii v2;

int check(int c) {
	vi v3(c);
	rep(i, c)
		v3[c - i - 1] = v2[i].fi;
	vi v(c + sz(v1));
	merge(all(v1), all(v3), v.begin());
	for (int i = 0; i < sz(v); i += k)
		if (v[i] < i / k)
			re 0;

	re 1;
}

int main() {

#ifdef LOCAL_BOBER
	freopen("input.txt", "r", stdin);
	//freopen("output.txt", "w", stdout);
#else
	//freopen("input.txt", "r", stdin);
	//freopen("output.txt", "w", stdout);
#endif

	cin >> n >> m >> k;
	rep(i, n)
		v1.pb(nint());
	rep(i, m)
		v2.pb({nint(), i});

	sort(all(v1));
	sort(all(v2));
	reverse(all(v2));

	int l = 0, r = sz(v2), ans = -1;
	while (l <= r) {
		int c = (l + r) / 2;
		if (check(c)) {
			ans = c;
			l = c + 1;
		}
		else
			r = c - 1;
	}
	cout << ans << endl;
	rep(i, ans)
		cout << v2[i].se + 1 << ' ';
	cout << endl;

	re 0;
}









