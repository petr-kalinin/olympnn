#include <bits/stdc++.h>

using namespace std;

#define mp make_pair
#define pb push_back
#define makeunique(x) sort(all(x)), (x).resize(unique(x) - (x).begin())
#define re return
#define fi first
#define se second
#define sz(x) ((int) (x).size())
#define all(x) (x).begin(), (x).end()
#define sqrt(x) sqrt(abs(x))
#define y0 y3487465
#define y1 y8687969
#define j0 j5743892
#define j1 j542893
                         
typedef vector<int> vi;
typedef long long ll;
typedef unsigned long long ull;
typedef long double ld;
typedef double D;
typedef pair<int, int> ii;
typedef vector<ii> vii;
typedef vector<string> vs;
typedef vector<vi> vvi;

template<class T> T abs(T x) { re x > 0 ? x : -x; }
template<class T> T gcd(T a, T b) { re a ? gcd (b % a, a) : b; }
template<class T> T sqr(T a) { re a * a; }
template<class T> T sgn(T a) { re a > 0 ? 1 : (a < 0 ? -1 : 0); }

#define filename ""

int n;
int m;

const int N = 1e6 + 10;
const int M = 1e7 + 10;
int a[N], q[M];
set <ii> p[2 * N];
ii b[N];

int main () {
//	freopen (filename".in", "r", stdin);
//	freopen (filename".out", "w", stdout);
	int k;
	scanf ("%d%d%d", &n, &m, &k);
	for (int i = 0; i < n; i++) scanf ("%d", &a[i]);
	for (int i = 0; i < m; i++) {
		int x;
		scanf ("%d", &x);
		b[i] = mp (x, i);
	}
	sort (a, a + n);
	sort (b, b + m);
	for (int i = 0; i < n; i++) {
		int cur = a[i] - i / k;
		if (cur < 0) {
			printf ("-1\n");
			return 0;
		}
		p[i % k].insert (mp (cur, i));
	}
	vi ans;
	a[n] = 1e9;
	int last = k - 1;
	for (int i = 0, j = 0; j < m; ) {
		if (a[i] <= b[j].fi) { p[i % k].erase(mp (a[i] - i / k, i)); i++; }
		else if (a[i] > b[j].fi) {
			if (p[last].size() > 0) {
				int cur = p[last].begin()->fi;
				if (cur >= q[last] + 1) {
					if (b[j].fi - (sz (ans) + i) / k >= 0) {
						q[last]++;
						last = (last - 1 + k) % k;
						ans.pb (b[j].se);
					}
				}
			} else {
				if (b[j].fi - (sz (ans) + i) / k >= 0) {
					q[last]++;
					last = (last - 1 + k) % k;
					ans.pb (b[j].se);
				}
			}
			j++;
		}
	}
	printf ("%d\n", sz (ans));
	for (int i = 0; i < sz (ans); i++) printf ("%d ", ans[i] + 1);
	return 0;
}
