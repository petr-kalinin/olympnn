#include <cstdio>
#include <iostream>
#include <vector>
#include <algorithm>

int place(std::vector<int>& slots, const std::vector<std::pair<int,int>>& a, int k, std::vector<bool>& used) {
    int cur = a.size() - 1;
    int res = 0;
    for (int i=slots.size()-1; i>=0; i--) {
        while (cur>=0 && a[cur].first>=i && slots[i]<k) {
            slots[i]++;
            used[cur] = true;
            res++;
            cur--;
        }
    }
    return res;
}

int main() {
    int n,m,k;
    scanf("%d%d%d", &n, &m, &k);
    std::vector<std::pair<int, int>> have(n), can(m);
    for (int i=0; i<n; i++) {
        scanf("%d", &have[i].first);
        have[i].second = i;
    }
    for (int i=0; i<m; i++) {
        scanf("%d", &can[i].first);
        can[i].second = i;
    }
    std::sort(have.begin(), have.end());
    std::sort(can.begin(), can.end());
    int max = std::max(have.back().first, can.back().first);
    std::vector<int> slots(max+1, 0);
    std::vector<bool> used0(n);
    int res = place(slots, have, k, used0);
    std::vector<bool> used(m, false);
    res = place(slots, can, k, used);
    printf("%d\n", res);
    for (int i=0; i<m; i++)
        if (used[i])
            printf("%d ", can[i].second + 1);
    return 0;
}
