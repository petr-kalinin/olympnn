#include "testlib.h"

using namespace std;


int main(int argc, char* argv[]) {
    registerGen(argc, argv, 1);
    int maxx = atoi(argv[1]);
    int maxr = atoi(argv[2]);
    int t = atoi(argv[3]);
    printf("%d\n", t);
    for (int i = 0; i < t; i++) {
  		double x = rnd.next(-maxx, maxx);
    	double y = rnd.next(-maxx, maxx);
    	double r = rnd.next(1, maxr);
		printf("%.5f %.5f %.5f\n", x, y, r);
	}	
	return 0;
}	