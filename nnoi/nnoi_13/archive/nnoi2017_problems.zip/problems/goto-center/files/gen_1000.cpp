#include "testlib.h"

using namespace std;

const double M = 10000;

int main(int argc, char* argv[]) {
    registerGen(argc, argv, 1);
    int t = 10000;
    printf("%d\n", t);
   	printf("%.7f %.7f %.7f\n", M, M, M);
   	printf("%.7f %.7f %.7f\n", M, -M, M);
    printf("%.7f %.7f %.7f\n", -M, M, M);
    printf("%.7f %.7f %.7f\n", -M, -M, M);
    for (int i=0; i<(t - 4)/4; i++) {
	    double dx = rnd.next(0.01) + 0.99;
   		double dy = rnd.next(0.01) + 0.99;        
   		double dr = rnd.next(0.01) + 0.99;        
      	printf("%.7f %.7f %.7f\n", M*dx, M*dy, M*dr);
   	    printf("%.7f %.7f %.7f\n", M*dx, -M*dy, M*dr);
        printf("%.7f %.7f %.7f\n", -M*dx, M*dy, M*dr);
        printf("%.7f %.7f %.7f\n", -M*dx, -M*dy, M*dr);
    }
	return 0;
}	