#include "testlib.h"

using namespace std;


int main(int argc, char* argv[]) {
    registerGen(argc, argv, 1);
    int t = atoi(argv[1]);
    printf("%d\n", t);
    for (int i = 0; i < t; i++) {
        double x = rnd.next(9000, 10000);
        double y = rnd.next(9000, 10000);
        double r = rnd.next(9000, 10000);
        if (rnd.next(0, 1)) {
        	x *= -1;
        }
        if (rnd.next(0, 1)) {
        	y *= -1;
        }
    	printf("%.5f %.5f %.5f\n", x, y, r);
    }
    return 0;
}	