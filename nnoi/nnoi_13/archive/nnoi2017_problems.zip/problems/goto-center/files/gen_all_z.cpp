#include "testlib.h"

using namespace std;


int main(int argc, char* argv[]) {
    registerGen(argc, argv, 1);
 	vector<pair<pair<int, int>, int> > g;
	for (int x = -4; x <= 4; x++) {
		for (int y = -4; y <= 4; y++) {
			for (int r = 1; r <= 4; r++) {
				g.push_back(make_pair(make_pair(x, y), r));
			}
		}
	}
	int t = g.size();
	printf("%d\n", t);

	for (int i = 0; i < t; i++) {
		printf("%.5f %.5f %.5f\n", (double)g[i].first.first, (double)g[i].first.second, (double)g[i].second);
	} 
	return 0;
}	