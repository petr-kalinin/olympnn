#include "testlib.h"

using namespace std;


const int M = 10000;

void pu(int x, int y, int r) {
	printf("%.7f %.7f %.7f\n", (double)x, (double)y, (double)r);
}	

int main(int argc, char* argv[]) {
    registerGen(argc, argv, 1);
    int t = (10000 / 6) * 6;
    printf("%d\n", t);
    for (int i = 0; i < t / 6; i++) {
    	int x = rnd.next(-M, M);
    	int r = rnd.next(1, M);
    	pu(x, 0, r);
    	pu(0, x, r);
    	pu(r, 0, r);
    	pu(0, r, r);
    	pu(x, -x, r);
    	pu(x, x, r);
    }
	return 0;
}	