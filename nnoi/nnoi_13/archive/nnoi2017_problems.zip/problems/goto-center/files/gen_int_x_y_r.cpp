#include "testlib.h"

using namespace std;


int main(int argc, char* argv[]) {
    registerGen(argc, argv, 1);
    printf("1\n");
    int x = atoi(argv[1]);
    int y = atoi(argv[2]);
    int r = atoi(argv[3]);
	printf("%.5f %.5f %.5f\n", (double)x, (double)y, (double)r);
	return 0;
}	