#include "testlib.h"

using namespace std;


int main(int argc, char* argv[]) {
    registerGen(argc, argv, 1);
    int maxx = atoi(argv[1]);
    int maxr = atoi(argv[2]);
    int dx = atoi(argv[3]);
    int dy = atoi(argv[4]);
    int dr = atoi(argv[5]);
    int t = atoi(argv[6]);
    printf("%d\n", t);
    for (int i = 0; i < t; i++) {
	    double x = rnd.next(maxx + 0.) + dx;
   		double y = rnd.next(maxx + 0.) + dy;
    	double r = rnd.next(maxr + 0.) + dr;
        if (rnd.next(0, 1)) {
        	x *= -1;
        }    	
        if (rnd.next(0, 1)) {
        	y *= -1;
        }    	
		printf("%.7f %.7f %.7f\n", x, y, r);
	}
	return 0;
}	