#include "testlib.h"
#include <string>
#include <iostream>
using namespace std;

typedef double db;
const int maxx = 10000;

int main(int argc, char ** argv){
	registerInteraction(argc, argv);
	int t = inf.readInt();
	printf("%d\n", t);
	fflush(stdout);
	inf.readEoln();
	for (int i = 0; i < t; i++) {
		db x = inf.readDouble();
		inf.readSpace();
		db y = inf.readDouble();
		inf.readSpace();
		db r = inf.readDouble();	
		int left = 5;
		bool ok = false;
		while (left > 0) {
			left--;
			char c = ouf.readChar();
			ouf.readSpace();
			db x1 = ouf.readDouble();
			ouf.readSpace();
			db y1 = ouf.readDouble();
			ouf.readEoln();
			if (c != '?' && c != 'A') {
				quitf(_wa, "incorrect quiery");
			}
			if (c == 'A') {
			    ok = true;
				tout.precision(20);
			   	tout << x1 << ' ' << y1 << endl;
			   	break;
			}
			if (c == '?') {
			    if (abs(x1) > maxx || abs(y1) > maxx) {
			    	quitf(_wa, "incorrect quiery");
			    }
				printf("%.10f\n", abs(r - sqrt((x - x1) * (x - x1) + (y - y1) * (y - y1))));
				fflush(stdout);
	
			}
		} 
		inf.readEoln();
		if (!ok) {
		    quitf(_wa, "too many questions");
		}
	}	
	quitf(_ok, "ok");
	return 0;
}