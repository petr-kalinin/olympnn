#include "testlib.h"
#include <cmath>

using namespace std;

const double EPS = 1E-6 + 1E-10;
const double EPS1 = 1E-4 + 1E-10;
const double EPS2 = 1E-2 + 1E-10;

double diff(double a, double b) {
    return abs(a-b) / max(1.0, abs(b));
}

int main(int argc, char * argv[])
{
    setName("compare two sequences of doubles, max absolute or relative error = %.7lf", EPS);
    registerTestlibCmd(argc, argv);

    int n = 0;
    double j, p;
    int t = inf.readInt();
    inf.readEoln();
    double maxDelta = 0;
    for (int tt = 0; tt < t; tt++) {
        for (int i = 0; i < 2; i++) 
        {
            n++;
            j = inf.readDouble();
            p = ouf.readDouble();
            double delta = diff(j, p);
            if (delta > maxDelta)
                maxDelta = delta;
        }
        j = inf.readDouble();
    
    }
    if (maxDelta < EPS) {
        quitf(_ok, "%d tests, worst delta %lf", n, maxDelta);
    } else if (maxDelta < EPS1) {
        quitf(_pc(1), "%d tests, worst delta %lf", n, maxDelta);
    } else if (maxDelta < EPS2) {
        quitf(_pc(2), "%d tests, worst delta %lf", n, maxDelta);
    } else {
        quitf(_wa, "%d tests, worst delta %lf", n, maxDelta);
    }
}