#include "testlib.h"
#include <string>
using namespace std;

typedef double db;

const int MinPre = 0;
const int MaxPre = 100;
const db Coor = 1e4;
const db Rad = 1e4;

int main(int argc, char **argv) {
    registerValidation(argc, argv);
    int t = inf.readInt(1, 1e4);
    inf.readEoln();
    for (int i = 0; i < t; i++) {
        db x = inf.readDouble(-Coor, Coor, "x");
        inf.readSpace();
        db y = inf.readDouble(-Coor, Coor, "y");
        inf.readSpace();
	    db r = inf.readDouble(0, Coor, "r");
	    ensuref(r > 0, "Radius should not be 0");    
	    inf.readEoln();
    }
    inf.readEof();     	
}
