#include <cstdio>
#include <vector>
#include <cmath>
#include <ctime>
#include <cassert>
#include <algorithm>
#include <cstdlib>
#include <iostream>
using namespace std;

const int M = 1e4;
const double eps = 1e-6;

double dist(double x, double y) {
	printf("? %.10f %.10f\n", x, y);
	fflush(stdout);
	double res;
	scanf("%lf", &res);
	return res;
}

double rand_double(int range) {
	return (rand() % 2 ? 1 : -1) * (rand() % (range - 1) + 1.) / (rand() % (range - 1) + 1.);
}	


double x4, y4, r4;
bool cmp(pair<pair<double, double>, double> a, pair<pair<double, double>, double> b) {
	return abs(r4 - abs(sqrt((x4 - a.first.first) * (x4 - a.first.first) + (y4 - a.first.second) * (y4 - a.first.second)) - a.second)) < 
		   abs(r4 - abs(sqrt((x4 - b.first.first) * (x4 - b.first.first) + (y4 - b.first.second) * (y4 - b.first.second)) - b.second));
}
int main() {
	srand(time(NULL));
	int t;
	cin>>t;
	while (t--) {
	double C1 = rand() % 50 + 1;//rand_double(M);
	double C2 = rand() % 50 + 1;//rand_double(M);
	double r1 = dist(0, 0);
	double r2 = dist(-C1, 0);
	double r3 = dist(-C2, 0);
	//x4 = rand_double(M), y4 = rand_double(M);
	x4 = rand() % 500 + 1, y4 = rand() % 500 + 1;
	r4 = dist(x4, y4);
	vector<pair<pair<double, double>, double> > answer;
   	for (int tq1 = -1; tq1 < 2; tq1 += 2) {
   		for (int tq2 = -1; tq2 < 2; tq2 += 2) {
   			for (int tq3 = -1; tq3 < 2; tq3 += 2) {
   				double R1 = tq1 * r1, R2 = tq2 * r2, R3 = tq3 * r3;
   				//assert(abs(R1 - R2) > eps);
   				//assert(abs(R1 - R3) > eps);
   				double a1 = 2 * C1, b1 = 2 * (R2 - R1), c1 = R2 * R2 - R1 * R1 - C1 * C1;
   				double a2 = 2 * C2, b2 = 2 * (R3 - R1), c2 = R3 * R3 - R1 * R1 - C2 * C2;
   		
   				double x = (abs(c1 * b2 - c2 * b1) < eps) ? 0 : (c1 * b2 - c2 * b1) / (a1 * b2 - a2 * b1);
   				double R = (c1 - a1 * x) / b1;
   				double y = sqrt(R * R - 2 * R * R1 + R1 * R1 - x * x);
   				answer.push_back(make_pair(make_pair(x, y), R));
   				answer.push_back(make_pair(make_pair(x, -y), R));
   		   	}
   		}
  	}
  	sort(answer.begin(), answer.end(), cmp);
  	printf("A %.10f %.10f\n", answer[0].first.first, answer[0].first.second);
  	fflush(stdout);
  	}
  	return 0;
}                                                                                                                     