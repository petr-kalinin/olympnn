#include <bits/stdc++.h>

using namespace std;

#define mp make_pair
#define pb push_back
#define makeunique(x) sort(all(x)), (x).resize(unique(x) - (x).begin())
#define re return
#define fi first
#define se second
#define sz(x) ((int) (x).size())
#define all(x) (x).begin(), (x).end()
#define sqrt(x) sqrt(abs(x))
#define y0 y3487465
#define y1 y8687969
#define j0 j5743892
#define j1 j542893
                         
typedef vector<int> vi;
typedef long long ll;
typedef unsigned long long ull;
typedef long double ld;
typedef double D;
typedef pair<int, int> ii;
typedef vector<ii> vii;
typedef vector<string> vs;
typedef vector<vi> vvi;

template<class T> T abs(T x) { re x > 0 ? x : -x; }
template<class T> T gcd(T a, T b) { re a ? gcd (b % a, a) : b; }
template<class T> T sqr(T a) { re a * a; }
template<class T> T sgn(T a) { re a > 0 ? 1 : (a < 0 ? -1 : 0); }

#define filename ""

int n;
int m;

double 	x[4] = {0, -1, -2, -3},
		y[4] = {0, -1, -2, -2}, 
		l[4];

double x0, y0, r0;

double query(double x, double y)
{
	double l;
	printf ("? %0.10lf %0.10lf\n", x, y); fflush (stdout);
//	double x0 = 3, y0 = 4, r0 = 3;
	scanf ("%lf", &l);
//	l = abs (sqrt(sqr(x - x0) + sqr(y - y0)) - r0);
	return l;
}

double ans_err, x_ans, y_ans;
double c[3], dl[3];

double error (double x, double y, double r)
{
	double e = 0;
	for (int i = 0; i < 4; i++) e += abs (sqr (x - ::x[i]) + sqr(y - ::y[i]) - sqr(r + l[i]));
	return e;
}

double det (double a00, double a01, double a02, double a10, double a11, double a12, double a20, double a21, double a22)
{
	return 	(a00 * a11 * a22 + a01 * a12 * a20 + a02 * a10 * a21) -
			(a02 * a11 * a20 + a01 * a10 * a22 + a00 * a12 * a21);
}

void solve ()
{
/*	for (int j = 0; j < 3; j++) 		
		dl[j] = l[j] - l[j + 1];
	double r;
		r = (c[0] - c[1]) / (2 * (dl[0] - dl[1]));
	double x = c[2] / 2 - dl[2] * r;
	double y = (c[1] - c[2]) / 2 - (dl[1] - dl[2]) * r;*/
	double D = 	det (2 * (x[0] - x[1]), 2 * (y[0] - y[1]), 2 * (l[0] - l[1]), 
					 2 * (x[1] - x[2]), 2 * (y[1] - y[2]), 2 * (l[1] - l[2]),
					 2 * (x[2] - x[3]), 2 * (y[2] - y[3]), 2 * (l[2] - l[3]));
	double Dx =	det (c[0], 2 * (y[0] - y[1]), 2 * (l[0] - l[1]), 
					 c[1], 2 * (y[1] - y[2]), 2 * (l[1] - l[2]),
					 c[2], 2 * (y[2] - y[3]), 2 * (l[2] - l[3]));
	double Dy =	det (2 * (x[0] - x[1]), c[0], 2 * (l[0] - l[1]), 
					 2 * (x[1] - x[2]), c[1], 2 * (l[1] - l[2]),
					 2 * (x[2] - x[3]), c[2], 2 * (l[2] - l[3]));
	double Dr = det (2 * (x[0] - x[1]), 2 * (y[0] - y[1]), c[0], 
					 2 * (x[1] - x[2]), 2 * (y[1] - y[2]), c[1],
					 2 * (x[2] - x[3]), 2 * (y[2] - y[3]), c[2]);
	double x = Dx / D;
	double y = Dy / D;
	double r = Dr / D;
	double cur_err = error (x, y, r);
//	cout << x << " " << y << " " << r << endl;
	if (cur_err < ans_err) {
		ans_err = cur_err;
		x_ans = x;
		y_ans = y;
	}
}

int main () {
//	freopen (filename".in", "r", stdin);
//	freopen (filename".out", "w", stdout);
	int T;
	scanf ("%d", &T);
	for (int j = 0; j < 4; j++) {
		x[j] = rand () % 20000 - 10000;
		y[j] = rand () % 20000 - 10000;
	}
	for (int i = 0; i < T; i++) {
//		scanf ("%lf %lf %lf\n", &x0, &y0, &r0);
		for (int j = 0; j < 4; j++) {
			//x[j] = rand () % 20000 - 10000;
			//y[j] = rand () % 20000 - 10000;
			l[j] = query (x[j], y[j]);
		}

		for (int j = 0; j < 3; j++) 
			c[j] = (sqr(l[j + 1]) - sqr(l[j])) + (sqr(x[j]) - sqr(x[j + 1])) + (sqr(y[j]) - sqr(y[j + 1]));
		ans_err = 1e9;
		for (int s0 = 0; s0 < 2; s0++, l[0] *= -1)
			for (int s1 = 0; s1 < 2; s1++, l[1] *= -1)
				for (int s2 = 0; s2 < 2; s2++, l[2] *= -1)
					for (int s3 = 0; s3 < 2; s3++, l[3] *= -1)
						solve ();
		printf ("A %0.10lf %0.10lf\n", x_ans, y_ans);
//		double q = sqrt(sqr(x_ans - x0) + sqr(y_ans - y0));
//		if (q > 0.001) printf ("%d %0.10lf %0.10lf\n", i, ans_err, q);
	}
	return 0;
}
