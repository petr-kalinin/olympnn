#include <cstdio>
#include <vector>
#include <cmath>
#include <ctime>
#include <cassert>
#include <algorithm>
#include <cstdlib>
#include <iostream>
using namespace std;

const int M = 1e4;
const double eps = 1e-3;


long double dist(long double x, long double y) {
	printf("? %.10f %.10f\n", (double)x, (double)y);
	fflush(stdout);
	double res;
	scanf("%lf", &res);
	return res;
}


int seed = 0;
int n_rand() {
	seed = (seed * 41 + 137) % 239;
	return seed;
}

long double x4, y4, r4;
bool cmp(pair<pair<long double, long double>, long double> a, pair<pair<long double, long double>, long double> b) {
	return abs(r4 - abs(sqrt((x4 - a.first.first) * (x4 - a.first.first) + (y4 - a.first.second) * (y4 - a.first.second)) - a.second)) < 
		   abs(r4 - abs(sqrt((x4 - b.first.first) * (x4 - b.first.first) + (y4 - b.first.second) * (y4 - b.first.second)) - b.second));
}
int main() {
	srand(time(NULL));
	int t;
	cin >> t;
	while (t--){
	seed = 3;
	long double C1 = n_rand(); 
	long double C2 = n_rand();
	long double r1 = dist(0, 0);
	long double r2 = dist(-C1, 0);
	long double r3 = dist(-C2, 0);
	x4 = n_rand(), y4 = n_rand();
	r4 = dist(x4, y4);
	vector<pair<pair<long double, long double>, long double> > answer;
   	for (int tq1 = -1; tq1 < 2; tq1 += 2) {
   		for (int tq2 = -1; tq2 < 2; tq2 += 2) {
   			for (int tq3 = -1; tq3 < 2; tq3 += 2) {
   				long double R1 = tq1 * r1, R2 = tq2 * r2, R3 = tq3 * r3;
   				assert(abs(R1 - R2) > eps);
   				assert(abs(R1 - R3) > eps);
   				long double a1 = 2 * C1, b1 = 2 * (R2 - R1), c1 = R2 * R2 - R1 * R1 - C1 * C1;
   				long double a2 = 2 * C2, b2 = 2 * (R3 - R1), c2 = R3 * R3 - R1 * R1 - C2 * C2;
   				long double x = (c1 * b2 - c2 * b1) / (a1 * b2 - a2 * b1);
   				long double R = (c1 - a1 * x) / b1;
   				long double y = sqrt(R * R - 2 * R * R1 + R1 * R1 - x * x);
   				answer.push_back(make_pair(make_pair(x, y), R));
   				answer.push_back(make_pair(make_pair(x, -y), R));
   		   	}
   		}
  	}
  	sort(answer.begin(), answer.end(), cmp);
  	printf("A %.10f %.10f\n", (double)answer[0].first.first, (double)answer[0].first.second);    
  	fflush(stdout);
  	}
  	return 0;
}                                                                                                                     