#include <iostream>
#include <cstdio>
#include <ctime>
#include <cassert>
#include <cmath>
#include <stack>
#include <set>
#include <map>
#include <vector>
#include <queue>
#include <algorithm>
#include <utility>
#include <cstdlib>
#include <cstring>
#include <string>
using namespace std;

#ifdef WIN32
    #define lld "%I64d"
#else
    #define lld "%lld"
#endif

#define mp make_pair
#define pb push_back
#define put(x) { cout << #x << " = "; cout << (x) << endl; }

typedef long long ll;
typedef long double ld;
typedef unsigned long long ull;
typedef double db;

const int M = 1e6 + 15;
const int Q = 1e9 + 7;

const ld eps = 1e-5;
int p[4];
ld A[5][5], a[5][5];
int inv[24];
int x[5], y[5];
ld r[5];
ld R[5];
vector<pair<pair<ld, ld>, ld > > ans;

void st() {
	for (int i = 0; i < 4; i++)
		p[i] = i;
}

ld det() {
	st();
	ld res = 0;
	for (int i = 0; i < 24; i++) {
		ld c = 1.;
		for (int j = 0; j < 4; j++) {
			c *= a[p[j]][j];
	   	}
	   	if (inv[i] % 2)  {
	   		c = -c;
	   	}
	   	res += c;
	   	next_permutation(p, p + 4);
	}
	return res;
}	

void fil(int q) {
	for (int i = 0; i < 4; i++) {
		for (int j = 0; j < 4; j++) {
			a[i][j] = A[i][j];
		}
   	}

   	for (int i = 0; i < 4; i++) {
   		a[i][q] = A[i][4];
   	}   
}

void print() {
	for (int i = 0; i < 4; i++) {
		for (int j = 0; j < 4; j++) {
			printf("%.5f ", (db)a[i][j]);
		}
		printf("\n");
	}
	printf("\n");
}
void solve() {

	ld d, d1, d2, d3;
	fil(4), d = det();
	//printf("%.5f", (db)d);
	if (abs(d) < eps)
		return;
	fil(0), d1 = det();
	fil(1), d2 = det();
	fil(2), d3 = det();
	//printf("%.5f %.5f %.5f\n", (db)(d1 / d), (db)(d2 / d), (db)(d3 / d));
	if (d3 / d > 0)
		ans.pb(mp(mp(d1 / d, d2 / d), d3 / d));
}
		

int  my_rand() {
	return rand() % 2000 - 1000;
}                          


ld XX = 1.43, YY = 32.23, RR = 143.1;
int main(){
    srand(time(NULL));
#ifndef ONLINE_JUDGE
    //freopen("input.txt", "r", stdin);
    //freopen("output.txt", "w", stdout);
#endif
	st();
	for (int i = 0; i < 24; i++) {
		for (int j = 0; j < 4; j++) 
			for (int k = j + 1; k < 4; k++) 
				if (p[j] > p[k]) 
					inv[i]++;
		next_permutation(p, p + 4);
	}
	int T;
	cin >> T;
	/*for (int i = 0; i< 4; i++)
		for (int j= 0; j < 5; j++)
			cin >>A[i][j];
	solve();
	return 0;  */
	while (T--) {
		for (int i = 0; i < 4; i++) {
			x[i] = my_rand();
			y[i] = my_rand();
			printf("? %d %d\n", x[i], y[i]);
			fflush(stdout);
			double res;
			scanf("%lf", &res);
			//res = abs(RR - sqrt((x[i] - XX) * (x[i] - XX) + (y[i] - YY) * (y[i] - YY)));
			r[i] = res;
		}
	   	ans.resize(0);
		for (int mask = 0; mask < 16; mask++) {
			for (int i = 0; i < 4; i++) 
				R[i] =  ((mask >> i) & 1) ? r[i] : -r[i];
			for (int i = 0; i < 4; i++) 
				A[i][0] = -2 * x[i], A[i][1] = -2 * y[i], A[i][2] = 2 * R[i], A[i][3] = 1, A[i][4] = R[i] * R[i] - x[i] * x[i] - y[i] * y[i];
			solve();
		}	
		ld E = 1e18, xa = -1, ya = -1;
		for (int i = 0; i < (int)ans.size(); i++) {
			ld xxx = ans[i].first.first, yyy = ans[i].first.second, zzz = ans[i].second;
			//printf("B x=%.5f y=%.5f r=%.5f\n", (db)xxx, (db)yyy, (db)zzz);
			ld er=0.;
			for (int j = 0; j < 4; j++) {
				er += (db)abs(r[j] - abs(zzz - sqrt((x[j] - xxx) * (x[j] - xxx) + (y[j] - yyy) * (y[j] - yyy))));
			}
			if (er < E) {
				E = er;
				xa = xxx, ya = yyy;
			}
		}	
		printf("A %.10f %.10f\n", (db)xa, (db)ya);
		fflush(stdout);
	}
    return 0;
}   