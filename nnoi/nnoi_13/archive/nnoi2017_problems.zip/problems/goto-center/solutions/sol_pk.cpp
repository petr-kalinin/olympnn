#include <iostream>
#include <fstream>
#include <random>
#include <cassert>
#include <cmath>

using namespace std;

const double MAX_VAL = 1e4;

int test = 0, failed = 0;
std::ofstream pic("pic.svg");
std::random_device random;
std::mt19937 randomEngine(random());
std::uniform_real_distribution<double> coord_dist(-MAX_VAL, MAX_VAL);
std::uniform_real_distribution<double> r_dist(0, MAX_VAL);
double real_x, real_y, real_r;

void generate() {
    real_x = coord_dist(randomEngine);
    real_y = coord_dist(randomEngine);
    real_r = r_dist(randomEngine);
    //std::cout << "Real coordinate generated are " << real_x << " " << real_y << " " << real_r << std::endl;
}

double ask(double x, double y) {
    /*double ans = abs(sqrt((x-real_x)*(x-real_x)+(y-real_y)*(y-real_y)) - real_r);
    ans = ((long long int)(ans*1e10))/1e10;
    if (test == 1) {
        std::string color= "0000ff";
        pic << "<circle r=\"1\" cx=\"" << x << "\" cy=\"" << y << "\" style=\"fill:#" << color << ";\" />" << std::endl;
    }
    return ans;*/
    //std::cout << "? " << x << " " << y << std::endl;
    printf("? %lf %lf\n", x, y);
    fflush(stdout);
    double res;
    scanf("%lf", &res);
    return res;
}

void find_center(double* x, double* y, double* r, double* alpha, double& xc, double& yc, double& rc) {
    double a[4][5];
    for (int i=0; i<4; i++) {
        a[i][0] = 2*x[i];
        a[i][1] = 2*y[i];
        a[i][2] = 2*r[i]*alpha[i];
        a[i][3] = 1;
        a[i][4] = x[i]*x[i]+y[i]*y[i]-r[i]*r[i];
    }
    /*
    std::cout << "-----" << std::endl;
    for (int q=0; q<4; q++) {
        std::cout << x[q] << " " << y[q] << " " << r[q] << " " << alpha[q] << std::endl;
    }
    std::cout << "-----" << std::endl;
    for (int q=0; q<4; q++) {
        for (int w = 0; w < 5; w++) {
            std::cout << a[q][w] << " ";
        }
        std::cout << std::endl;
    }
    std::cout << std::endl;
     */
    for (int i=0; i<4; i++) {
        /*
        double max = abs(a[i][i]);
        int maxj = i;
        for (int j=i+1; j<4; j++) {
            if (abs(a[j][i]) > max) {
                max = abs(a[j][i]);
                maxj = j;
            }
        }
        for (int j=i; j<5; j++) {
            double t = a[i][j];
            a[i][j] = a[maxj][j];
            a[maxj][j] = t;
        }*/
        for (int j=i+1; j<4; j++) {
            double coeff = a[j][i]/a[i][i];
            for (int k=i; k<5; k++) {
                a[j][k] -= coeff*a[i][k];
            }
        }
        /*
        for (int q=0; q<4; q++) {
            for (int w = 0; w < 5; w++) {
                std::cout << a[q][w] << " ";
            }
            std::cout << std::endl;
        }
        std::cout << std::endl;
         */
    }
    double ans[4];
    for (int i=3; i>=0; i--) {
        for (int j=i+1; j<4; j++) {
            a[i][4] -= a[i][j] * ans[j];
        }
        ans[i] = a[i][4]/a[i][i];
    }
    //std::cout << "ans=" << ans[0] << " " << ans[1] << " " << ans[2] << " " << ans[3] << std::endl;
    xc = ans[0];
    yc = ans[1];
    rc = ans[2];
}

double diff(double a, double b)
{
    return abs(a - b) / max(abs(a), 1.0);
}

void answer(double xc, double yc, double r) {
    //std::cout << "A " << xc << " " << yc << std::endl;
    printf("A %lf %lf\n", xc, yc);
    fflush(stdout);
/*
    if ((diff(xc, real_x) > 1e-6) || (diff(yc, real_y) > 1e-6)) {
        failed++;
        std::cout
        << " Real: " << real_x << " " << real_y << " " << real_r << std::endl
        << " Guessed: " << xc << " " << yc << " " << r << std::endl
        << " Fraction: " << failed << "/" << test << " (" << 1.0*failed/test << std::endl;
        std::cout << "Wrong!" << std::endl;
        pic << "<circle r=\"0.3\" cx=\"" << real_x << "\" cy=\"" << real_y << "\" style=\"fill:#ff8800;\" />" << std::endl;
        //exit(1);
    } else {
        if (test % 1000000 != 0)
            return;
        std::cout
        << " Real: " << real_x << " " << real_y << " " << real_r << std::endl
        << " Guessed: " << xc << " " << yc << " " << r << std::endl
        << " Fraction: " << failed << "/" << test << " (" << 1.0*failed/test << std::endl;
        std::cout << "Correct!" << std::endl;
        //pic << "<circle r=\"0.3\" cx=\"" << real_x << "\" cy=\"" << real_y << "\" style=\"fill:#00ff00;\" />" << std::endl;
    }
*/
}

void solve() {
    double x[4] = {MAX_VAL*0.97, MAX_VAL*0.95, -MAX_VAL*0.93, -MAX_VAL*0.98};
    double y[4] = {MAX_VAL*0.93, -MAX_VAL*0.96, -MAX_VAL*0.92, MAX_VAL*0.99};
    double r[4], alpha[4];

    for (int i=0; i<4; i++) {
        r[i] = ask(x[i], y[i]);
    }
    double mind = 1e10;
    double minx, miny, minr;
    for(int mask = 0; mask<16; mask++) {
        int t = mask;
        for (int i=0; i<4; i++) {
            alpha[i] = (t%2) ? 1 : -1;
            t /= 2;
        }
        assert(t == 0);
        double xc, yc, rc;
        find_center(x, y, r, alpha, xc, yc, rc);
        double curd = 0;
        for (int i=0; i<4; i++) {
            double curr = abs(sqrt((x[i]-xc)*(x[i]-xc)+(y[i]-yc)*(y[i]-yc))-rc);
            curr = abs(curr - r[i]);
            if (curr > curd)
                curd = curr;
        }
        //std::cout << "Curd: " << xc <<" " << yc << " " << rc << " => " << curd << std::endl;
        if (curd < mind) {
            mind = curd;
            minx = xc;
            miny = yc;
            minr = rc;
        }
    }
    //std::cout << "Best d= " << mind << std::endl;
    assert(mind < 1e10);
    answer(minx, miny, minr);
}

int main() {
    std::cout.precision(20);
    int nt;
    cin >> nt;
    //while (true) {
        //test++;
    for (int test=0; test<nt; test++) {
        generate();
        solve();
    }
    return 0;
}