#include <bits/stdc++.h>

using namespace std;

using ll = long long;
using ld = long double;
using D = double;
using uint = unsigned int;

#ifdef WIN32
    #define LLD "%I64d"
#else
    #define LLD "%lld"
#endif

#define pb push_back
#define mp make_pair
#define all(x) begin(x), end(x)
#define fi first
#define se second

inline ld sqr(ld a) { return a * a; }

const ld eps = 1e-5;

ld coef[5][5];
ld m[5][5];
ld x[5];
ld y[5];
ld r[5];
int sgn[5];
int seed;
bool found;

int myrand()
{
    return seed = (seed * 41 + 137) % 239;
}

inline void ask(int id)
{
    x[id] = (ld)myrand() / 239 * 100;
    y[id] = (ld)myrand() / 239 * 100;
//     x[id] = rand() % 3;
//     y[id] = rand() % 3;
    printf("? %.20lf %.20lf\n", (D)x[id], (D)y[id]);
    fflush(stdout);
    double ans;
    scanf("%lf", &ans);
    r[id] = ans;
}

inline ld det()
{
    ld ans = 0;
    for (int i = 0; i < 3; i++)
    {
        ld cur = 1;
        for (int j = 0; j < 3; j++) cur *= m[j][(i + j) % 3];
        ans += cur;
    }
    for (int i = 0; i < 3; i++)
    {
        ld cur = 1;
        for (int j = 0; j < 3; j++) cur *= m[j][(i - j + 3) % 3];
        ans -= cur;
    }
    return ans;
}

inline bool closeenought(ld a, ld b)
{
    return abs(a - b) / max(abs(a), (ld)1) < eps;
}

void check()
{
    if (found) return;
    for (int i = 0; i < 3; i++)
    {
        for (int j = 0; j < 4; j++) if (j != 2) m[i][j] = coef[i][j] - coef[3][j];
        m[i][2] = sgn[i] * coef[i][2] - sgn[3] * coef[3][2];
    }
    ld d = det();
    
    assert(abs(d) > eps);
    for (int i = 0; i < 3; i++) swap(m[i][0], m[i][3]);
    ld X = det() / d;
    for (int i = 0; i < 3; i++) swap(m[i][0], m[i][3]);
    for (int i = 0; i < 3; i++) swap(m[i][1], m[i][3]);
    ld Y = det() / d;
    for (int i = 0; i < 3; i++) swap(m[i][1], m[i][3]);
    for (int i = 0; i < 3; i++) swap(m[i][2], m[i][3]);
    ld R = det() / d;
    ld lft = sqr(x[3] - X) + sqr(y[3] - Y);
    ld rght = sqr(R + sgn[3] * r[3]);
    if (closeenought(lft, rght))
    {
//         fprintf(stderr, "B %.20lf %.20lf\n", (D)X, (D)Y);
//         fprintf(stderr, "%.20lf %.20lf %.20lf\n", (D)r[3], (D)lft, (D)rght);
       	printf("A %.20lf %.20lf\n", (D)X, (D)Y);
        found = true;
        fflush(stdout);
//        exit(0);              
    }
//     cerr << "bad coefs" << endl;
}

void go(int cur)
{
    if (cur == 4)
    {
        check();
        return;
    }
    for (sgn[cur] = -1; sgn[cur] < 2; sgn[cur] += 2) go(cur + 1);
}

int main()
{
    int NT;
    scanf("%d", &NT);
    for (int T = 0; T < NT; T++)
    {
        found = false;
//         cerr << "next test " << endl;
        seed = 3;
        for (int i = 0; i < 4; i++)
        {
            ask(i);
            coef[i][0] = -2 * x[i];
            coef[i][1] = -2 * y[i];
            coef[i][2] = -2 * r[i];
            coef[i][3] = r[i] * r[i] - x[i] * x[i] - y[i] * y[i];
        }
        go(0);
    }
    return 0;
}