#include "testlib.h"
#include <iostream>
#include <cstdio>
#include <algorithm>

using namespace std;

int a[100007];

int main(int argc, char *argv[])
{
	registerGen(argc, argv, 1);

	int T_s = atoi(argv[1]); 
	int T_f = atoi(argv[2]); 
	int t = atoi(argv[3]); 
	int n = atoi(argv[4]);
	int n1 = atoi(argv[5]);

	for (int i = 0; i < n1; ++i) 
        {
		a[i] = rnd.next(T_s);
                if (a[i] == 0) a[i] = 1;
        }


	for (int i = n1; i < n; ++i)
        {
		a[i] = T_s + rnd.next(n * t);
        }

	for (int i = 0; i < 200000; ++i)
	{
		int x = rnd.next(n);
		int y = rnd.next(n);
		swap(a[x], a[y]);
	}
	sort(&a[0], &a[n]);
	cout << T_s << " " << T_f << " " << t << endl;
	cout << n << endl;
	for (int i = 0; i + 1 < n; ++i)
		cout << a[i] << " ";
	cout << a[n - 1] << endl;
	return 0;		
}