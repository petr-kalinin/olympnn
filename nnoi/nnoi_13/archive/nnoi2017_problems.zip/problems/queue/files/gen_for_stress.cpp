#include "testlib.h"
#include <iostream>
#include <cstdio>
#include <algorithm>


using namespace std;

int a[100007];

int main(int argc, char *argv[])
{
	registerGen(argc, argv, 1);

	int maxT = atoi(argv[1]);
	int maxN = atoi(argv[2]);

	int T_s = rnd.next(1, maxT-1); 
        cerr << "T_s=" << T_s << endl;
	int T_f = rnd.next(T_s+1, maxT); 
        cerr << "T_f=" << T_f << endl;
	int t = rnd.next(1, T_f - T_s);
        cerr << "t=" << t << endl;
	int n = rnd.next(0, maxN);
        cerr << "n=" << n << endl;
	int n1 = rnd.next(0, n);

	for (int i = 0; i < n1; ++i) 
        {
		a[i] = rnd.next(T_s);
        if (a[i] == 0) a[i] = 1;
    }

	for (int i = n1; i < n; ++i)
        {
		a[i] = rnd.next(1, maxT+1);
    }

    if (n > 0) {
  	for (int i = 0; i < 200000; ++i)
	{
		int x = rnd.next(n);
		int y = rnd.next(n);
		swap(a[x], a[y]);
	}
    }
	sort(&a[0], &a[n]);
	cout << T_s << " " << T_f << " " << t << endl;
	cout << n << endl;
	for (int i = 0; i + 1 < n; ++i)
		cout << a[i] << " ";
	if (n > 0) {
    	cout << a[n - 1];
	cout << endl;
        }
	return 0;		
}
