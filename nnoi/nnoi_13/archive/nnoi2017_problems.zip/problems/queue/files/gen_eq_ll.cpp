#include "testlib.h"
#include <iostream>
#include <cstdio>
#include <algorithm>

#define ll long long


using namespace std;

ll a[100007];

int main(int argc, char *argv[])
{
	registerGen(argc, argv, 1);

	ll T_s = atoll(argv[1]); 
	ll T_f = atoll(argv[2]); 
    ll T_c = atoll(argv[3]); 
    ll t = atoll(argv[4]); 
	int n = atoi(argv[5]);

	for (int i = 0; i < n; ++i) 
    {
		a[i] = T_c;
    }

	cout << T_s << " " << T_f << " " << t << endl;
	cout << n << endl;
	for (int i = 0; i + 1 < n; ++i)
		cout << a[i] << " ";
	cout << a[n - 1] << endl;
	return 0;		
}
