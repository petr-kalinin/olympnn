#include "testlib.h"
#include <iostream>
#include <cstdio>
#include <algorithm>

#define ll long long


using namespace std;

ll a[100007];

int main(int argc, char *argv[])
{
	registerGen(argc, argv, 1);

	ll T_s = atoll(argv[1]); 
	ll T_bef = atoll(argv[2]); 
	ll t = atoll(argv[3]); 
	int n = atoi(argv[4]);
    int skip = atoi(argv[5]);

    ensure(T_bef <= t);
    ensure(n - skip > 0);
    
	for (int i = 0; i < n; ++i) 
    {
		a[i] = max(1LL, T_s + t * i - rnd.next(T_bef));
    }
    ll T_f = T_s + t * (n - skip);

	cout << T_s << " " << T_f << " " << t << endl;
	cout << n << endl;
	for (int i = 0; i + 1 < n; ++i)
		cout << a[i] << " ";
	cout << a[n - 1] << endl;
	return 0;		
}
