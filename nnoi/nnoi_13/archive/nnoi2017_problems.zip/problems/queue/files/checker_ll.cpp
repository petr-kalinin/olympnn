#include "testlib.h"
#include <iostream>
#include <algorithm>

using namespace std;

#define ll long long

const int maxN = 100005;
const ll INF = 1000000000007;

ll t_s, t_f, t;
int n;
ll a[maxN];

ll jury;
ll out;

ll check(ll x)
{
	ll start = t_s;
	int i = 0;
	while(i < n && a[i] <= x)
	{
		start = max(start, a[i]);
		if (start + t > t_f)
			return INF;
		start += t;
		++i;
	}
	start = max(start, x);
        if (start + t > t_f)
                return INF;
	return start - x;
}

int main(int argc, char** argv) {
	registerTestlibCmd(argc, argv);

	t_s = inf.readLong();
	t_f = inf.readLong();
	t = inf.readLong();
	n = inf.readInt();
	for (int i = 0; i < n; ++i)
		a[i] = inf.readLong();

	sort(&a[0], &a[n]);

	jury = ans.readLong();
	out = ouf.readLong();

        if (out < 0)
        {
                quit(_wa, "Wrong out format");
        }

	ll jury_time, out_time;
	jury_time = check(jury);
	out_time = check(out);

	if (jury_time == INF)
	{
		quit(_fail, "Jury answer is incorrect (too late)");
	}


	if (out + t > t_f || out_time == INF)
	{
		quitf(_wa, "Vasya was late: out = %lld, t_f = %lld, t = %lld", out, t_f, t);
	}

	if (jury_time < out_time)
	{
		quitf(_wa, "Jury has better solution: jury_time = %lld, out_time = %lld", jury_time, out_time);
	}
	else if (jury_time == out_time)
	{
		quitf(_ok, "Best time = %lld", jury_time);
	}
	else if (jury_time > out_time)
	{
		quitf(_fail, "Contestant has better solution!!! jury_time = %lld, out_time = %lld, out_ans = %lld", jury_time, out_time, out);
	}
	return 0;
}