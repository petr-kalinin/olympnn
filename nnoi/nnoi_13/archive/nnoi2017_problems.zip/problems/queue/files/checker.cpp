#include "testlib.h"
#include <iostream>
#include <algorithm>

using namespace std;

const int maxN = 100005;
const int INF = 1000000007;

int t_s, t_f, t;
int n;
int a[maxN];

int jury;
int out;

int check(int x)
{
	int start = t_s;
	int i = 0;
	while(i < n && a[i] <= x)
	{
		start = max(start, a[i]);
		if (start + t > t_f)
			return INF;
		start += t;
		++i;
	}
	start = max(start, x);
        if (start + t > t_f)
                return INF;
	return start - x;
}

int main(int argc, char** argv) {
	registerTestlibCmd(argc, argv);

	t_s = inf.readInt();
	t_f = inf.readInt();
	t = inf.readInt();
	n = inf.readInt();
	for (int i = 0; i < n; ++i)
		a[i] = inf.readInt();

	sort(&a[0], &a[n]);

	jury = ans.readInt();
	out = ouf.readInt();

        if (out < 0)
        {
                quit(_wa, "Wrong out format");
        }

	int jury_time, out_time;
	jury_time = check(jury);
	out_time = check(out);

	if (jury_time == INF)
	{
		quit(_fail, "Jury answer is incorrect (too late)");
	}


	if (out + t > t_f || out_time == INF)
	{
		quitf(_wa, "Vasya was late: out = %d, t_f = %d, t = %d", out, t_f, t);
	}

	if (jury_time < out_time)
	{
		quitf(_wa, "Jury has better solution: jury_time = %d, out_time = %d", jury_time, out_time);
	}
	else if (jury_time == out_time)
	{
		quitf(_ok, "Best time = %d", jury_time);
	}
	else if (jury_time > out_time)
	{
		quitf(_fail, "Contestant has better solution!!! jury_time = %d, out_time = %d", jury_time, out_time);
	}
	return 0;
}