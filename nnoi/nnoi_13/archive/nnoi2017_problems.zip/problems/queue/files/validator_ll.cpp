#include "testlib.h"

using namespace std;

#define ll long long

const ll MAX_TIME = 1000000000000;
const ll MAX_N = 100000;

int main(int argc, char** argv)
{
	registerValidation(argc, argv);

	ll Ts = inf.readLong(1, MAX_TIME, "Ts");
	inf.readSpace();
	ll Tf = inf.readLong(Ts + 1, MAX_TIME, "Tf");
	inf.readSpace();
	ll t = inf.readLong(1, min(MAX_TIME, Tf - Ts), "T");
	
	inf.readEoln();
	int n = inf.readInt(0, MAX_N, "N");
	
	inf.readEoln();
	ll last = 1;
	for (int i = 0; i < n; ++i)
	{
	    last = inf.readLong(last, MAX_TIME, format("a[%d]", i + 1));
		if (i + 1 < n)
			inf.readSpace();
	}
	if (n) inf.readEoln();
	inf.readEof();

	return 0;
}      