#include "testlib.h"

using namespace std;

const int MAX_TIME = 1000000000;
const int MAX_N = 100000;

int main(int argc, char** argv)
{
	registerValidation();

	int Ts = inf.readInt(1, MAX_TIME, "Ts");
	inf.readSpace();
	int Tf = inf.readInt(Ts + 1, MAX_TIME, "Tf");
	inf.readSpace();
	int t = inf.readInt(1, min(MAX_TIME, Tf - Ts), "T");
	
	inf.readEoln();
	int n = inf.readInt(0, MAX_N, "N");
	
	inf.readEoln();
	int last = 1;
	for (int i = 0; i < n; ++i)
	{
		last = inf.readInt(last, MAX_TIME, format("a[%d]", i + 1));
		if (i + 1 < n)
			inf.readSpace();
	}
	if (n) inf.readEoln();
	inf.readEof();

	return 0;
}      