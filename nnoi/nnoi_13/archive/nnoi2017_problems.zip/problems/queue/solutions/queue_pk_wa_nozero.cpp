#include <stdio.h>
#include <vector>

int main() {
    long long int ts, tf, t0;
    int n;
    scanf("%lld%lld%lld%d", &ts, &tf, &t0, &n);
    if (n == 0) {
        printf("%lld", ts);
        return 0;
    }
    std::vector<long long int> t(n, 0);
    for (auto& x: t) {
        scanf("%lld", &x);
    }
    long long int last = ts;
    std::vector<long long int> start(n, 0);
    for (int i=0; i<n; i++) {
        if (t[i] > last)
            last = t[i];
        start[i] = last;
        last += t0;
    }
    long long int ans = t[0] - 1;
    long long int min = ts - ans;
    for (int i=1; i<n; i++) {
        if (t[i] > t[i-1]) {
            long long int curt = start[i] - t[i] + 1;
            if (curt < min) {
                min = curt;
                ans = t[i] - 1;
            }
        }
    }
    printf("%lld", ans);
    return 0;
}