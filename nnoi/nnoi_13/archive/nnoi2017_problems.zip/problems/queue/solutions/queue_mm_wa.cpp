#include <iostream>
#include <cstdio>

using namespace std;

const int inf = 1000000000007;
const int maxN = 100005;

int a[maxN];
int t_s, t_f, t;
int n;
int ans;
int best;


int main()
{


	scanf("%d%d%d", &t_s, &t_f, &t);
	scanf("%d", &n);
	for (int i = 0; i < n; ++i)
		scanf("%d", &a[i]);

	best = inf;
	int curStart = t_s;
	int pred = 0;
	for (int i = 0; i < n; ++i)
	{
		if (curStart + t > t_f)
			break;

		if (a[i] - pred < 1)
		{
			curStart += t;
			continue;
		}
		
		if (a[i] > curStart)
		{
			best = 0;
			ans = curStart;
			break;
		}

		int tm = curStart - (a[i] - 1);
		if (tm < best)
		{
			best = tm;
			ans = a[i] - 1;
		}

		pred = a[i];
		curStart += t;
	}

	cout << ans;
}