#include <iostream>
#include <fstream>
#include <vector>
#include <algorithm>

using namespace std;

int main() {
    long long int ts,tf,t;
    cin >> ts >> tf >> t;
    int n;
    cin >> n;
    vector<long long int> a;
    for (int i=0; i<n; i++)  {
       long long int x;
       cin >> x;
       a.push_back(x);
    }

    sort(a.begin(), a.end());

    long long int cur = 0;
    long long int realt = ts;

    long long int ans = tf + 1;
    long long int besttime = -1;

    for (long long int st=0; st<tf; st++) {
        while ((cur < n) && (a[cur]<=st)) {
            if (realt < a[cur])
               realt = a[cur];
            realt += t;
            cur++;
        }
        if (realt < st) realt = st;
        if (realt > tf)
            break;
        if (realt - st < ans) {
            ans = realt - st;
            besttime = st;
        }
    }

    cout << besttime << endl;

    return 0;
}