#include <bits/stdc++.h>

using namespace std;

using ll = long long;
using ld = long double;
using D = double;
using uint = unsigned int;
template<typename T>
using pair2 = pair<T, T>;

#ifdef WIN32
    #define LLD "%I64d"
#else
    #define LLD "%lld"
#endif

#define pb push_back
#define mp make_pair
#define all(x) (x).begin(),(x).end()
#define fi first
#define se second

ll tf, ts, t;
int n;

int main()
{
    scanf("%lld%lld%lld", &ts, &tf, &t);
    tf -= t;
    scanf("%d", &n);
    ll curt = ts;
    pair2<ll> answer = {1000000007, 0};
    for (int i = 0; i < n && curt <= tf; i++)
    {
        ll x;
        scanf("%lld", &x);
        if (curt < x) answer = min(answer, {0, curt});
        answer = min(answer, {curt - x + 1, x - 1});
        curt = max(curt, x) + t;
    }
    if (curt <= tf) answer = min(answer, {0, curt});
    cout << answer.se << endl;
    return 0;
}