#include <stdio.h>
#include <vector>
#include <iostream>

int main() {
    long long int ts, tf, t0;
    int n;
    scanf("%lld%lld%lld%d", &ts, &tf, &t0, &n);
    if (n == 0) {
        printf("%lld", ts);
        return 0;
    }
    std::vector<long long int> t(n, 0);
    for (auto& x: t) {
        scanf("%lld", &x);
    }
    long long int ans = t[0] - 1;
    long long int min = ts - ans + t0;
    long long int last = ts;
    for (int i=0; i<n; i++) {
        if (t[i] > t[i-1]) {
            long long int myt = t[i] - 1;
            long long int mylast = last;
            if (myt > mylast)
                mylast = myt;
            mylast += t0;
            if (mylast <= tf && mylast - myt < min) {
                min = mylast - myt;
                ans = myt;
            }
        }
        if (t[i] > last)
            last = t[i];
        last += t0;
    }
    if (last + t0 <= tf) {
        ans = last;
        min = 0;
    }
    if (min != 0)
        ans = -1;
    printf("%lld", ans);
    return 0;
}