#include <iostream>
#include <cstdio>

#define ll long long

using namespace std;

const ll inf = 1000000000007;
const int maxN = 100005;

ll a[maxN];
ll t_s, t_f, t;
int n;
ll ans;
ll best;


int main()
{


	scanf("%lld%lld%lld", &t_s, &t_f, &t);
	scanf("%d", &n);
	for (int i = 0; i < n; ++i)
		scanf("%lld", &a[i]);

	best = inf;
	ll curStart = t_s;
	ll pred = 0;
	for (int i = 0; i < n; ++i)
	{
		if (curStart + t > t_f)
			break;

		if (a[i] - pred < 1)
		{
			curStart += t;
			continue;
		}
		
		if (a[i] > curStart)
		{
			best = 0;
			ans = curStart;
			break;
		}

		ll tm = curStart - (a[i] - 1);
		if (tm < best)
		{
			best = tm;
			ans = a[i] - 1;
		}

		pred = a[i];
		curStart += t;
	}

	if (curStart + t <= t_f)
	{
		ans = curStart;
		best = 0;
	}
	
	cout << ans;
}