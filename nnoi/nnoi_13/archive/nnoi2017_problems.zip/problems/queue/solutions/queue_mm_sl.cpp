#include <iostream>
#include <cstdio>

using namespace std;

const long long inf = 1000000000007;
const int maxN = 100005;

long long a[maxN];
long long t_s, t_f, t;
int n;
long long ans;
long long best;


int main()
{


	scanf("%lld%lld%lld", &t_s, &t_f, &t);
	scanf("%d", &n);
	for (int i = 0; i < n; ++i)
		scanf("%lld", &a[i]);

	best = inf;
	long long curStart = t_s;
	int pred = 0;
	int k = 0;
	for (long long i = 0; i < t_f; ++i)
	{
	    curStart = max(curStart, i);
		while(k < n && a[k] <= i)
		{
			curStart += t;
			++k;
		}
		if (curStart + t > t_f)
			break;
		long long tmp = max(curStart, i);
		if (tmp + t > t_f)
			break;
		if (tmp - i < best)
		{
			ans = i;
			best = tmp - i;
//cerr << ans << " " << best << endl;
		}
	}

	cout << ans;
}