#include <bits/stdc++.h>

using namespace std;

using ll = long long;

const int maxn = 100005;

int c[maxn], w[maxn];
pair<int, int> answer[maxn];
int n, m;
priority_queue<pair<int, int>> q;

int main()
{
    scanf("%d%d", &n, &m);
    for (int i = 0; i < n; i++) scanf("%d", &c[i]);
    for (int i = 0; i < n; i++) scanf("%d", &w[i]);
    ll total_answer = 0;
    for (int i = 0; i < n; i++)
    {
        m -= c[i] % 100;
        answer[i] = {c[i] / 100, c[i] % 100};
        if (c[i] % 100 != 0) q.push({-(100 - c[i] % 100) * w[i], i});
        if (m < 0)
        {
            auto id = q.top().second;
            q.pop();
            total_answer += w[id] * (100 - c[id] % 100);
            answer[id].first++;
            answer[id].second = 0;
            m += 100;
        }
    }
    printf("%lld\n", total_answer);
    for (int i = 0; i < n; i++) printf("%d %d\n", answer[i].first, answer[i].second);
    return 0;
}