#include <bits/stdc++.h>

using namespace std;

using ll = long long;
using ld = long double;
using D = double;
using uint = unsigned int;

#ifdef WIN32
    #define LLD "%I64d"
#else
    #define LLD "%lld"
#endif

#define pb push_back
#define mp make_pair
#define all(x) (x).begin(),(x).end()
#define fi first
#define se second

const int maxn = 505;
const int maxB = 100 * maxn + maxn;
const ll inf = 1e18;

ll ans[maxn][maxB];
vector<pair<int, int>> answer;
int n, m;
int c[maxn], notes[maxn], w[maxn];

inline void upd(ll &a, ll b)
{
    a = min(a, b);
}

int main()
{
    scanf("%d%d", &n, &m);
    for (int i = 0; i < n; i++)
    {
        scanf("%d", &c[i]);
        notes[i] = c[i] / 100;
        c[i] %= 100;
    }
    for (int i = 0; i < n; i++) scanf("%d", &w[i]);
    int B = m + 100 * n;
    for (int i = 0; i <= n; i++)
    {
        for (int j = 0; j <= B; j++) ans[i][j] = inf;
    }
    ans[0][m] = 0;
    for (int i = 0; i < n; i++)
    {
        for (int j = 0; j <= B; j++)
        {
            if (j >= c[i]) upd(ans[i + 1][j - c[i]], ans[i][j]);
            if (c[i] != 0 && j + 100 - c[i] <= B) upd(ans[i + 1][j + 100 - c[i]], ans[i][j] + (100 - c[i]) * w[i]);
        }
    }
    int curm = min_element(ans[n], ans[n] + B + 1) - ans[n];
    ll result = ans[n][curm];
    for (int i = n; i > 0; i--)
    {
        if (curm + c[i - 1] <= B && ans[i][curm] == ans[i - 1][curm + c[i - 1]])
        {
            answer.pb({notes[i - 1], c[i - 1]});
            curm += c[i - 1];
        } else
        {
            answer.pb({notes[i - 1] + 1, 0});
            curm -= 100 - c[i - 1];
            assert(curm >= 0);
        }
    }
    reverse(all(answer));
    printf("%lld\n", result);
    for (auto t : answer) printf("%d %d\n", t.fi, t.se);
    return 0;
}