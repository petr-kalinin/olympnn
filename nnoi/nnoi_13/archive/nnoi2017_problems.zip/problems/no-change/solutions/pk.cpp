#include <iostream>
#include <cstdio>
#include <vector>
#include <set>

int main() {
    int n, m;
    scanf("%d%d", &n, &m);
    std::vector<int> c(n), w(n);
    for (auto& x: c)
        scanf("%d", &x);
    for (auto& x: w)
        scanf("%d", &x);
    std::set<std::pair<int, int>> a;
    std::set<int> days;
    long long int ans = 0;
    for (int i=0; i<n; i++) {
        if (c[i] % 100 == 0)
            continue;
        a.emplace((100 - c[i]%100) * w[i], i);
        m -= c[i]%100;
        if (m < 0) {
            auto z = *a.begin();
            a.erase(z);
            days.insert(z.second);
            ans += z.first;
            m += 100;
        }
    }
    printf("%lld\n", ans);
    for (int i=0; i<n; i++) {
        if (days.count(i)) {
            printf("%d %d\n", c[i]/100+1, 0);
        } else {
            printf("%d %d\n", c[i]/100, c[i]%100);
        }
    }
    return 0;
}
