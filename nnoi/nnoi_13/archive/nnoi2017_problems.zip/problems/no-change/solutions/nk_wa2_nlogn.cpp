#include <bits/stdc++.h>

using namespace std;

using ll = long long;
using ld = long double;
using D = double;
using uint = unsigned int;

#ifdef WIN32
    #define LLD "%I64d"
#else
    #define LLD "%lld"
#endif

#define pb push_back
#define mp make_pair
#define all(x) (x).begin(),(x).end()
#define fi first
#define se second

const int maxn = 100005;

int c[maxn], w[maxn];
pair<int, int> answer[maxn];
int n, m;
priority_queue<pair<int, int>> q;

int main()
{
    scanf("%d%d", &n, &m);
    for (int i = 0; i < n; i++) scanf("%d", &c[i]);
    for (int i = 0; i < n; i++) scanf("%d", &w[i]);
    ll total_answer = 0;
    for (int i = 0; i < n; i++)
    {
        m -= c[i] % 100;
        answer[i] = {c[i] / 100, c[i] % 100};
        q.push({-(100 - c[i] % 100) * w[i], i});
        if (m < 0)
        {
//             cout << "bad " << i << endl;
            auto id = q.top().se;
            q.pop();
//             cout << "pop " << id << endl;
            total_answer += w[id] * (100 - c[id] % 100);
            answer[id].fi++;
            answer[id].se = 0;
            m += 100;
        }
    }
    printf("%lld\n", total_answer);
    for (int i = 0; i < n; i++) printf("%d %d\n", answer[i].fi, answer[i].se);
    return 0;
}