#include <bits/stdc++.h>

using namespace std;

using ll = long long;
using ld = long double;
using D = double;
using uint = unsigned int;

#ifdef WIN32
    #define LLD "%I64d"
#else
    #define LLD "%lld"
#endif

#define pb push_back
#define mp make_pair
#define all(x) (x).begin(),(x).end()
#define fi first
#define se second

const int maxn = 100005;

int c[maxn], w[maxn];
int n, m;
pair<int, int> answer[maxn];

int main()
{
    scanf("%d%d", &n, &m);
    for (int i = 0; i < n; i++) scanf("%d", &c[i]);
    for (int i = 0; i < n; i++) scanf("%d", &w[i]);
    ll ans = 0;
    for (int i = 0; i < n; i++) 
    {
        if (m >= c[i] % 100)
        {
            m -= c[i] % 100;
            answer[i] = {c[i] / 100, c[i] % 100};
        } else
        {
            m += 100 - c[i] % 100;
            answer[i] = {c[i] / 100 + 1, 0};
            ans += w[i] * (100 - c[i] % 100);
        }
    }
    printf("%lld\n", ans);
    for (int i = 0; i < n; i++) printf("%d %d\n", answer[i].fi, answer[i].se);
    return 0;
}