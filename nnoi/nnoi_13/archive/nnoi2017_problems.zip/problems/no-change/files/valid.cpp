#include "testlib.h"

int ngroups = 4;

int nmax[] = {100000, 20, 500, 500, 100000};
int mmax[] = {1000000000, 500, 500, 1000000000, 1000000000};

int main(int argc, char* argv[])
{
    registerValidation(argc, argv);
    int group = (validator.group().empty()) ? 0 : atoi(validator.group().data());
    ensure(0 <= group && group <= ngroups);
    int n = inf.readInt(1, nmax[group], "n");
    inf.readSpace();
    inf.readInt(0, mmax[group], "m");
    inf.readEoln();
    for (int i = 0; i < n; i++)
    {
        if (i > 0) inf.readSpace();
        inf.readInt(1, 100 * 1000, format("c[%d]", i + 1));
    }
    inf.readEoln();
    for (int i = 0; i < n; i++)
    {
        if (i > 0) inf.readSpace();
        inf.readInt(1, 100 * 1000, format("w[%d]", i + 1));
    }
    inf.readEoln();
    inf.readEof();
    return 0;
}
