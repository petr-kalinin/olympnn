#include <iostream>
#include "testlib.h"

using namespace std;

int main(int argc, char* argv[])
{
    registerGen(argc, argv, 1);
    int n = atoi(argv[1]);
    int maxm = atoi(argv[2]);
    int maxc = atoi(argv[3]);
    int maxw = atoi(argv[4]);
    printf("%d %d\n", n, rnd.next(0, maxm));
    for (int i = 0; i < n; i++) printf("%d%c", rnd.next(1, maxc), " \n"[i + 1 == n]);
    for (int i = 0; i < n; i++) printf("%d%c", rnd.next(1, maxw), " \n"[i + 1 == n]);
}
