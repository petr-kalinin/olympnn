#include "testlib.h"

#include <vector>

using namespace std;

using ll = long long;

int n, m;
vector<int> c, w;

ll get_answer(InStream &stream)
{
    ll answer = stream.readLong(0, 1000LL * 1000 * 1000 * 1000, "answer");
    int current_coins = m;
    ll current_answer = 0;
    for (int i = 0; i < n; i++)
    {
        int notes = stream.readInt(0, 10 * 1000, "notes");
        int coins = stream.readInt(0, 1000 * 1000, "coins");
        if (coins > current_coins) stream.quitf(_wa, "lack of coins on day %d", i + 1);
        current_coins -= coins;
        int sum = notes * 100 + coins;
        if (sum > 1000 * 1000) stream.quitf(_wa, "sum is greater than a million on day %d", i + 1);
        if (sum < c[i]) stream.quitf(_wa, "sum is less than needed to pay on day %d", i + 1);
        int change = sum - c[i];
        current_answer += w[i] * (change / 100 + change % 100);
        current_coins += change % 100;
    }
    if (current_answer != answer) stream.quitf(_wa, "printed dissatisfaction is %lld, certificate's dissatisfaction is %lld", answer, current_answer);
    return answer;
}

int main(int argc, char* argv[])
{
    registerTestlibCmd(argc, argv);

    n = inf.readInt();
    m = inf.readInt();
    c.resize(0);
    for (int i = 0; i < n; i++) c.push_back(inf.readInt());
    w.resize(0);
    for (int i = 0; i < n; i++) w.push_back(inf.readInt());

    ll ja = get_answer(ans);
    ll pa = get_answer(ouf);

    if (ja == pa) quitf(_ok, "answer is %lld, n = %d", ja, n);
    else
    {
        if (ja < pa) quitf(_wa, "participant's answer is worse: pa = %lld, ja = %lld, n = %d", pa, ja, n);
        if (ja > pa) quitf(_fail, "jury's answer is worse: pa = %lld, ja = %lld, n = %d", pa, ja, n);
    }
}