#include <iostream>
#include "testlib.h"

using namespace std;

int main(int argc, char* argv[])
{
    registerGen(argc, argv, 1);
    int n = atoi(argv[1]);
    int minm = atoi(argv[2]);
    int maxm = atoi(argv[3]);
    int minc = atoi(argv[4]);
    int maxc = atoi(argv[5]);
    int minw = atoi(argv[6]);
    int maxw = atoi(argv[7]);
    printf("%d %d\n", n, rnd.next(minm, maxm));
    for (int i = 0; i < n; i++) printf("%d%c", rnd.next(minc, maxc), " \n"[i + 1 == n]);
    for (int i = 0; i < n; i++) printf("%d%c", rnd.next(minw, maxw), " \n"[i + 1 == n]);
}
