#include <iostream>
#include "testlib.h"

using namespace std;

int main(int argc, char* argv[])
{
    registerGen(argc, argv, 1);
    int n = atoi(argv[1]);
    int m = atoi(argv[2]);
    int maxc = atoi(argv[3]);
    int maxw = atoi(argv[4]);
    int noise = atoi(argv[5]);
    printf("%d %d\n", n, m);
    for (int i = 0; i < n; i++) printf("%d%c", rnd.next(1, maxc), " \n"[i + 1 == n]);
    for (int i = 0; i < n; i++)
    {
        int w;
        if (i % 2 == 0)
        {
            w = rnd.next(1, maxw / 10000 + 1);
            if (rnd.next(0, 99) < noise) w = rnd.next(maxw / 2, maxw);
        } else
        {
            w = rnd.next(maxw / 2, maxw);
            if (rnd.next(0, 99) < noise) w = rnd.next(1, maxw / 10000 + 1);
        }
        printf("%d%c", w, " \n"[i + 1 == n]);
    }
}
