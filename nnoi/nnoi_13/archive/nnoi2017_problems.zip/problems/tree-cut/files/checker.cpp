#include <cstdio>
#include <cstring>
#include <algorithm>
#include <vector>
#include <iostream>
#include <cassert>
#include <cmath>
#include <string>
#include <queue>
#include <set>
#include <map>
#include <cstdlib>

#include "testlib.h"

using namespace std;

const int maxn = 1e6;

int root;
vector <int> edges[maxn + 5];
vector <int> banned;
int w[maxn + 5];
int n;

int dfs(int v) {
    int result = w[v];
    for (int u : edges[v]) {
        if (find(banned.begin(), banned.end(), u) == banned.end())
            result += dfs(u);
    }
    return result;
}

char verdict[100];

int load_answer(InStream & stream) {
    vector <int> chosen(2);
    chosen[0] = stream.readInt(-1, n);
    if (chosen[0] == 0) {
        sprintf(verdict, "0 violates the range [1;%d]", n);
        stream.quit(_pe, verdict);
    } else if (chosen[0] == -1) {
        return -1;
    }
    chosen[1] = stream.readInt(1, n);
    if (chosen[0] == chosen[1]) {
        sprintf(verdict, "Two equal verteces in answer: %d", chosen[0]);
        stream.quit(_pe, verdict);
    }
    if (chosen[0] == root || chosen[1] == root) {
        sprintf(verdict, "At least one of verteces %d and %d is root %d",
                chosen[0], chosen[1], root);
        stream.quit(_pe, verdict);
    }

    banned = chosen;
    int part1 = dfs(root);
    int part2 = dfs(chosen[0]);
    int part3 = dfs(chosen[1]); 
    if (part1 != part2 || part1 != part3) {
        sprintf(verdict, "Parts have different sizes: %d (root %d) %d (root %d) %d (root %d)",
                    part1, root, part2, chosen[0], part3, chosen[1]);
        stream.quit(_wa, verdict);
    }
    return part1;
}

int main(int argc, char ** argv) {
    registerTestlibCmd(argc, argv);
    n = inf.readInt();
    for (int i = 1; i <= n; ++i) {
        int anc;
        anc = inf.readInt();
        w[i] = inf.readInt();
        if (anc != 0)
            edges[anc].push_back(i);
        else root = i;
    }
    int jury_ans = load_answer(ans);
    int contestant_ans = load_answer(ouf);
    if (jury_ans == -1) {
        if (contestant_ans != -1) {
            quit(_fail, "Contestant found the solution but Jury didn't");
        } else quit(_ok, "-1 no solution");
    }
    if (contestant_ans == -1)
        quit(_wa, "Contestant didn't find the solution but it exists");
    quitf(_ok, "sizes of three parts: %d", jury_ans);
}
