#include "testlib.h"
#include <vector>

using namespace std;

const int minn = 3;
const int maxn = 1e6;
const int maxT = 100;
vector <int> edges[maxn + 1];
bool mark[maxn + 1];

void dfs(int v, int anc) {
    mark[v] = true;
    for (int u : edges[v]) {
        if (u == anc)
            continue;
        ensuref(!mark[u], "graph should be tree");
        dfs(u, v);
    }
}

int main(int argc, char ** argv)
{
    registerValidation(argc, argv);

    int n = inf.readInt(minn, maxn, "n");
    inf.readEoln();
    for (int i = 1; i <= n; i++)
    {
        int anc = inf.readInt(0, n, "ancestor");
        inf.readSpace();
        if (anc != 0) {
            edges[anc].push_back(i);
            edges[i].push_back(anc);
        }
        int t = inf.readInt(-maxT, maxT, "temperature");
        inf.readEoln();
    }
    inf.readEof();
    dfs(1, -1);
    for (int i = 1; i <= n; i++)
        ensuref(mark[i], "graph should be connected");
    return 0;
}
