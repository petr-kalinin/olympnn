#include <cstdio>
#include <cstring>
#include <algorithm>
#include <vector>
#include <iostream>
#include <cassert>
#include <cmath>
#include <string>
#include <queue>
#include <set>
#include <map>
#include <cstdlib>

#include "testlib.h"

using namespace std;

#define INF 1e+9
#define mp make_pair
#define pb push_back
#define fi first
#define fs first
#define se second
#define i64 long long
#define li long long
#define lint long long
#define pii pair<int, int>
#define vi vector<int>

#define forn(i, n) for (int i = 0; i < (int)n; i++)
#define fore(i, b, e) for (int i = (int)b; i <= (int)e; i++)

const int max_w = 100;

vi w;
vector <vi> edges;
vi sz;
int third;

void get_sizes(int v) {
    sz[v] = 1;
    for (int u : edges[v]) {
        get_sizes(u);
        sz[v] += sz[u];
    }
}

void build(int v, int need) {
    w[v] = need;
    int L = sz[v];
    for (int u : edges[v]) {
        L -= sz[u];
        int lower = max(w[v] - max_w * L, sz[u]);
        int upper = min(w[v] - L, max_w * sz[u]);
        int chosen;
        if (lower <= 2 * third && 2 * third <= upper && rnd.next(2) == 0)
            chosen = 2 * third;
        else if (lower <= third && third <= upper && rnd.next(2) == 0)
            chosen = third;
        else chosen = rnd.next(lower, upper);
        w[v] -= chosen;
        build(u, chosen);
    }
}

int main(int argc, char ** argv) {
    registerGen(argc, argv, 1);
    if (argc != 2 && argc != 3) {
        printf("Usage <N> <flag> (optional)");
        exit(0);
    }
    bool flag = argc == 3;
    int n = atoi(argv[1]);

    w.resize(n + 1);
    vi anc(n + 1);
    vi order(n);
    fore(i, 1, n)
        order[i - 1] = i;
    edges.resize(n + 1);
    shuffle(order.begin(), order.end());
    fore(i, 1, n - 1) {
        int prev = order[rnd.next(i)];
        //printf("adding %d %d\n", order[i], prev);
        edges[prev].pb(order[i]);
        anc[order[i]] = prev;
    }
    sz.resize(n + 1);
    get_sizes(order[0]);
    /*fore(j, 1, n)
        printf("sz[%d] = %d\n", j, sz[j]);*/
    third = n;
    fprintf(stderr, "third = %d\n", third);
    build(order[0], 3 * third);
    if (flag)
        w[order[0]] += rnd.next(1, 2);
    printf("%d\n", n);
    fore(i, 1, n) {
        assert(w[i] >= -100 && w[i] <= 100);
        printf("%d %d\n", anc[i], w[i]);
    }
}
