#include <cstdio>
#include <cstring>
#include <algorithm>
#include <vector>
#include <iostream>
#include <cassert>
#include <cmath>
#include <string>
#include <queue>
#include <set>
#include <map>
#include <cstdlib>

#include "testlib.h"

using namespace std;

#define INF 1e+9
#define mp make_pair
#define pb push_back
#define fi first
#define fs first
#define se second
#define i64 long long
#define li long long
#define lint long long
#define pii pair<int, int>
#define vi vector<int>

#define forn(i, n) for (int i = 0; i < (int)n; i++)
#define fore(i, b, e) for (int i = (int)b; i <= (int)e; i++)

const int RNG = 5;

int main(int argc, char ** argv) {
    registerGen(argc, argv, 1);
    if (argc != 3) {
        printf("Usage <mode> <N>");
        exit(-1);
    }
    int n = atoi(argv[2]);
    vi anc(n + 1);
    vi w(n + 1);
    int mode = atoi(argv[1]);
    int third = rnd.next(-5, 5);
    if (mode == 1) {
        int root = rnd.next(1, n);
        int chosen1 = rnd.next(1, root - 1);
        int chosen2 = rnd.next(root + 1, n);
        int sum = 0;
        fore(j, 1, n) {
           if (j == root || j == chosen1 || j == chosen2)
               continue;
           while(true) {
               w[j] = rnd.next(-sum - RNG, -sum + RNG);
               if (w[j] != third)
                   break;
           }
           sum += w[j];
           anc[j] = root;
        }
        w[root] = third - sum;
        w[chosen1] = w[chosen2] = third;
        anc[chosen1] = anc[chosen2] = root;
        fprintf(stderr, "chosen1 = %d chosen2 = %d\n", chosen1, chosen2);
    } else if (mode == 2) {
        vi order(n);
        forn(j, n)
            order[j] = j + 1;
        shuffle(order.begin(), order.end());
        int chosen0_idx = rnd.next(0, n - 1);
        int chosen1_idx = rnd.next(chosen0_idx + 1, n - 1);
        fprintf(stderr, "verteces %d %d\n", order[chosen0_idx], order[chosen1_idx]);
        int sum = 0;
        for (int i = n - 1; i > 0; i--) {
            int v = order[i];
            if (i == chosen0_idx)
                w[v] = 2 * third - sum;
            else if (i == chosen1_idx)
                w[v] = third - sum;
            else {
                while(true) {    
                    w[v] = rnd.next(-sum - RNG, - sum + RNG);
                    if (w[v] + sum != third && w[v] + sum != 2 * third)
                        break;
                }
            }
            sum += w[v];
            anc[v] = order[i - 1];
        }
        w[order[0]] = 3 * third - sum;
    } else {
        printf("Unknown mode");
        exit(-1);
    }
    printf("%d\n", n);
    fore(j, 1, n) {
        printf("%d %d\n", anc[j], w[j]);
    }
}

