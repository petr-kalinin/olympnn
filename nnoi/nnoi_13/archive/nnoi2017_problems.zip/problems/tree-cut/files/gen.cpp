#include <cstdio>
#include <cstring>
#include <algorithm>
#include <vector>
#include <iostream>
#include <cassert>
#include <cmath>
#include <string>
#include <queue>
#include <set>
#include <map>
#include <cstdlib>

#include "testlib.h"

using namespace std;

#define INF 1e+9
#define mp make_pair
#define pb push_back
#define fi first
#define fs first
#define se second
#define i64 long long
#define li long long
#define lint long long
#define pii pair<int, int>
#define vi vector<int>

#define forn(i, n) for (int i = 0; i < (int)n; i++)
#define fore(i, b, e) for (int i = (int)b; i <= (int)e; i++)


const int RNG = 22;
const double eps = 1.0e-9;

vi w;
int thirds_cnt = 0;
int twothirds_cnt = 0;
vector <vi> edges;
vector <bool> mark;
int maxh, mode, third;

int rnd_not_special() {
    while(true) {
        int x = rnd.next(-RNG, RNG);
        if (x != third && x != 2 * third)
            return x;
    }
}

inline bool roll(double prob) {
    if (prob < eps)
        return false;
    if (prob > 1.0)
        return true;
    return rnd.next(1000) <= 1000 * prob;
}

inline int get(bool marked, int h) {
    if (h == maxh && mode == 1)
        return third;
    if (h > maxh - 10 && mode == 2) {
        if (roll(0.75))
            return 2 * third;
    }
    if (marked) {
        if (mode == 1) {
            if (roll(0.75))
                return third;
            return rnd_not_special(); 
        } else if (mode == 2) {
            if (roll(0.75))
                return third;
            return rnd_not_special();
        }
    }
    if (roll(0.5))
        return 2 * third;
    return rnd_not_special();
}

void build(int v, int need, int h) {
    if (need == third) {
        thirds_cnt++;
        if (!mark[v])
            fprintf(stderr, "!!! h = %d\n", h);
    }
    else if (need == 2 * third)
        twothirds_cnt++;
    w[v] = need;
    for (int u : edges[v]) {
        //printf("v = %d u = %d\n", v, u);
        int need_u = get(mark[u], h + 1);
        build(u, need_u, h + 1);
        w[v] -= need_u;
    }
}

int main(int argc, char ** argv) {
    registerGen(argc, argv, 1);
    if (argc != 3 && argc != 4) {
        printf("Usage <mode> <N> <flag> (optional)");
        exit(0);
    }
    mode = atoi(argv[1]);
    bool flag = argc == 4;
    if (mode != 1 && mode != 2) {
        printf("Invalid mode %d! Should be 1 or 2", mode);
        exit(0);
    }
    int n = atoi(argv[2]);
    third = rnd.next(-5, 5);

    w.resize(n + 1);
    vi anc(n + 1);
    vi order(n);
    vi h(n + 1);
    mark.resize(n + 1);
    fore(i, 1, n)
        order[i - 1] = i;
    edges.resize(n + 1);
    shuffle(order.begin(), order.end());
    mark[order[0]] = true;
    int last_marked = order[0];
    fore(i, 1, n - 1) {
        int prev;
        if (roll(0.75)) {
            prev = last_marked;
            mark[order[i]] = true;
            last_marked = order[i];
        } else
        {
            if (roll(0.5))
                prev = last_marked;
            else prev = order[rnd.next(i)];
        }
        //printf("adding %d %d\n", order[i], prev);
        edges[prev].pb(order[i]);
        anc[order[i]] = prev;
        h[order[i]] = h[prev] + 1;
    }
    maxh = 0;
    fore(j, 1, n) if (!mark[j]) {
        maxh = max(maxh, h[j]);
    }
    fprintf(stderr, "================\n");
    fprintf(stderr, "root %d\n maxh = %d third = %d\n", order[0], maxh, third);
    /*fore(v, 1, n) {
        fprintf(stderr, "mark[%d] = %d; ", v, (int)mark[v]);
        for (int u : edges[v])
            fprintf(stderr, "%d ", u);
        fprintf(stderr, "\n");
    }*/
/*    for (int x : order)
        printf("%d ", x);
    printf("\n");*/
    build(order[0], 3 * third, 0);
    fprintf(stderr, "1/3 cnt = %d; 2/3 cnt = %d\n", thirds_cnt, twothirds_cnt);
    //printf("\n================\n");
    if (flag)
        w[order[0]] += rnd.next(1, 2);
    int minw = w[1];
    int maxw = w[1];
    fore(j, 2, n) {
        minw = min(minw, w[j]);
        maxw = max(maxw, w[j]);
    }
    fprintf(stderr, "minw = %d maxw = %d\n", minw, maxw);
    printf("%d\n", n);
    fore(i, 1, n) {
        printf("%d %d\n", anc[i], w[i]);
    }
}
