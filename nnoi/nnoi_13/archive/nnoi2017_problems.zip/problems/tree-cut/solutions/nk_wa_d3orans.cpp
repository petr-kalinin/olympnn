#include <bits/stdc++.h>

using namespace std;

using ll = long long;
using ld = long double;
using D = double;
using uint = unsigned int;
template<typename T>
using pair2 = pair<T, T>;

#ifdef WIN32
    #define LLD "%I64d"
#else
    #define LLD "%lld"
#endif

#define pb push_back
#define mp make_pair
#define all(x) (x).begin(),(x).end()
#define fi first
#define se second

const int maxn = 1000006;

vector<int> gr[maxn];
int t[maxn];
int n;
int timer, need, wasfirst, wasfirstid, waslast, waslastid;
pair2<int> answer;

int go(int cur)
{
    timer++;
    int curtimer = timer;
    int cursum = t[cur];
    for (auto v : gr[cur]) cursum += go(v);
    if (cursum == need && wasfirst < curtimer) answer = {wasfirstid, cur};
    if (cursum == 2 * need && waslast > curtimer) answer = {waslastid, cur};
    if (cursum == need)
    {
        if (wasfirstid == -1)
        {
            wasfirstid = cur;
            wasfirst = curtimer;
        }
        waslastid = cur;
        waslast = timer;
    }
    return cursum;
}

int main()
{
    scanf("%d", &n);
    int ttsum = 0;
    int root = -1;
    for (int i = 0; i < n; i++)
    {
        int x;
        scanf("%d%d", &x, &t[i]);
        x--;
        ttsum += t[i];
        if (x == -1) root = i;
        else gr[x].pb(i);
    }
    assert(root != -1);
    timer = 0;
    wasfirst = n + 2;
    wasfirstid = -1;
    waslast = -1;
    waslastid = -1;
    if (ttsum % 3 > 0)
    {
        printf("-1\n");
        return 0;
    }
    need = ttsum / 3;
    answer = {-1, -1};
    go(root);
    /*if (answer.fi == -1) printf("-1\n");
    else */printf("%d %d\n", answer.fi + 1, answer.se + 1);
    return 0;
}