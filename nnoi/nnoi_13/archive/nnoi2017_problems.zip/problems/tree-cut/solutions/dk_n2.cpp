#include <cstdio>
#include <cstring>
#include <algorithm>
#include <vector>
#include <iostream>
#include <cassert>
#include <cmath>
#include <string>
#include <queue>
#include <set>
#include <map>
#include <cstdlib>

using namespace std;

#define INF 1e+9
#define mp make_pair
#define pb push_back
#define fi first
#define fs first
#define se second
#define i64 long long
#define li long long
#define lint long long
#define pii pair<int, int>
#define vi vector<int>

#define forn(i, n) for (int i = 0; i < (int)n; i++)
#define fore(i, b, e) for (int i = (int)b; i <= (int)e; i++)

const int maxn = 1e6 + 5;

vi edges[maxn];
i64 sz[maxn];
int in[maxn];
int out[maxn];
int w[maxn];
int timer = 0;

void dfs(int v) {
    timer++;
    in[v] = timer;
    sz[v] = w[v];
    for (int u : edges[v]) {
        dfs(u);
        sz[v] += sz[u];
    }
    timer++;
    out[v] = timer;
}

void imp() {
    printf("-1");
    exit(0);
}

void print(int i, int j) {
    printf("%d %d\n", i, j);
    exit(0);
}

int main() {
#ifdef LOCAL
    freopen("inp", "r", stdin);
#endif
    int n, root = 0;
    scanf("%d", &n);
    fore(j, 1, n) {
        int anc;
        scanf("%d%d", &anc, &w[j]);
        if (anc == 0) {
            root = j;
        } else
            edges[anc].pb(j);
    }
    assert(root != 0);
    dfs(root);
    if (abs(sz[root]) % 3 != 0) {
        imp();
    }
    i64 third = sz[root] / 3;
    fore(i, 1, n)
        fore(j, 1, n) {
            if (in[i] < in[j] && out[i] < out[j] && sz[i] == third && sz[j] == third)
                print(i, j);
            if (in[i] < in[j] && out[i] > out[j] && sz[i] == 2 * third && sz[j] == third)
                print(i, j);
        }
    imp();
}

