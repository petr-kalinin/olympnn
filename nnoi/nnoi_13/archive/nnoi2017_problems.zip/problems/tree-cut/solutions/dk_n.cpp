#include <cstdio>
#include <cstring>
#include <algorithm>
#include <vector>
#include <iostream>
#include <cassert>
#include <cmath>
#include <string>
#include <queue>
#include <set>
#include <map>
#include <cstdlib>

using namespace std;

#define INF 1e+9
#define mp make_pair
#define pb push_back
#define fi first
#define fs first
#define se second
#define i64 long long
#define li long long
#define lint long long
#define pii pair<int, int>
#define vi vector<int>

#define forn(i, n) for (int i = 0; i < (int)n; i++)
#define fore(i, b, e) for (int i = (int)b; i <= (int)e; i++)

const int maxn = 1e6;

vi special;
vi edges[maxn + 5];
int total[maxn + 5];
int w[maxn + 5];
int third;

int dfs(int v) {
    total[v] = w[v];
    int lower = -1;
    for (int u : edges[v]) {
        int res = dfs(u);
        if (res != -1)
            lower = res;
        total[v] += total[u];
    }
    if (total[v] == 2 * third && lower != -1) {
        printf("%d %d\n", v, lower);
        exit(0);
    }
    if (total[v] == third && lower == -1)
        special.pb(v);
    if (lower != -1)
        return lower;
    return total[v] == third ? v : -1;
}

int main() {
#ifdef LOCAL
    freopen("inp", "r", stdin);
    //freopen("outp", "w", stdout);
#endif
    int n, root = -1, sum = 0;
    scanf("%d", &n);
    fore(j, 1, n) {
        int anc;
        scanf("%d%d", &anc, &w[j]);
        if (anc == 0)
            root = j;
        else
            edges[anc].pb(j);
        sum += w[j];
    }
    assert(root != -1);
    if (abs(sum) % 3 != 0) {
        printf("-1");
        exit(0);
    }
    third = sum / 3;
    dfs(root);
    if (special.size() < 2)
        printf("-1");
    else printf("%d %d", special[0], special[1]);
}

