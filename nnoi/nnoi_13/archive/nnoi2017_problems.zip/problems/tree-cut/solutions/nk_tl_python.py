def solve():
    global timer, need, wasfirst, wasfirstid, waslast, waslastid, answer
    n = int(input())

    t = [0] * n
    gr = [[] for i in range(n)]
    ttsum = 0

    for i in range(n):
        x, t[i] = map(int, input().split())
        ttsum += t[i]
        x -= 1
        if x == -1:
            root = i
            continue
        gr[x].append(i)

    sumtemps = []
    timer = 0
    wasfirst = n + 2
    wasfirstid = -1
    waslast = -1
    waslastid = -1
    if ttsum % 3 > 0:
        print(-1)
        exit()
    need = ttsum // 3
    answer = []

    def go(cur):
        global timer, need, wasfirst, wasfirstid, waslast, waslastid, answer
        timer += 1
        curtimer = timer
        cursum = t[cur]
        for v in gr[cur]:
            cursum += go(v)
        if cursum == need and wasfirst < curtimer:
            answer = [wasfirstid, cur]
        if cursum == 2 * need and waslast > curtimer:
            answer = [waslastid, cur]
        if cursum == need:
            if wasfirstid == -1:
                wasfirstid = cur
                wasfirst = curtimer
            waslastid = cur
            waslast = timer
        #print("go %d, found %d, need %d" % (cur, cursum, need))
        return cursum

    go(root)

    if not answer:
        print(-1)
    else:
        print(answer[0] + 1, answer[1] + 1)


import sys
import threading

sys.setrecursionlimit(1000000)
threading.stack_size(156000000)
thread = threading.Thread(target=solve)
thread.start()
thread.join()
