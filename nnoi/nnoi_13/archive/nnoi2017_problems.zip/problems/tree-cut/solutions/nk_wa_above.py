def solve():
    #n = 99999
    n = int(input())

    t = [0] * n
    gr = [[] for i in range(n)]

    for i in range(n):
        x, t[i] = map(int, input().split())
        #x, t[i] = i, 1
        x -= 1
        if x == -1:
            root = i
            continue
        gr[x].append(i)

    sumtemps = []

    def go(cur):
        cursum = t[cur]
        for v in gr[cur]:
            cursum += go(v)
        sumtemps.append([cursum, cur])
        return cursum

    ttsum = go(root)
    #print(ttsum)
    ans1 = -1
    ans2 = -1
    for p in sumtemps:
        if p[0] * 3 == ttsum:
            if ans1 == -1:
                ans1 = p[1]
            elif ans2 == -1:
                ans2 = p[1]

    if ans2 == -1:
        print(-1)
    else:
        print(ans1 + 1, ans2 + 1)


import sys
import threading

sys.setrecursionlimit(1000000)
threading.stack_size(156000000)
thread = threading.Thread(target=solve)
thread.start()
thread.join()
