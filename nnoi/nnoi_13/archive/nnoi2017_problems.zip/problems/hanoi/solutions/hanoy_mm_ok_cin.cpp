#include <iostream>

using namespace std;

int a[100005];
int n, q;

int main()
{
	cin >> n;
	q = n - 1;
	for (int i = 0; i < n; ++i)
	{
		int x;
		cin >> x;
		--x;
		a[x] = 1;
		while(q >= 0 && a[q])
		{
			cout << q + 1 << " ";
			--q;
		}
		cout << endl;
	}
}