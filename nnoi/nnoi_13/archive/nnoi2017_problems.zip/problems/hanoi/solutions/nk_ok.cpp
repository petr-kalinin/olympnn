#include <bits/stdc++.h>

using namespace std;

using ll = long long;
using ld = long double;
using D = double;
using uint = unsigned int;

#ifdef WIN32
    #define LLD "%I64d"
#else
    #define LLD "%lld"
#endif

#define pb push_back
#define mp make_pair
#define all(x) (x).begin(),(x).end()
#define fi first
#define se second

const int maxn = 100005;

bool was[maxn];
int n;

int main()
{
    scanf("%d", &n);
    int need = n;
    for (int i = 0; i < n; i++)
    {
        int x;
        scanf("%d", &x);
        was[x] = true;
        while (need > 0 && was[need]) printf("%d ", need--);
        printf("\n");
    }
    return 0;
}