#!/usr/bin/python3
n = int(input())
a = map(int, input().split())
seen = [False] * (n + 1)
last = n + 1
for i in a:
    seen[i] = True
    was = False
    while seen[last - 1]:
        print(last - 1, end=" ")
        was = True
        last -= 1
    if was:
        print()