#include "testlib.h"
#include <iostream>

using namespace std;

int main(int argc, char* argv[])
{
    registerGen(argc, argv, 1);
    
    int n = atoi(argv[1]);
    int m = atoi(argv[2]);
    
    std::vector<int> a;
    for (int i=n; i>=1; i--)
        a.push_back(i);
    for (int i=0; i<m; i++) {
        int x = rnd.next(0, n-1);
        int y = rnd.next(0, n-1);
        swap(a[x], a[y]);
    }
    
    cout << n << endl;
    for (int i=0; i<n; i++) {
        cout << a[i];
        if (i != n-1) cout << " ";
    }
    cout << endl;

    return 0;
}