#include "testlib.h"

using namespace std;

int main(int argc, char* argv[])
{
    registerValidation(argc, argv);
    
    int n = inf.readInt(1, 100000, "n");
    inf.readEoln();
    
    std::vector<bool> seen(n + 1, false);

    for (int i = 0; i < n; i++)
    {
        int x = inf.readLong(1, n, format("a[%d]", i + 1));
        ensuref(!seen[x], "Number repeats");
        seen[x] = true;

        if (i + 1 < n)
            inf.readSpace();
    }
    inf.readEoln();

    inf.readEof();
    return 0;
}