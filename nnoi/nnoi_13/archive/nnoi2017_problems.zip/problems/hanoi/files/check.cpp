#include "testlib.h"
#include <string>
#include <vector>
#include <sstream>

using namespace std;

int main(int argc, char * argv[])
{
    setName("compare files as sequence of ints in lines");
    registerTestlibCmd(argc, argv);

    int n = 0;
    while (!ans.eof()) 
    {
        std::vector<int> ja, pa;
        
        while (!ans.seekEoln())
            ja.push_back(ans.readLong());

        while (!ouf.seekEoln())
            pa.push_back(ouf.readLong());

        n++;

        if (ja != pa)
            quitf(_wa, "%d%s lines differ", n, englishEnding(n).c_str());
    }
    
    quitf(_ok, "%d lines", n);
}