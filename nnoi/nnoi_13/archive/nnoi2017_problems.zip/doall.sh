echo [INFO]: Building problem 'best-before'.
cd problems/best-before
./doall.sh
cd -

echo [INFO]: Building problem 'goto-center'.
cd problems/goto-center
./doall.sh
cd -

echo [INFO]: Building problem 'hanoi'.
cd problems/hanoi
./doall.sh
cd -

echo [INFO]: Building problem 'no-change'.
cd problems/no-change
./doall.sh
cd -

echo [INFO]: Building problem 'queue'.
cd problems/queue
./doall.sh
cd -

echo [INFO]: Building problem 'tree-cut'.
cd problems/tree-cut
./doall.sh
cd -

echo [INFO]: Building russian contest statement.
cd statements/russian
./doall.sh
cd -

