echo [INFO]: Wiping problem 'best-before'.
cd problems/best-before
./wipe.sh
cd -

echo [INFO]: Wiping problem 'goto-center'.
cd problems/goto-center
./wipe.sh
cd -

echo [INFO]: Wiping problem 'hanoi'.
cd problems/hanoi
./wipe.sh
cd -

echo [INFO]: Wiping problem 'no-change'.
cd problems/no-change
./wipe.sh
cd -

echo [INFO]: Wiping problem 'queue'.
cd problems/queue
./wipe.sh
cd -

echo [INFO]: Wiping problem 'tree-cut'.
cd problems/tree-cut
./wipe.sh
cd -

echo [INFO]: Wiping russian contest statement.
cd statements/russian
./wipe.sh
cd -

