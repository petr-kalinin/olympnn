cd ../../problems/best-before/statements/russian
rm -f *.log
rm -f *.aux
rm -f *.dvi
rm -f *.pdf
rm -f *.ps
cd -

cd ../../problems/goto-center/statements/russian
rm -f *.log
rm -f *.aux
rm -f *.dvi
rm -f *.pdf
rm -f *.ps
cd -

cd ../../problems/hanoi/statements/russian
rm -f *.log
rm -f *.aux
rm -f *.dvi
rm -f *.pdf
rm -f *.ps
cd -

cd ../../problems/no-change/statements/russian
rm -f *.log
rm -f *.aux
rm -f *.dvi
rm -f *.pdf
rm -f *.ps
cd -

cd ../../problems/queue/statements/russian
rm -f *.log
rm -f *.aux
rm -f *.dvi
rm -f *.pdf
rm -f *.ps
cd -

cd ../../problems/tree-cut/statements/russian
rm -f *.log
rm -f *.aux
rm -f *.dvi
rm -f *.pdf
rm -f *.ps
cd -

rm -f *.log
rm -f *.aux
rm -f *.dvi
rm -f *.pdf
rm -f *.ps
