#include <stdio.h>
#include <assert.h>
#include <string.h>
#include <stdlib.h>

#define fin "bubble.in"
#define fout "bubble.out"

int Sqrt(int a)
{
	int l=1,r=400;
	while (r-l>1){
		int x=(l+r)/2;
		if (x*x<=a)l=x;else r=x;
	}
	return r;
}

int main()
{
	int ans[1000];
	int n,i,size,*res,l;
	freopen(fin,"rt",stdin);
	freopen(fout,"wt",stdout);

	scanf("%d",&n);
	assert(1<=n&&n<=10000);

	memset(ans,0,sizeof(ans));
	for (i=0;i<n;i++){
		int x,y,j;
		scanf("%d",&x);
		assert(1<=x&&x<=1000);
		y=Sqrt(x);
		for (j=2;j<y;j++){
			int d=0;
			while (x%j==0){
				d++;
				x/=j;
			}
			if (d>ans[j])ans[j]=d;
		}
		if (x!=1&&ans[x]<1)ans[x]=1;
	}

	n=10;l=1;size=0;
	for (i=0;i<1000;i++){
		if (i==n){
			l++;
			n*=10;
		}
		size+=ans[i]*l;
	}

	res=(int*)calloc(size+1,sizeof(int));
	memset(res,0,sizeof(res));
	res[0]=1;
	for (i=2;i<1000;i++){
		while (ans[i]){
			int j;
			for (j=0;j<size;j++)res[j]*=i;
			for (j=0;j<size;j++){
				res[j+1]+=res[j]/10;
				res[j]%=10;
			}
			ans[i]--;
		}
	}

	while (res[size]==0)size--;
	for (i=size;i>=0;i--)printf("%d",res[i]);printf("\n");
	free(res); res=NULL;
	fflush(stdout);

	return 0;
}
