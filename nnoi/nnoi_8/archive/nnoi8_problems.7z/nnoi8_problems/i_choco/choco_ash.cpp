#include <iostream>
#include <cstdio>
#include <cstdlib>

using namespace std;

//for linux gcc? or 32-bit gcc?
//typedef long long int __int64;

const int MAXN = 15;
const int MAXK = 15;

int n, k;
int value[MAXN];

int maskValue[1 << MAXN];
__int64 dp[MAXK][1 << MAXN];
bool was[MAXK][1 << MAXN];

__int64 getAnswer(int mask, int friendsCount) {
	if (friendsCount == k)
		return 1;

	if (was[friendsCount][mask])
		return dp[friendsCount][mask];

	__int64 answer = 0;
	if (friendsCount == 0) {
		for (int currentMask = mask; currentMask > 0; currentMask = (mask & (currentMask - 1)))
			answer += getAnswer(mask - currentMask, 1);
	}
	else {
		// ������� �������� ������ ��������� ������� �����
		int sumValue = maskValue[(1 << n) - 1 - mask] / friendsCount;
		for (int currentMask = mask; currentMask > 0; currentMask = (mask & (currentMask - 1)))
			if (maskValue[currentMask] == sumValue)
				answer += getAnswer(mask - currentMask, friendsCount + 1);
	}

	was[friendsCount][mask] = true;
	dp[friendsCount][mask] = answer;
	return answer;
}

int main() {
	freopen("choco.in", "r", stdin);
	freopen("choco.out", "w", stdout);

	cin >> n >> k;
	for (int i = 0; i < n; i++)
		cin >> value[i];
	for (int i = 0; i < (1 << n); i++)
		for (int j = 0; j < n; j++)
			if ((i & (1 << j)) != 0)
				maskValue[i] += value[j];

	cout << getAnswer((1 << n) - 1, 0) << endl;

	return 0;
}
