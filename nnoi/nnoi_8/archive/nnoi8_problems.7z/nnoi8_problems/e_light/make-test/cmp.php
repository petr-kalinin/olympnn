<?
set_magic_quotes_runtime(0);
$f=file($argv[1]);
$g=file($argv[2]);
if (count($f)<>count($g)) die("Different count!");
foreach ($f as $id=>$s){
  if (trim($s)<>trim($g[$id])) printf("X");
  else printf(".");
}
?>
