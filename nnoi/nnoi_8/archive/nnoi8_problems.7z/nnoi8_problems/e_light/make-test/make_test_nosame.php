#!/usr/bin/php
<?

function pexec($cmd,&$out) {
  global $nn;
  printf("[$nn] $cmd...");
  unset($output);
  //only under linux
//  $cmd="./".$cmd;
  //----
  exec($cmd,$output,$ret);
  printf("done\n");
  $out=$output;
  return $ret;
}

function check_out($sol,$o1){
  pexec($sol,$o2);
  if (count($o1)<>count($o2)) {
    printf("different count! ".$sol."\n");
    die();
  }
  $res=array();
  for ($j=0;$j<count($o1);$j++)
    if ($o1[$j]<>$o2[$j]) 
      $res[]=$j;
  return $res;
}

function parse($s){
 $s=trim($s);
 preg_match("/(-?\d+\s+-?\d+)\s+(-?\d+\s+-?\d+)\s+(-?\d+\s+-?\d+)/",$s,$m);
 return array($m[1],$m[2],$m[3]);
}

function parse3($s){
 $s=trim($s);
 preg_match("/(\d+)\s+(\d+)\s+(\d+)/",$s,$m);
 return array($m[1],$m[2],$m[3]);
}

function printpoint($f,$p,$t){
  list($x,$y)=explode(" ",$p);
  fprintf($f,$x*$t[0][0]+$y*$t[0][1]+$t[0][2]);
  fprintf($f," ");
  fprintf($f,$x*$t[1][0]+$y*$t[1][1]+$t[1][2]);
  fprintf($f," ");
}

function printtest($f,$test,$g,$ouf){
  fprintf($f,$test[0].$test[1]);
  fprintf($g,$ouf);
}

$good_sol=array("check light.in light.out _00.a","light_ve","light_pk_real","light_pk_real_2");
$bad_sol=array(
"light_pk_divide",
//"light_pk_wrong2",
"light_pk_wrong3",
"light_pk_wrong4",
"light_pk_wrong5",
);

$ct=array();
foreach ($bad_sol as $sol){
   $ct[$sol]=array();
}

$couf=array();
foreach ($bad_sol as $sol){
   $couf[$sol]=array();
}

$mult_coeff=1;
$maxtest=10;
$needtest=floor($maxtest/count($bad_sol)/$mult_coeff);
//$needtest=1;
printf("Need $needtest tests\n");

$nn=0;
do {
    $nn++;
    mt_srand();
    $seed=mt_rand(1,1000000);
    printf($seed."\n");

    mt_srand($seed);
    $r=mt_rand(1,3);
//    $r=3;
    $tt=1000;
    if ($r==1) {$maxd=10; /*$tt=10;*/}
    elseif ($r==2) $maxd=100;
    elseif ($r==3) $maxd=700;
    
    $rand=mt_rand(1,1000000);
    $cmd="genboth $rand $tt $maxd 10 > light.in";
    pexec($cmd,$tmp);
    
    $ans=array("1 2 3","1 3 2","2 1 3","2 3 1","3 1 2","3 2 1");
    $f=fopen("light.out","w");
    for ($t=0;$t<$tt;$t++)
       fprintf($f,$ans[mt_rand(0,count($ans)-1)]."\n");
    fclose($f);

    $test=file("light.in");
    $ouf=file("light.out");

    pexec($good_sol[0],$main_out);
    foreach ($good_sol as $id=>$sol) if ($id<>0) {
       $res=check_out($sol,$main_out);
       if (count($res)<>0) {
	  printf("Found difference ".$sol);
	  var_dump($res);
	  die();
      }
    }
    $was=array();
    foreach ($bad_sol as $id=>$sol) if (count($ct[$sol])<$needtest) {
      $res=check_out($sol,$main_out);
      if (count($res)<>0) {
         printf("Found ".count($res)." contr-tests for ".$sol."!\n");
         foreach ($res as $num) if (!isset($was[$num])) {
           $was[$num]=1;
           $t=array($test[2*$num+1],$test[2*$num+2]);
           $ct[$sol][]=$t;
           $couf[$sol][]=$ouf[$num];
         }
      }
    }
    
    printf("[ ");
    $done=true;
    foreach ($bad_sol as $sol) {
      printf(count($ct[$sol])." ");
      $done = ($done and (count($ct[$sol])>=$needtest));
    }
    printf("] of $needtest\n");
     
} while (!$done);

$f=fopen("light.in","w");
$g=fopen("light.out","w");
fprintf($f,(count($bad_sol)*$needtest*$mult_coeff)."\n");
foreach ($bad_sol as $sol)
  for ($i=0;$i<$needtest;$i++) {
     printtest($f,$ct[$sol][$i],$g,$couf[$sol][$i]);
  }
//var_dump($ct);

printf("Done!");
?>