#!/usr/bin/php
<?

function pexec($cmd,&$out) {
  global $nn;
  printf("[$nn] $cmd...");
  unset($output);
  exec($cmd,$output,$ret);
  printf("done\n");
//  printf(implode("\n",$output)."\n");
  $out=$output;
  return $ret;
}


$nn=0;
while (true) {
    $nn++;
    mt_srand();
    $seed=mt_rand(1,1000000);
    printf($seed."\n");

    mt_srand($seed);
    $r=mt_rand(1,3);
//    $r=1;
    $tt=1000;
    if ($r==1) {$maxd=10; $tt=10;}
    elseif ($r==2) $maxd=100;
    elseif ($r==3) $maxd=800;
    
//    $tt=1;
    
    $rand=mt_rand(1,1000000);
    $cmd="genboth $rand $tt $maxd 10 > light.in";
    pexec($cmd,$tmp);
    
    $ans=array("1 2 3","1 3 2","2 1 3","2 3 1","3 1 2","3 2 1");
    $f=fopen("light.out","w");
    for ($t=0;$t<$tt;$t++)
       fprintf($f,$ans[mt_rand(0,count($ans)-1)]."\n");
    fclose($f);
    
    $checkers=array("check light.in light.out _00.a","check_ve",/*"check_pk_divide",*/"check_pk_real","check_pk_real_2");
    $outs=array();
    foreach ($checkers as $i=>$ch)
        pexec($ch,$outs[$i]);
    for ($i=1;$i<count($outs);$i++){
        if (count($outs[$i])<>count($outs[0])) {
            printf("different count! $i vs 0");
            die();
        }
        for ($j=0;$j<count($outs[0]);$j++)
            if ($outs[0][$j]<>$outs[$i][$j]) {
                printf("Different: ".($j+1)."! 0 vs $i");
                die();
            }
    }
//    var_dump($outs);
//    die();
}
?>