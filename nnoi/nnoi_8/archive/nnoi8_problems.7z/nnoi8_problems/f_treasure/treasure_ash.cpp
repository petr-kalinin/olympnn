#include <iostream>
#include <algorithm>
#include <vector>
#include <cstdio>

using namespace std;

const int MAXN = 5000;
const int INF = 2100000000;

int n;
int a[MAXN], b[MAXN];
int table[MAXN][MAXN];
bool use[MAXN][MAXN], was[MAXN][MAXN];
int id[MAXN];

bool cmp(int i, int j) {
	return a[i] > a[j];
}

int getans(int p, int c) {
	if (p == n) {
		if (c != n / 2)
			return -INF;
		else
			return 0;
	}
	if (c * 2 < p || c > n / 2)
		return -INF;
	int &ans = table[p][c];
	if (was[p][c])
		return ans;
	was[p][c] = true;
	ans = getans(p + 1, c + 1);
	use[p][c] = true;
	int tmp = getans(p + 1, c) + b[id[p]];
	if (tmp > ans) {
		ans = tmp;
		use[p][c] = false;
	}
	return ans;
}

int main() {
	freopen("treasure.in", "r", stdin);
	freopen("treasure.out", "w", stdout);

	cin >> n;
	for (int i = 0; i < n; i++)
		cin >> a[i];
	for (int i = 0; i < n; i++)
		cin >> b[i];
	for (int i = 0; i < n; i++)
		id[i] = i;
	sort(id, id + n, cmp);

	getans(0, 0);

	int cur = 0;
	vector<int> v1, v2;
	for (int i = 0; i < n; i++) {
		if (use[i][cur]) {
			v1.push_back(id[i]);
			cur++;
		}
		else
			v2.push_back(id[i]);
	}

	for (int i = 0; i < n / 2; i++)
		cout << v1[i] + 1 << ' ' << v2[i] + 1 << endl;

	return 0;
}
