#include <cstdio>
#include <iostream>
#include <cstring>
#include <string>
#include <algorithm>
#include <cstdlib>
#include <vector>
#include <cmath>
#include <set>
#include <map>
#include <deque>
#include <bitset>

#define sqr(x) ((x) * (x))
#define fi first
#define se second
#define mp make_pair
#define pb push_back
#define y0 ywuerosdfhgjkls
#define y1 hdsfjkhgjlsdfhgsdf
#define j1 j924
#define j0 j2834
#define sqrt(x) (sqrt(abs(x)))
#define re return
#define sz(x) ((int)(x).size())
#define all(x) (x).begin(), (x).end()
#define rep(i, n) for (int i = 0; i < (n); i++)
#define rrep(i, n) for (int i = ((n) - 1); i >= 0; i--)
#define fill(a, x) memset(a, x, sizeof(a))

using namespace std;

typedef long long ll;
typedef long double ld;
typedef pair <int, int> ii;
typedef vector <int> vi;
typedef vector <ii> vii;
typedef vector <vi> vvi;
typedef double D;
typedef vector <string> vs;

template <class T> inline T abs(T a) {
	return a > 0 ? a : -a;
}

int n;
int m;

pair <ii, int> a[5000];

int dp[5000][5000];

char go[5000][5000];
int ans[5000];

int main() {
	freopen("treasure.in", "r", stdin);
	freopen("treasure.out", "w", stdout);
	cin >> n;
	rep(i, n)
		cin >> a[i].fi.fi;
	rep(i, n) {
		cin >> a[i].fi.se;
		a[i].se = i;
	}
	sort(a, a + n);
	reverse(a, a + n);
	fill(go, 255);
	rep(i, n)
		rep(j, n)
			dp[i][j] = -1e9;
	dp[0][1] = 0;
	go[0][1] = 0;
	for (int i = 1; i < n; i++) {
		//flint
		rep(j, n - 1) {
			dp[i][j + 1] = max(dp[i][j + 1], (i ? dp[i - 1][j] : 0));
			go[i][j + 1] = 0;
		}
		//jack
		for (int j = 1; j < n; j++) {
			int tmp = (i ? dp[i - 1][j] : 0) + a[i].fi.se;
			if (dp[i][j - 1] < tmp) {
				dp[i][j - 1] = tmp;
				go[i][j - 1] = 1;
			}
		}
	}
	ii cur = mp(n - 1, 0);
	while (cur.fi >= 0) {
		ans[cur.fi] = go[cur.fi][cur.se];
		if (ans[cur.fi])
			cur.se++;
		else
			cur.se--;
		cur.fi--;
	}
	rep(i, n) {
		if (ans[i] == 0) 
			rep(j, n)
				if (ans[j] == 1) {
					cout << a[i].se + 1 << ' ' << a[j].se + 1 << endl;
					ans[j] = 2;
					break;
				}
	}
	return 0;
}
