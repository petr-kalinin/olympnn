#include <cstdio>
#include <vector>

using namespace std;

vector<int> ans;
int         n, N, mx;

bool is_happy(int x)
{
  int r = 0;
  for(int i=0; i<n; ++i) r += x % 10, x /= 10;
  for(int i=0; i<n; ++i) r -= x % 10, x /= 10;
  return r==0;
}

void rec_print(int x, int n)
{
  if (!n) return;
  rec_print(x / 10, n - 1);
  printf("%i", x % 10);
}

bool solve(bool print)
{
  for(int i=0; i<N; ++i) if (!is_happy(i))
  {
    int down = i - 1, up = i + 1;
    while (!is_happy(down)) down--;
    while (!is_happy(up)) up++;
    down = (i - down < up - i) ? i - down : up - i;
    if (down > mx)
      mx = down;
    else
      if (down == mx && print) ans.push_back(i);
  }
}

void sq(int k, int v)
{
  for(int i=0; i<k; ++i) printf("%i", v);
}

void p()
{
  printf("\n");
}

int main()
{
  freopen("tickets.in", "r", stdin);
  freopen("tickets.out", "w", stdout);
  scanf("%i", &n);
  if (n==1)
  {
    N = 1;
    for(int i=0; i<2*n; ++i) N *= 10;
    mx = 0;
    solve(false);
    solve(true);
    printf("%i\n", ans.size());
    for(int i=0; i<ans.size(); ++i) rec_print(ans[i], 2*n), printf("\n");
  }
  else
  {
    sq(1, 4); p();
    sq(n, 0); sq(1, 5); sq(n-1, 0); p();
    sq(n, 0); sq(1, 5); sq(n-2, 0); sq(1, 1); p();
    sq(n, 9); sq(1, 4); sq(n-2, 9); sq(1, 8); p();
    sq(n, 9); sq(1, 4); sq(n-2, 9); sq(1, 9); p();
  }
}