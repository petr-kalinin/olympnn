#include <iostream>
#include <cstdio>
#include <cstring>

#define mp make_pair

using namespace std;

int n;

const int M = 13;

int col[M][4];

int table[M + 1][1 << 16];
int next[M + 1][1 << 16];
int cur[M + 1][1 << 16];

int good[81];
pair<int, int> res[4][16][4];

inline int getbits(int x, int p, int c) {
	return (x >> p) & ((1 << c) - 1);
}

pair<int, int> getres(int col, int prev, int next) {
	int l[2];
	for (int i = 0; i < 2; i++) {
		l[i] = (prev >> (i * 2)) & 3;
		int c = (next >> i) & 1;
		if (c == 0 && l[i] < 3 && l[i] != 0)
			return mp(-1, -1);
		if (c == 0)
			l[i] = 0;
		else {
			col--;
			l[i]++;
		}
		if (l[i] > 3)
			l[i] = 3;
	}

	if (col < 0)
		return mp(-1, -1);
	if (l[0] < l[1]) swap(l[0], l[1]);
	return mp(col, l[0] + l[1] * 4);
}

int getgood(int x) {
	int sum = 0;
	int m = 0;
	for (int i = 0; i < 4; i++) {
		int c = x % 3;
		m = max(m, c);
		sum += c;
		x /= 3;
	}
	return sum >= 3 * m;
}

int getans(int p, int prev) {
	int &ans = table[p][prev];

	if (ans != -1)
		return ans;

	if (p == M) {
		for (int i = 0; i < 8; i++) {
			int c = getbits(prev, 2 * i, 2);
			if (c == 1 || c == 2) {
				ans = 0;
				return ans;
			}
		}
		ans = 1;
		return ans;
	}

	for (int i = 0; i < 256; i++) {
		int f = 1;
		int used = 0;
		int next = 0;
		for (int j = 3; j >= 0; j--) {
			pair<int, int> x  = res[col[p][j]][getbits(prev, j * 4, 4)][getbits(i, j * 2, 2)];
			if (x.first == -1) {
				f = 0;
				break;
			}
			next = next * 16 + x.second;
		}
		if (f) {
			if (getans(p + 1, next) != 0 && good[used]) {
				::next[p][prev] = next;
				cur[p][prev] = i;
				ans = 1;
				return ans;
			}
		}
	}

	ans = 0;
	return ans;
}

int main() {
	freopen("rummikub.in", "r", stdin);
	freopen("rummikub.out", "w", stdout);

	for (int i = 0; i < 81; i++)
		good[i] = getgood(i);

	for (int i = 0; i < 4; i++)
		for (int j = 0; j < 16; j++)
			for (int k = 0; k < 4; k++)
				res[i][j][k] = getres(i, j, k);

	cin >> n;
	for (int i = 0; i < n; i++) {
		string s;
		cin >> s;
		int x = s[0] - 'A';
		int y = s[1] - '0';
		if (s.length() > 2)
			y = y * 10 + s[2] - '0';
		y--;
		col[y][x]++;
	}

	memset(table, -1, sizeof(table));
	int ans = getans(0, 0);
	cout << ans << endl;

	return 0;
}
