#include <cstdio>
#include <cstdlib>
#include <algorithm>

using namespace std;

#define MAXN 1010

int a[MAXN];
int b[MAXN];
int f[MAXN][MAXN];

int n, m, p, q;

int main() {
    freopen("schedule.in", "r", stdin);
    freopen("schedule.out", "w", stdout);

    scanf("%i %i %i %i", &n, &m, &p, &q);
    for(int i=1; i<=n; ++i) {
        scanf("%i", &a[i]);
    }

    for(int i=1; i<=m; ++i) {
        scanf("%i", &b[i]);
    }

    sort(a + 1, a + n + 1);
    sort(b + 1, b + m + 1);

    for(int i=0; i<=n; ++i) f[i][0] = p*i;
    for(int i=0; i<=m; ++i) f[0][i] = q*i;

    for(int i=1; i<=n; ++i)
        for(int j=1; j<=m; ++j) {
            f[i][j] = min(f[i][j-1] + q, f[i-1][j] + p);
            f[i][j] = min(f[i][j], abs(a[i] - b[j]) + f[i-1][j-1]);
        }

    printf("%i\n", f[n][m]);
    return 0;
}