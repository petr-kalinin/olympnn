#include <iostream>
#include <fstream>
#include <cmath>
#include <cstdlib>
#include <map>
#include <set>
#include <vector>
#include <cstring>
#include <string>
#include <algorithm>
#include <queue>
#include <cassert>

using namespace std;

const int nmax = 1e6;
int n;

int a[nmax];

int main()
{
	freopen("holidays.in","r",stdin);
	freopen("holidays.out","w",stdout);
	cin >> n;
	for (int i = 0; i < n; i ++) {
		cin >> a[i];
	}	
	for (int i = 0; i < n; i ++) {
		if (a[i] > 0) {
			a[i + 1] += a[i] - 1;
			a[i] = 1;
		}
	}
	for (int i = 0; i < n; i ++) {
		if (a[i] > 0) {
			printf("+ ");
		} else {
			printf("- ");
		}
	}
	for (int i = 0; i < a[n]; i ++) {
		printf("+ ");
	}
	printf("\n");
	return 0;
}
