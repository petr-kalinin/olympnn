// ������ ����� �������
#include <windows.h>
#include <cstdio>
#include <cstdlib>
#include <algorithm>
#include <vector>

using namespace std;

#define MAXN 1010
#define INF  1000000000

vector<int> a, pa;
vector<int> b, pb;

int n, m, p, q;
int finish;
int ans;

void bf(int step, int tek_penalty, int pair_count) {
    if (GetTickCount() > finish) return;    
    if (step == n) {
        tek_penalty += q*(m - pair_count);
        if (tek_penalty < ans) ans = tek_penalty;
    } else {
        if (tek_penalty >= ans) return;
        for(int i=0; i<m; ++i) if (pb[i] == -1) {
            pb[i] = 1;
            bf(step + 1, tek_penalty + abs(a[step] - b[i]), pair_count + 1);
            pb[i] = -1;
        }
        bf(step + 1, tek_penalty + p, pair_count);
    }
}

int main() {
    freopen("schedule.in", "r", stdin);
    freopen("schedule.out", "w", stdout);

    scanf("%i %i %i %i", &n, &m, &p, &q);
    a.resize(n);
    b.resize(m);
    pa.resize(n);
    pb.resize(m);

    for(int i=0; i<n; ++i) {
        scanf("%i", &a[i]);
        pa[i] = -1;
    }

    for(int i=0; i<m; ++i) {
        scanf("%i", &b[i]);
        pb[i] = -1;
    }

    sort(a.begin(), a.end());
    sort(b.begin(), b.end());

    ans = INF;

    finish = GetTickCount() + 960;

    bf(0, 0, 0);

    printf("%i\n", ans);
    return 0;
}