#include <iostream>
#include <cstdio>
#include <cstring>
#include <vector>
#include <algorithm>

#define mp make_pair
#define sz(x) ((int)(x).size())

using namespace std;

const int M = 13;

int col[M][4];
int table[M + 1][1 << 16], next[M + 1][1<<16],
  used[M + 1][1 << 16], cur[M + 1][1 << 16];
int good[81];

pair<int, int> res[4][16][4];

int getbits(int x, int p, int c) {
  return (x >> p) & ((1 << c) - 1);
}

pair<int, int> getres(int col, int prev, 
                               int next) {
  int l[2];
  for (int i = 0; i < 2; i++) {
    l[i] = (prev >> (i * 2)) & 3;
    int c = (next >> i) & 1;
    if (c == 0 && l[i] < 3 && l[i] != 0)
      return mp(-1, -1);
    if (c == 0) l[i] = 0;
    else {
      col--;
      l[i]++;
    }
    if (l[i] > 3) l[i] = 3;
  }
  if (col < 0) return mp(-1, -1);
  if (l[0] < l[1]) swap(l[0], l[1]);
  return mp(col, l[0] + l[1] * 4);
}

int getgood(int x) {
  int sum = 0, m = 0;
  for (int i = 0; i < 4; i++) {
    int c = x % 3;
    m = max(m, c);
    sum += c;
    x /= 3;
  }
  return sum >= 3 * m;
}

int getans(int p, int prev) {
  int &ans = table[p][prev];
  if (ans != -1) return ans;
  if (p == M) {
    for (int i = 0; i < 8; i++) {
      int c = getbits(prev, 2 * i, 2);
      if (c == 1 || c == 2) {
        ans = 0;
        return ans;
      }
    }
    ans = 1;
    return ans;
  }
  for (int i = 0; i < 256; i++) {
    int f = 1, used = 0, next = 0;
    for (int j = 3; j >= 0; j--) {
      pair<int, int> x  = res[col[p][j]]
          [getbits(prev, j * 4, 4)]
          [getbits(i, j * 2, 2)];
      if (x.first == -1) {
        f = 0;
        break;
      }
      next = next * 16 + x.second;
      used = used * 3 + x.first;
    }
    if (f) {
      if (getans(p+1, next)!=0 && good[used]) {
        ::next[p][prev] = next;
        ::used[p][prev] = used;
        cur[p][prev] = i;
        ans = 1;
        return ans;
      }
    }
  }
  ans = 0;
  return ans;
}

pair<int, int> parse(string s) {
  int x = s[0] - 'A', y = 0;
  for (int i = 1; i < sz(s); i++)
    y = y * 10 + s[i] - '0';
  return make_pair(x, y - 1);
}

string getstring(pair<int, int> x) {
  string ans = "";
  ans += (char) (x.first + 'A');
  if (x.second >= 9)
    ans += (char) ((x.second + 1) / 10 + 48);
  ans += (char) ((x.second + 1) % 10 + 48);
  return ans;
}

vector<vector<pair<int, int> > > v;
vector<pair<int, int> > column[4][2];

void getrows(int p, int used) {
  int col[4], sum = 0;
  for (int i = 0; i < 4; i++) {
    col[i] = used % 3;
    used /= 3;
    sum += col[i];
  }
  if (sum == 0) return;
  if (sum < 5) {
    vector<pair<int, int> > ans;
    for (int i = 0; i < 4; i++)
      if (col[i]) ans.push_back(mp(i, p));
    v.push_back(ans);
  }
  else {
    vector<pair<int, int> > v1, v2;
    for (int i = 0; i < 4; i++) {
      if (col[i]) v1.push_back(mp(i, p));
      if (col[i] > 1)
        v2.push_back(mp(i, p));
    }
    while (sz(v2) < 3) {
      for (int i = 0; i < sz(v1); i++)
        if (count(v2.begin(), v2.end(),
                         v1[i]) == 0) {
          v2.push_back(v1[i]);
          swap(v1[i], v1[sz(v1) - 1]);
          v1.pop_back();
          break;
        }
    }
    v.push_back(v1);
    v.push_back(v2);
  }
}

void restore(int p, int prev) {
  if (p == M) {
    for (int i = 0; i < 4; i++)
      for (int j = 0; j < 2; j++)
        if (sz(column[i][j]))
          v.push_back(column[i][j]);
    return;
  }
  int x = cur[p][prev], y = used[p][prev];
  getrows(p, y);
  for (int i = 0; i < 4; i++) {
    int cx = x & 3;
    x >>= 2;
    for (int j = 0; j < 2; j++) {
      if ((cx >> j) & 1)
        column[i][j].push_back(mp(i, p));
      else {
        if (sz(column[i][j]))
          v.push_back(column[i][j]);
        column[i][j].clear();
      }
    }
    if (sz(column[i][0]) < sz(column[i][1]))
      swap(column[i][0], column[i][1]);
  }
  restore(p + 1, next[p][prev]);
}

int main() {
  freopen("rummikub.in", "r", stdin);
  freopen("rummikub.out", "w", stdout);
  for (int i = 0; i < 81; i++)
    good[i] = getgood(i);
  for (int i = 0; i < 4; i++)
    for (int j = 0; j < 16; j++)
      for (int k = 0; k < 4; k++)
        res[i][j][k] = getres(i, j, k);
  int n;
  cin >> n;
  for (int i = 0; i < n; i++) {
    string s;
    cin >> s;
    pair<int, int> tmp = parse(s);
    col[tmp.second][tmp.first]++;
  }
  memset(table, -1, sizeof(table));
  int ans = getans(0, 0);
  if (ans == 0) {
    cout << -1 << endl;
    return 0;
  }
  restore(0, 0);
  cout << sz(v) << endl;
  for (int i = 0; i < sz(v); i++) {
    cout << sz(v[i]) << ' ';
    for (int j = 0; j < sz(v[i]); j++)
      cout << getstring(v[i][j]) << ' ';
    cout << endl;
  }
  return 0;
}