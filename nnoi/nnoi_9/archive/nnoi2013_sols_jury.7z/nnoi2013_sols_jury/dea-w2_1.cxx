// �������, ������� ���-�� ���������� ����������
#include <windows.h>
#include <cstdio>
#include <cstdlib>
#include <algorithm>
#include <vector>

using namespace std;

#define MAXN 1010
#define INF  1000000000

int a[MAXN];
int b[MAXN];

int n, m, p, q;
int finish;
int ans;

void bf(int step, int from, int tek_penalty, int pair_count) {
    if (GetTickCount() > finish) return;    
    if (step == n) {
        tek_penalty += q*(m - pair_count);
        if (tek_penalty < ans) ans = tek_penalty;

    } else {
        if (tek_penalty >= ans) return;
        for(int i=from; i<m; ++i) {
            bf(step + 1, i + 1, tek_penalty + abs(a[step] - b[i]), pair_count + 1);
        }
        bf(step + 1, from, tek_penalty + p, pair_count);
    }
}

int main() {
    freopen("schedule.in", "r", stdin);
    freopen("schedule.out", "w", stdout);

    scanf("%i %i %i %i", &n, &m, &p, &q);

    for(int i=0; i<n; ++i) {
        scanf("%i", &a[i]);
    }

    for(int i=0; i<m; ++i) {
        scanf("%i", &b[i]);
    }

    sort(a, a + n);
    sort(b, b + m);

    ans = INF;

    finish = GetTickCount() + 960;

    bf(0, 0, 0, 0);

    printf("%i\n", ans);
    return 0;
}