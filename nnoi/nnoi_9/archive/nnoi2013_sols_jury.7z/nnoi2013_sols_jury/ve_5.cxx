#include <cstdio>
#include <iostream>

using namespace std;

long long calc (long long x) {
	long long y = 0;
	while (x) {
		x /= 2;
		y += x;
	}
	return y;
}

int main () {
	freopen ("paint.in", "r", stdin);
	freopen ("paint.out", "w", stdout);
	long long l, r;
	cin >> l >> r;
	cout << calc (r) - calc (l - 1) << endl;
	return 0;
}