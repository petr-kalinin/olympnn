#include <iostream>
#include <fstream>
#include <cmath>
#include <cstdlib>
#include <map>
#include <set>
#include <vector>
#include <cstring>
#include <string>
#include <algorithm>
#include <queue>
#include <cassert>

using namespace std;

int n,m,p,q;

const int nmax = 2e3;
int d[nmax][nmax];
int a[nmax];
int b[nmax];

int main()
{
	freopen("schedule.in", "r", stdin);
	freopen("schedule.out", "w", stdout);
	cin >> n >> m >> p >> q;
	for (int i = 0; i < n; i ++) {
		cin >> a[i];
	}
	for (int i = 0; i < m; i ++) {
		cin >> b[i];
	}
	sort(a, a + n);
	sort(b, b + m);
	for (int i = 0; i <= n; i ++) {
		for (int j = 0; j <= m; j ++) {
			if (i == 0) {
				d[i][j] = j * q;
			} else if (j == 0) {
				d[i][j] = i * p;
			} else {
				d[i][j] = min(min(d[i-1][j] + p, d[i][j-1] + q), d[i-1][j-1] + abs(a[i - 1] - b[j - 1]));
			}
		}
	}
	cout << d[n][m] << endl;
	return 0;
}
