#include <fstream>
#include <iostream>

int main() {
	std::ifstream ifs("holidays.in");
	std::ofstream ofs("holidays.out");

	int multiplicity = 0, current = 0, n;
	ifs >> n;
	for (int i=0; i<n; i++) {
		ifs >> multiplicity;
		current += multiplicity;
		if (current > 0) {
			ofs << "+ ";
			current--;
		}
		else
			ofs << "- ";
	}
	for (int i=0; i<current; i++)
		ofs << "+ ";

	ifs.close();
	ofs.close();
}
