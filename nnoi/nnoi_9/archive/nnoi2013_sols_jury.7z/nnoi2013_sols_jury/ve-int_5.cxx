#include <cstdio>

using namespace std;

int calc (int x) {
	int y = 0;
	while (x) {
		x /= 2;
		y += x;
	}
	return y;
}

int main () {
	freopen ("paint.in", "r", stdin);
	freopen ("paint.out", "w", stdout);
	int l, r;
	scanf ("%d%d", &l, &r);
	printf ("%d\n", calc (r) - calc (l - 1));
	return 0;
}