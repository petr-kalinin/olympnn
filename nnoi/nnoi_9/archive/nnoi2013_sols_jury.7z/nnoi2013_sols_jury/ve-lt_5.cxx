#include <cstdio>
#include <iostream>

using namespace std;

int main () {
	freopen ("paint.in", "r", stdin);
	freopen ("paint.out", "w", stdout);
	long long l, r;
	cin >> l >> r;
	ll paint = 0;
	for (int t = l; t <= r; t++) {
		int k = 0;
		ll p = t;
		while (p % 2 == 0) {
			p /= 2;
			k++;
		}	
		paint += k;
	}
	cout << paint << endl;
	return 0;
}