#include <iostream>
#include <fstream>
#include <cmath>
#include <cstdlib>
#include <map>
#include <set>
#include <vector>
#include <cstring>
#include <string>
#include <algorithm>
#include <queue>
#include <cassert>

using namespace std;

ostream& operator << (ostream& out, vector<int> v) {
	out << v.size();
	for (int i = 0; i < v.size(); i ++) {
		out << " " << v[i];
	}
	return out;
}

int main()
{
	freopen("testing.in", "r", stdin);
	freopen("testing.out", "w", stdout);
	int n;
	cin >> n;
	int m = 0;
	while ((1 << m) < n) {
		m ++;
	}
	cout << m << endl;
	for (int i = 0; i < m; i ++) {
		vector <int> v;
		for (int j = 0; j < n; j ++) {
			if ((1 << i) & j) {
				v.push_back(j + 1);
			}
		}
		cout << v << endl;
	}	
	return 0;
}
