#include <cstdio>
#include <cstdlib>
#include <algorithm>

using namespace std;

int p[100000];

int main() {
	int n, ans;
	freopen("testing.in", "r", stdin);
	freopen("testing.out", "w", stdout);
	scanf("%d", &n);
	for (int i = 0; i < n; i++)
		p[i] = i;
	random_shuffle(p, p + n);
	ans = 0;
	while ((1 << ans) < n)
		ans++;
	printf("%d\n", ans);
	for (int i = 0; (1 << i) < n; i++) {
		int m = 0;
		for (int j = 0; j < n; j++)
			if ((p[j] & (1 << i)) == 0)
				m++;
		printf("%d", m);
		for (int j = 0; j < n; j++)
			if ((p[j] & (1 << i)) == 0)
				printf(" %d", j + 1);
		printf("\n");
	}
}
