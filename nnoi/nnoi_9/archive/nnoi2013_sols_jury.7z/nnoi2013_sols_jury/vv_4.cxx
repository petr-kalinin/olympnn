#include <cstdio>
#include <cstdlib>

int main() {
	int n, ans;
	freopen("testing.in", "r", stdin);
	freopen("testing.out", "w", stdout);
	scanf("%d", &n);
	ans = 0;
	while ((1 << ans) < n)
		ans++;
	printf("%d\n", ans);
	for (int i = 0; (1 << i) < n; i++) {
		int m = 0;
		for (int j = 0; j < n; j++) {
			if ((j & (1 << i)) == 0)
				m++;
		}
		printf("%d", m);
		for (int j = 0; j < n; j++)
			if ((j & (1 << i)) == 0)
				printf(" %d", j + 1);
		printf("\n");
	}
}
