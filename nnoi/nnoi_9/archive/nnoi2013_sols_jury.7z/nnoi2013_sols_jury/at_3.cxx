#include <iostream>
#include <fstream>
#include <vector>
#include <cstdlib>
#include <cassert>

using namespace std;

const int nmax = 1e5;

vector <int> g[nmax];

int answer[nmax];

int a[nmax];
int b[nmax];

int n;

void dfs(int v, int c) {
	if (answer[v] != 0 && answer[v] != c) {
		assert(false);
	}
	if (answer[v] == c) {
		return;
	}
	answer[v] = c;
	for (int i = 0; i < g[v].size(); i ++) {
		int u = g[v][i];
		dfs(u, 3 - c);
	}
}

int main() {
	freopen("http.in", "r", stdin);
	freopen("http.out", "w", stdout);
	cin >> n;
	for (int i = 0; i < n; i ++) {
		cin >> a[i]; 
		a[i] --;
	}
	for (int i = 0; i < n; i ++) {
		cin >> b[i];
		b[i] --;
	}
	for (int i = 0; i + 1 < n; i += 2) {
		g[a[i]].push_back(a[i + 1]);
		g[a[i + 1]].push_back(a[i]);
		g[b[i]].push_back(b[i + 1]);
		g[b[i + 1]].push_back(b[i]);
	}
	for (int i = 0; i < n; i ++) {
		if (answer[i] == 0) {
			dfs(i, 1);
		}
	}
	for (int i = 0; i < n; i ++) {
		if (answer[i] == 1) {
			cout << 'W';
		} else {
			cout << 'L';
		}
	}
	cout << endl;
	return 0;
}
