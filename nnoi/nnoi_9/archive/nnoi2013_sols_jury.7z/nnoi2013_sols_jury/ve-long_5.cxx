#include <iostream>
#include <cstdio>
#include <cstring>

using namespace std;

struct tlong {
	int len;
	int val[200];
	int clear () {
		len = 0;
		memset (val, 0, sizeof (val));
		return 0;
	}
};

tlong fstring (string x) {
	tlong a; a.clear ();
	a.len = x.size ();
	for (int i = 0; i < a.len; i++) a.val[a.len - i - 1] = x[i] - '0';
	return a;
}

int print (tlong a, bool nextline) {
	if (a.len == 0) printf ("0");
	for (int i = a.len; i > 0; i--)
		printf ("%d", a.val[i - 1]);
	if (nextline) printf ("\n");
}

tlong operator- (tlong a, tlong b) {
	tlong c;
	c.clear ();
	c.len = max (a.len, b.len);
	for (int i = 0; i < c.len; i++) {
		c.val[i] = c.val[i] + a.val[i] - b.val[i];
		if (c.val[i] < 0) {
			c.val[i + 1]--;
			c.val[i] += 10;
		}
	}
	while (c.len > 0 && c.val[c.len - 1] == 0) c.len--;
	return c;		
}

tlong operator+ (tlong a, tlong b) {
	tlong c;
	c.clear ();
	c.len = max (a.len, b.len);
	int r = 0;
	for (int i = 0; i < c.len; i++) {
		c.val[i] = a.val[i] + b.val[i] + r;
		r = c.val[i] / 10;
		c.val[i] %= 10;
	}
	while (r) {
		c.val[c.len] = r % 10;
		c.len++;
		r /= 10;
	}
	return c;		
}

tlong operator/ (tlong a, int b) {
	tlong d; d.clear ();
	long long c = 0;
	for (int i = a.len - 1; i >= 0; i--) {
		c = c * 10 + a.val[i];
		int k = c / b;
		c %= b;
		if (d.len > 0 || k > 0) {
			d.val[d.len] = k;
			d.len++;
		}
	}
	for (int i = 0; d.len - i - 1 > i; i++) swap (d.val[i], d.val[d.len - i - 1]);
	return d;
}

tlong calc (tlong x) {
	tlong y;
	y.clear ();
	while (x.len > 0) {
		x = x / 2;
		y = y + x;
	}
	return y;
}


int main () {
	freopen ("paint.in", "r", stdin);
	freopen ("paint.out", "w", stdout);
	string l, r;
	cin >> l >> r;
	print (calc (fstring (r)) - calc (fstring (l) - fstring ("1")), true);
}