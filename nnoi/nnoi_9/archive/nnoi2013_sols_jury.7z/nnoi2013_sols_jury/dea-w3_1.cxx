#include <cstdio>
#include <cstdlib>
#include <algorithm>
#include <vector>

using namespace std;

#define MAXN 1010
#define INF  1000000000

vector<int> a;
vector<int> b;

int n, m, p, q;

int main() {
    freopen("schedule.in", "r", stdin);
    freopen("schedule.out", "w", stdout);

    scanf("%i %i %i %i", &n, &m, &p, &q);
    a.resize(n);
    b.resize(m);

    for(int i=0; i<n; ++i) {
        scanf("%i", &a[i]);
    }

    for(int i=0; i<m; ++i) {
        scanf("%i", &b[i]);
    }

    if (n > m) {
        swap(n, m);
        swap(p, q);
        swap(a, b);
    }

    sort(a.begin(), a.end());
    sort(b.begin(), b.end());

    int ans = INF;

    for(int i=0; i+n<=m; ++i) {
        int tmp = (m - n)*q;
        for(int j=0; j<n; ++j) tmp += abs(a[j] - b[i+j]);
        ans = min(tmp, ans);
    }

    printf("%i\n", ans);
    return 0;
}