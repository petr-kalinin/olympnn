// �������� ����� ���� ��������, ����������� ����� �����
#include <windows.h>
#include <cstdio>
#include <cstdlib>
#include <algorithm>
#include <vector>

using namespace std;

#define MAXN 1010
#define INF  1000000000

#define ADD     1
#define DEL     2
#define CHANGE1 3
#define CHANGE2 4

int a[MAXN];
int b[MAXN];

int pa[MAXN];
int pb[MAXN];

int n, m, p, q;
int finish;
int ans;

struct improvement {
    int value;
    int cross;
    int method;
    int x, y;
    int x1, y1;
} best;

int main() {
    freopen("schedule.in", "r", stdin);
    freopen("schedule.out", "w", stdout);

    scanf("%i %i %i %i", &n, &m, &p, &q);

    for(int i=0; i<n; ++i) scanf("%i", &a[i]);

    for(int i=0; i<m; ++i) scanf("%i", &b[i]);


    for(int i=0; i<MAXN; ++i) pa[i] = pb[i] = -1;

    ans = n*p + m*q;
    best.value = 1;
    finish = GetTickCount() + 950;

    while (best.value && GetTickCount() < finish) {        
        best.value = 0;
        best.cross = 0;

        // add 
        for(int i=0; i<n; ++i) if (pa[i] == -1)
            for(int j=0; j<m; ++j) if (pb[j] == -1) {
                int tmp = p + q - abs(a[i] - b[j]);
                //printf("%i %i %i\n", i, j, tmp);
                if (tmp > best.value) {
                    best.value = tmp;
                    best.method = ADD;
                    best.x = i;
                    best.y = j;
                }
            }

        // delete 
        for(int i=0; i<n; ++i) if (pa[i] >= 0) {
            int tmp = abs(a[i] - b[ pa[i] ]) - p - q;
            if (tmp > best.value) {
                best.method = DEL;
                best.value = tmp;
                best.x = i;
                best.y = pa[i];
            }
        }

        // change
        for(int i=0; i<n; ++i) if (pa[i] >= 0) {
            for(int j=0; j<n; ++j) if (pa[j] == -1) {
                int tmp = abs(a[i] - b[ pa[i] ]) - abs(a[j] - b[ pa[i] ]);
                if (tmp > best.value) {
                    best.method = CHANGE1;
                    best.value = tmp;
                    best.x = i;
                    best.y = j;
                }
            }

            for(int j=i+1; j<n; ++j) if (pa[j] >= 0) {
                int tmp = abs(a[i] - b[pa[i]]) + abs(a[j] - b[pa[j]]) - abs(a[i] - b[pa[j]]) - abs(a[j] - b[pa[i]]);
                if (tmp > best.value) {
                    best.method = CHANGE2;
                    best.value = tmp;
                    best.x = i;
                    best.y = j;
                    best.x1 = pa[i];
                    best.y1 = pa[j];
                }

                if (best.value == 0 && tmp == 0 && pa[i] > pa[j]) {
                    best.method = CHANGE2;
                    best.value = tmp;
                    best.x = i;
                    best.y = j;
                    best.x1 = pa[i];
                    best.y1 = pa[j];
                    best.cross = 1;
                }
                
            }
        }

        if (best.value || best.cross) {
            ans -= best.value;
            switch(best.method) {
            case ADD: {
                    pa[ best.x ] = best.y;
                    pb[ best.y ] = best.x;
                    break;
                }
            case DEL: {
                    pa[ best.x ] = -1;
                    pb[ best.y ] = -1;
                    break;
                }
            case CHANGE1: {
                    pa[ best.y ] = pa[ best.x ];
                    pb[ pa[ best.x ] ] = best.y;
                    pa[ best.x ] = -1;
                    break;
                }
            case CHANGE2: {
                    pa[ best.x ]  = best.y1;
                    pb[ best.y1 ] = best.x;
                    pa[ best.y ]  = best.x1;
                    pb[ best.x1 ] = best.y;
                    break;

                }

            
            }
        }
    }

    printf("%i\n", ans);
    return 0;
}