#include <iostream>
#include <fstream>
#include <cmath>
#include <cstdlib>
#include <map>
#include <set>
#include <vector>
#include <cstring>
#include <string>
#include <algorithm>
#include <queue>
#include <cassert>

using namespace std;

const int nmax = 100;

int a[nmax][nmax];

void process(const string& s) { 
	int color = s[0] - 'A';
	int value;
	if (s.size() == 2) {
		value = s[1] - '0';
	} else {
		value = 10 * (s[1] - '0') + s[2] - '0';
	}
	value -= 1;
	a[value][color] ++;
}

const int HORIZONTAL_SET_LENGTH = 3;
const int VERTICAL_SET_LENGTH = 5;
const int MAX_HORIZONTAL = 4;
const int MAX_VERTICAL = 13;

vector < vector < pair <int, int> > >  solution;

void write(const pair<int,int>& p) {
	cout << (char)(p.second + 'A') << p.first + 1;
}

void write(const vector<pair<int,int> >& v) {
	cout << v.size(); 
	for (int i = 0; i < (int)v.size(); i ++) {
		cout << " ";
		write(v[i]);
	}
}

bool canPutHorizontal(int i, int j, int len) {
	for (int k = 0; k < len; k ++) {
		if (a[i][(j + k) % MAX_HORIZONTAL] == 0) {
			return false;
		}
	}
	return true;
}

bool canPutVertical(int i, int j, int len) {
	for (int k = 0; k < len; k ++) {
		if (a[i + k][j] == 0) {
			return false;
		}
	}
	return true;
}

void putHorizontal(int i, int j, int len) {
	vector < pair <int, int> > v;
	for (int k = 0; k < len; k ++) {
		v.push_back(make_pair(i, (j + k) % MAX_HORIZONTAL));
		a[i][(j + k) % MAX_HORIZONTAL] --;
	}
	solution.push_back(v);
}

void unputHorizontal(int i, int j, int len) {
	for (int k = 0; k < len; k ++) {
		a[i][(j + k) % MAX_HORIZONTAL] ++;
	}
	solution.pop_back();
}

void putVertical(int i, int j, int len) {
	vector < pair <int, int> > v;
	for (int k = 0; k < len; k ++) {
		v.push_back(make_pair(i + k, j));
		a[i + k][j] --;
	}
	solution.push_back(v);
}

void unputVertical(int i, int j, int len) {
	for (int k = 0; k < len; k ++) {
		a[i + k][j] ++;
	}
	solution.pop_back();
}

bool go(int i, int j, int step = 0) {
	if (j == 0 && i > 0) {
		for (int k = 0; k < MAX_HORIZONTAL; k ++) {
			if (a[i - 1][k] > 0) {
				return false;
			}
		}
	}
	if (j >= MAX_HORIZONTAL) {
		return go(i + 1, 0);
	}
	if (i >= MAX_VERTICAL) {
		return true;
	}
	if (step == 0) {
		for (int len = 3; canPutVertical(i, j, len); len ++) {
			putVertical(i, j, len);
			if (go(i, j, step)) {
				return true;
			}
			unputVertical(i, j, len);
		}
	}
	if (step == 1) {
		for (int len = 3; len <= 4; len ++) {
			if (len == 4 && j != 0) {
				continue;
			}
			if (canPutHorizontal(i, j, len)) {
				putHorizontal(i, j, len);
				if (go(i, j, step)) {
					return true;
				}
				unputHorizontal(i, j, len);
			}
		}
	}
	if (step == 2) {
		return go(i, j + 1, 0);
	}
	go(i, j, step + 1);
}

int main()
{
	freopen("rummikub.in", "r", stdin);
	freopen("rummikub.out", "w", stdout);
	int n;
	cin >> n;
	string s;
	for (int i = 0; i < n; i ++) {
		cin >> s;
		process(s);
	}
	if (go(0, 0)) {
		cout << solution.size() << endl;
		for (int i = 0; i < (int) solution.size(); i ++) {
			write(solution[i]); 
			cout << endl;
		}
	} else {
		cout << -1 << endl;
	}
	return 0;
}
