#include <iostream>
#include <fstream>
#include <cmath>
#include <cstdlib>
#include <map>
#include <set>
#include <vector>
#include <cstring>
#include <string>
#include <algorithm>
#include <queue>
#include <cassert>

using namespace std;

long long calc(long long n) {
	if (n == 0) {
		return 0;
	}
	long long k = 1;
	long long s = 0;
	long long currentNumber = 0;
	while (2 * k + 1 <= n) {
		currentNumber += 1;
		s *= 2;
		s += currentNumber;
		k = 2 * k + 1;
	}
	if (k == n) {
		return s;
	}
	return s + currentNumber + 1 + calc(n - k - 1);
}

int main()
{
	freopen("paint.in", "r", stdin);
	freopen("paint.out", "w", stdout);
	long long l, r;
	cin >> l >> r;
	cout << calc(r) - calc(l - 1) << endl;
	return 0;
}
