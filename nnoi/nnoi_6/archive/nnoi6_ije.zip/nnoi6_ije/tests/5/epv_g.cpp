#include <cstdio>
#include <cassert>
#include <vector>

using namespace std;

int l, n, m, k, last[1000], was[1000], use[10000];
vector<pair<int, int> > v[4][1000];

int go (int it, int x) {
	was[x] = 1;
	while (last[x] < (int)v[it][x].size ()) {
		int y = v[it][x][last[x]].first, z = v[it][x][last[x]].second;
		last[x]++;
		if (use[z]) continue;
		use[z] = 1;
		go (it, y);
		l ^= 1;
		if (l) {                                 
			v[it + 1][x].push_back (make_pair (y, z));
			v[it + 1][y].push_back (make_pair (x, z));
		}
	}
	return 0;
}
                            
int main () {                       
	freopen ("secret.in", "rt", stdin);
	freopen ("secret.out", "wt", stdout);
	scanf ("%d%d", &n, &k);
	m=k*n;
	assert (n >= 1 && n <= 500 && k <= 4 && k >= 0);
	assert (m == n * k);
	for (int i = 0; i < m; i++) {
		int a, b;
		scanf ("%d%d", &a, &b); a--; b--;
		assert (a >= 0 && a < n && b >= 0 && b < n);
		b += n;
		v[0][a].push_back (make_pair (b, i));
		v[0][b].push_back (make_pair (a, i));
	}
	n *= 2;
	assert ((k & (k - 1)) == 0);
	for (int i = 0; i < n; i++)
		assert ((int)v[0][i].size () == k);
	int it;
	for (it = 0; k > 1; it++, k >>= 1) {
		memset (was, 0, sizeof (was));
		memset (use, 0, sizeof (use));
		memset (last, 0, sizeof (last));
		l = 0;
		for (int i = 0; i < n; i++)
			if (!was[i])
				go (it, i);
	}
	for (int i = 0; i < n; i++)
		if (v[it][i][0].first > i)
			printf ("%d %d\n", i + 1, v[it][i][0].first + 1 - n / 2);
}