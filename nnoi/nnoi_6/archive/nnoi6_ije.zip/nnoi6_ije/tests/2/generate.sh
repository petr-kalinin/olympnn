echo "- compiling generate.cpp"
g++ -o generate generate.cpp
echo "- creating tests"
./generate
echo "- clearing"
rm generate
echo "- generating answers"
./answers.sh
