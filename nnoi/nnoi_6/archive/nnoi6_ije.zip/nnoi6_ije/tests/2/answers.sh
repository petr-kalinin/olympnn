echo "- compiling solution.cpp"
g++ -o solution solution.cpp
echo "- clearing previous answers"
rm -f *.a
echo "- generating new answers"
for i in ??
do
	cp $i change.in
	./solution
	mv change.out $i.a
done
echo "- clearing"
rm change.in
rm solution
