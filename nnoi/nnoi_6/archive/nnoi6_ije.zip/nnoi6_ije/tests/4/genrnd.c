#include <stdio.h>
#include <stdlib.h>
#include <glib.h>

static gint n       = 10;
static gint m       = 10;
static gint block_n = 1000;
static gint block_m = 1000;
static gdouble prob = 0.5;
static gint    seed = 239;
static gboolean frame = FALSE;

static GOptionEntry option_entries[] =
{
  { "N", 'N', 0, G_OPTION_ARG_INT, &n, "Number of lines (N)", NULL },
  { "M", 'M', 0, G_OPTION_ARG_INT, &m, "Number of rows (M)", NULL },
  { "block-n", 'n', 0, G_OPTION_ARG_INT, &block_n, "Lines in block", NULL },
  { "block-m", 'm', 0, G_OPTION_ARG_INT, &block_m, "Rows in block", NULL },
  { "prob", 'p', 0, G_OPTION_ARG_DOUBLE, &prob, "Probability of ball (#)", NULL },
  { "seed", 's', 0, G_OPTION_ARG_INT, &seed, "Change random seed", NULL },
  { "frame", 'f', 0, G_OPTION_ARG_NONE, &frame, "Make frame", NULL },
  { NULL }
};

void init (int argc, char* argv[])
{
	GError *error = NULL;
	GOptionContext *context;
	
	context = g_option_context_new ("");
	g_option_context_add_main_entries (context, option_entries, NULL);
	if (!g_option_context_parse (context, &argc, &argv, &error)) {
		g_warning ("error parsing options: %s\n", error->message);
		exit (1);
	}
	if (block_n > n) block_n = n;
	if (block_m > m) block_m = m;
	g_option_context_free (context);
}

int main (int argc, char* argv[])
{
	gboolean **block;
	gint i, j;
	
	init (argc, argv);
	g_random_set_seed (seed);
	
	block = g_new (gboolean*, block_n);
	for (i = 0; i < block_n; i++) {
		block[i] = g_new0 (gboolean, block_m);
		for (j = 0 ;j < block_m; j++)
			block[i][j] = g_random_double () < prob;
	}
	
	printf ("%d %d\n", n, m);
	for (i = 0; i < n; i++) {
		for (j = 0; j < m; j++) {
			gchar c = block[i % block_n][j % block_m] ? '#' : '.';
			if (frame) if (i == 0 || j == 0 || i == n-1 || j == m-1)
				c = '#';
			printf ("%c", c);
		}
		printf ("\n");
	}
	
	for (i = 0; i < block_n; i++)
		g_free (block[i]);
	g_free (block);
	
	return 0;
}

