#include <stdio.h>
#include <string.h>
#include <assert.h>

#define MAXN 500
#define MAXK 4

typedef struct _Edge Edge;
struct _Edge {
	int from, to, mark;
};

static int N, K;
static Edge  edge[MAXN * MAXK];
static int   size[MAXN * 2];
static Edge* next[MAXN * 2][MAXK];
static char  done[MAXN * 2];

static int get_next (int v, int i)
{
	return (v >= N) ? next[v][i]->from : (N + next[v][i]->to);
}

static int mark, top, del;
static void walk (int v)
{
	int i;
	
	done[v] = 1;
	for (i = size[v] - 1; i >= 0; i--) {
		if (next[v][i]->mark == mark || next[v][i]->mark < 0)
			continue;
		next[v][i]->mark = mark;
		walk (get_next (v, i));
	}
	
	if (top != -1 && del) {
		int found = 0;
		for (i = size[top] - 1; i >= 0; i--) {
			if (get_next (top, i) == v) {
				assert (next[top][i]->mark >= 0);
				next[top][i]->mark = -1;
				found = 1;
				break;
			}
		}
		assert (found);
	}
	del ^= 1;
	top = v;
}

int main()
{
	int i, t;
	
	freopen ("secret.in", "r", stdin);
	freopen ("secret.out", "w", stdout);
	
	scanf ("%d %d", &N, &K);
	for (i = 0; i < N*K; i++) {
		int from, to;
		scanf("%d %d", &from, &to);
		from--; to--;
		
		edge[i].from = from;
		edge[i].to   = to;
		edge[i].mark = 0;
		
		next[from][size[from]++] = &edge[i];
		next[N+to][size[N+to]++] = &edge[i];
	}
	for (i = 0; i < 2*N; i++)
		assert (size[i] == K);
	
	mark = 0;
	for (t = K; t > 1; t >>= 1) {
		memset (done, 0, sizeof (done));
		mark++;
		
		for (i = 0; i < 2*N; i++) {
			top = -1;
			del = 0;
			if (!done[i]) walk (i);
		}
	}
	
	for (i = 0; i < N*K; i++) {
		if (edge[i].mark >= 0) {
			printf ("%d %d\n", edge[i].from + 1, edge[i].to + 1);
		}
	}
	return 0;
}

