#include <stdio.h>
#include <string.h>
#include <assert.h>

#define fin "lg.in"
#define fout "lg.out"

int main()
{
	char s[102];
	int a[102],n,b,ans=0,i,head;

	freopen(fin,"rt",stdin);
	freopen(fout,"wt",stdout);

	scanf("%s%d",s,&b);
	n=strlen(s);

	assert(b>=2&&b<=100);
	assert(s[0]>'0');
	assert(n<=101);
	if (n==101){
		assert(s[0]=='1');
		for (i=1;i<n;i++)assert(s[i]=='0');
	}

	memset(a,0,sizeof(a));
	for (i=0;i<n;i++){
		assert('0'<=s[i]&&s[i]<='9');
		a[i]=s[i]-'0';
	}
	
	head=0;
	while (1){
		for (i=head;i<n-1;i++){
			a[i+1]+=(a[i]%b)*10;
			a[i]/=b;
		}
		a[n-1]/=b;
		for (i=n-1;i>head;i--){
			a[i-1]+=a[i]/10;
			a[i]%=10;
		}
		while (head<n&&a[head]==0)head++;
		if (head==n) break;
		ans++;
	}

	printf("%d\n",ans);
	fflush(stdout);

	return 0;
}
