// ��������� ������ ������� - �������� ~25 ������

#include <cstdio>
#include <cassert>
#include <vector>

using namespace std;

int n, m, k, ea[10000], eb[10000], p[10000];
                            
int main () {                       
	freopen ("secret.in", "rt", stdin);
	freopen ("secret.out", "wt", stdout);
	scanf ("%d%d", &n, &k);
	m = n * k;
	for (int i = 0; i < m; i++) {
		scanf ("%d%d", &ea[i], &eb[i]); 
		ea[i]--; eb[i]--;
		eb[i] += n;
	}
	n *= 2;
	memset (p, -1, sizeof (p));
	for (int i = 0; i < m; i++)
		if (p[ea[i]] == -1 && p[eb[i]] == -1) {
			p[ea[i]] = eb[i];
			p[eb[i]] = ea[i];
		}
	for (int i = 0; i < n; i++)
		if (p[i] > i)
			printf ("%d %d\n", i + 1, p[i] + 1 - n / 2);
}