#include <stdio.h>

int main()
{
	int n, i, coins, min, cur;
	freopen ("change.in", "r", stdin);
	freopen ("change.out", "w", stdout);
	
	scanf("%d", &n);
	coins = min = 0;
	for (i = 0; i < n; i++) {
		scanf ("%d", &cur);
		if (cur != 5)
			coins -= (cur - 5) / 5;
		else
			coins++;
		if (coins < min)
			min  = coins;
	}
	printf ("%d\n", -min);
	return 0;
}
