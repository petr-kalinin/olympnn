import java.util.*;
import java.io.*;
import java.math.*;

public class ash_3 {

	public static void main(String[] args) throws Exception {
		Scanner in = new Scanner(new FileInputStream("lg.in"));
		PrintWriter out = new PrintWriter(new FileOutputStream("lg.out"));
		
		BigInteger a = in.nextBigInteger(), b = in.nextBigInteger();
		int answer = 0;
		
		while (a.compareTo(b) >= 0) {
			answer++;
			a = a.divide(b);
		}
		
		out.println(answer);
		out.flush();
	}
}
