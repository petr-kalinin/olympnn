import java.util.*;
import java.io.*;
import java.math.*;

public class nis_3 {
	Scanner in;
	PrintWriter out;
	
	void run() throws IOException {
		in = new Scanner(new File("lg.in"));
		BigInteger A = in.nextBigInteger();
		int b = in.nextInt();
		if (A.compareTo(new BigInteger("10").pow(100)) > 0 || b < 2 || b > 100)
			throw new IOException("Wrong input format");
		BigInteger B = BigInteger.valueOf(b);
		in.close();
		
		int l = 0, r = 400;
		while (r - l > 1) {
			int m = (l + r) >> 1;
			if (B.pow(m).compareTo(A) <= 0)
				l = m;
			else
				r = m;
		}
		
		out = new PrintWriter(new File("lg.out"));
		out.println(l);
		out.close();
	}

	public static void main(String[] args) throws IOException {
		new nis_3().run();
	}

}
