#define inputfile "balls.in"
#define outputfile "balls.out"

#include <fstream>
#include <vector>

int main() {
	std::ifstream ifs(inputfile, std::ifstream::in);
	int m, n;
	ifs >> n >> m;
	assert((m>0)&&(n>0));
	std::vector< std::vector<char> > p(2*n-1, std::vector<char>(2*m-1, ' '));
	char c;
	for (int i=0; i<n; ++i)
		for (int j=0; j<m; ++j) {
			ifs >> c;
			assert((c=='#')||(c=='.'));
			p[2*i][2*j] = c;
		}
	ifs.close();

	for (int i=0; i<2*n-1; ++i)
		for (int j=0; j<2*m-1; ++j)	{
			if (i%2==0) {
				if (j%2==1) {
					if ((p[i][j-1]=='#')&&(p[i][j+1]=='#'))
						p[i][j] = '-';
				}
			}
			else {
				if (j%2==0) {
					if ((p[i-1][j]=='#')&&(p[i+1][j]=='#'))
						p[i][j] = '|';
				}
				else {
					bool ls = (p[i+1][j-1]=='#')&&(p[i-1][j+1]=='#');
					bool rs = (p[i-1][j-1]=='#')&&(p[i+1][j+1]=='#');
					if (ls&&rs)
						p[i][j] = 'X';
					else {
						if (ls) p[i][j] = '/';
						if (rs) p[i][j] = '\\';
					}
				}
			}
		}
	
	std::ofstream ofs(outputfile, std::ofstream::out);
	
	for (int i=0; i<2*n-1; ++i) {
		for (int j=0; j<2*m-1; ++j)
			ofs << p[i][j];
		ofs << std::endl;
	}	

	ofs.close();
}