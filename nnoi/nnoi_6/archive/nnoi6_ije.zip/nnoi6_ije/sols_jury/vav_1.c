#include <stdio.h>
#include <assert.h>
#include <math.h>

#define fin "metro.in"
#define fout "metro.out"
#define abs(x) ((x)>0?(x):-(x))
#define eps 1e-9

int gcd(int a,int b)
{
	if (b==0)return a;return gcd(b,a%b);
}

int main()
{
	int x,y,r,x1,y1,x2,y2,q;
	double a,b,c,d,t1,t2;
	freopen(fin,"rt",stdin);
	freopen(fout,"wt",stdout);
	scanf("%d%d%d%d%d%d%d",&x,&y,&r,&x1,&y1,&x2,&y2);
	q=gcd(abs(x2-x1),abs(y2-y1));
	x2=(x2-x1)/q;
	y2=(y2-y1)/q;
	x1-=x;y1-=y;
	//(x1+x2*t)^2+(y1+y2^t)^2<=r^2
	//t^2(x2^2+y2^2)+2*t*(x1*x2+y1*y2)+x1^2+y1^2-r^2<=0
	a=((double)x2*(double)x2+(double)y2*(double)y2);
	b=((double)x1*(double)x2+(double)y1*(double)y2);
	c=((double)x1*(double)x1+(double)y1*(double)y1-(double)r*(double)r);
	d=b*b-a*c;
	if (fabs(d)<eps)d=0.0;
	if (d<0.0)printf("0\n");
	else{
		int l,r;
		t1=(-b-sqrt(d))/a;
		t2=(-b+sqrt(d))/a;
		l=(int)t1-10;
		r=(int)t2+10;
		while (l+eps<t1)l++;
		while (r-eps>t2)r--;
		if (r-l>=0)printf("%d\n",r-l+1);else printf("0\n");
	}
	fflush(stdout);
	return 0;
}
